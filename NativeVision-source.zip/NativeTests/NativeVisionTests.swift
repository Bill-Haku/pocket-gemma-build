import XCTest
import UIKit
import Metal
import Darwin
import LiteRTLM
import PocketCore
import VisionRuntimeBridge
@testable import PocketGemma

actor ProbeReply {
    var text = ""
    func append(_ chunk: String) { text += chunk }
    func value() -> String { text.lowercased() }
}

final class NativeVisionTests: XCTestCase {
    override func setUpWithError() throws {
        executionTimeAllowance = 240
        try AppFiles.prepareModels()
        let fixtures = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("NativeModels")
        for spec in [ModelSpec.e2b, .e4b] where !AppFiles.hasVerifiedModel(spec) {
            let source = fixtures.appendingPathComponent(spec.fileName)
            guard FileManager.default.fileExists(atPath: source.path) else {
                throw XCTSkip("Real pinned model fixture missing; never substitute mock inference.")
            }
            let pending = AppFiles.pendingModel(spec)
            if FileManager.default.fileExists(atPath: pending.path) { try FileManager.default.removeItem(at: pending) }
            try FileManager.default.moveItem(at: source, to: pending)
            try ModelValidator.validate(pending, spec: spec)
            try AppFiles.installVerifiedModel(spec)
        }
        print("NATIVE_ENV iOS=\(UIDevice.current.systemVersion) physicalMemory=\(ProcessInfo.processInfo.physicalMemory) Metal=\(MTLCreateSystemDefaultDevice()?.name ?? "unavailable") SDK=0.18.0")
    }

    func fixture(circle: Bool = false) async throws -> ChatAttachment {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".jpg")
        let image = UIGraphicsImageRenderer(size: CGSize(width: 512, height: 512)).image { ctx in
            UIColor.white.setFill(); ctx.fill(CGRect(x: 0, y: 0, width: 512, height: 512))
            (circle ? UIColor.green : UIColor.red).setFill()
            let bounds = CGRect(x: 96, y: 96, width: 320, height: 320)
            if circle { ctx.cgContext.fillEllipse(in: bounds) } else { ctx.fill(bounds) }
        }
        try XCTUnwrap(image.jpegData(compressionQuality: 0.85)).write(to: url)
        // Exercise the production EXIF/resize/JPEG import, not an alternate codec.
        return try await AttachmentStorage.importFile(url)
    }

    func production(_ service: GemmaService, _ spec: ModelSpec, image: ChatAttachment?,
                    budget: Int = 280, backend: ExecutionBackend = .gpu, visionBackend: ExecutionBackend = .cpu, thread: UUID = UUID(), history: [ChatMessage] = [],
                    text: String = "Describe the main shape and its color in English with one short sentence.",
                    kernel: VisionCPUImplementation = .xnnpack) async throws -> String {
        let result = ProbeReply()
        var settings = GenerationSettings(); settings.maxTokens = 4096
        settings.maxOutputTokens = 128; settings.topK = 1; settings.topP = 1
        settings.temperature = 0; settings.visualTokenBudget = budget; settings.backend = backend
        settings.visionBackend = visionBackend
        settings.visionCPUImplementation = kernel
        try await service.generate(threadID: thread, prompt: text, history: history, model: spec,
            settings: settings, attachments: image.map { [$0] } ?? [],
            onStage: { print("NATIVE_STAGE \(spec.id) \($0)") },
            onText: { await result.append($0) })
        let reply = await result.value()
        print("NATIVE_REPLY \(spec.id) \(reply)")
        XCTAssertFalse(reply.isEmpty)
        return reply
    }

    // GPU failures in this virtual Metal device are recorded as blocked tests,
    // never as successful image recognition or evidence of a phone vision bug.
    func testProductionConfigurationMatrix4096() async throws {
        executionTimeAllowance = 900
        let image = try await fixture()
        var records: [InferenceDiagnostic] = []
        for spec in [ModelSpec.e2b, .e4b] {
            for (main, vision) in [(ExecutionBackend.gpu, ExecutionBackend.gpu), (.gpu, .cpu), (.cpu, .cpu)] {
                let service = GemmaService()
                do {
                    let reply = try await production(service, spec, image: image, backend: main, visionBackend: vision)
                    XCTAssertTrue(reply.contains("red") && (reply.contains("square") || reply.contains("rectangle")), reply)
                    XCTAssertEqual(InferenceDiagnostic.load()?.result, "success")
                } catch {
                    let record = try XCTUnwrap(InferenceDiagnostic.load())
                    let native = (record.nativeLogLines ?? []).joined(separator: "\n")
                    XCTAssertEqual(main, .gpu, "CPU/CPU must perform real vision inference")
                    XCTAssertEqual(record.stage, "engine_initialization", "Only the previously measured simulator main-GPU limitation may block this probe")
                    XCTAssertTrue(native.contains("texture binding has argument index") || native.contains("delegate_metal.mm:"), "Unexpected native failure: \(error)\n\(native)")
                    print("NATIVE_SIMULATOR_BLOCKED \(spec.id) \(main)/\(vision) stage=\(record.stage)")
                }
                let record = try XCTUnwrap(InferenceDiagnostic.load())
                XCTAssertEqual(record.modelSHA256, spec.sha256)
                XCTAssertEqual(record.contextTokens, 4096); XCTAssertEqual(record.visionTokens, 280)
                XCTAssertEqual(record.mainBackend, main.rawValue); XCTAssertEqual(record.visionBackend, vision.rawValue)
                XCTAssertNotNil(record.runtimeBuild, "Native binary receipt must be available in diagnostic exports")
                XCTAssertFalse(record.conversationWasReused ?? false)
                records.append(record)
                await service.unload()
            }
        }
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]; encoder.dateEncodingStrategy = .iso8601
        let destination = AppFiles.root.appendingPathComponent("native-configuration-matrix.json")
        let matrixData = try encoder.encode(records)
        try matrixData.write(to: destination)
        // XCTest may run a cloned simulator container. Export synthetic-only
        // diagnostic evidence via stdout as well as the production local file.
        print("NATIVE_MATRIX_JSON \(matrixData.base64EncodedString())")
        print("NATIVE_HISTORY_JSON \(try encoder.encode(InferenceDiagnostic.history()).base64EncodedString())")
        XCTAssertEqual(records.filter { $0.result == "success" && $0.mainBackend == "CPU" }.count, 2)
    }

    func testNativeLogCaptureRestoresStderrAndRecordsOnlyOperationalErrors() throws {
        let capture = try XCTUnwrap(NativeLogCapture())
        let bytes = "ERROR: XNNPack delegate failed to reshape runtime\nNode number 1480 (TfLiteXNNPackDelegate) failed to prepare.\nPrivate synthetic unrelated text\n"
        bytes.withCString { pointer in _ = write(STDERR_FILENO, pointer, strlen(pointer)) }
        let first = capture.finish()
        XCTAssertEqual(first.lines.count, 2); XCTAssertEqual(first.discardedLines, 1)
        XCTAssertEqual(NativeLogEvidence(error: "", logLines: first.lines).failedDelegate, "XNNPACK")
        let another = try XCTUnwrap(NativeLogCapture(), "stderr reservation must be released after an error")
        XCTAssertTrue(another.finish().lines.isEmpty)
    }

    func testE2BDirectBundledJPEGs() async throws { try await directJPEGs(.e2b) }
    func testE4BDirectBundledJPEGs() async throws { try await directJPEGs(.e4b) }
    func testE2BDirectBuiltinJPEGs() async throws { try await directJPEGs(.e2b, kernel: .builtin) }
    func testE4BDirectBuiltinJPEGs() async throws { try await directJPEGs(.e4b, kernel: .builtin) }
    private func directJPEGs(_ spec: ModelSpec, kernel: VisionCPUImplementation = .xnnpack) async throws {
        executionTimeAllowance = 900
        for kind in [VisionProbeKind.squareJPEG, .portraitJPEG] {
            let reply: String
            do { reply = try await VisionDiagnosticRunner.run(model: spec, kind: kind, main: .cpu, vision: .cpu, kernel: kernel) }
            catch { exportProbe(); throw error }
            exportProbe()
            XCTAssertTrue(reply.lowercased().contains("red")); XCTAssertTrue(reply.lowercased().contains("square"))
            let record = try XCTUnwrap(InferenceDiagnostic.load())
            XCTAssertEqual(record.inputPath, "bundled_jpeg_direct_sdk")
            XCTAssertEqual(record.contextTokens, 4096); XCTAssertEqual(record.visionTokens, 280)
            XCTAssertEqual(record.modelSHA256, spec.sha256); XCTAssertEqual(record.result, "success")
            XCTAssertEqual(record.visionCPUImplementation, kernel.rawValue)
            XCTAssertEqual(record.runtimeBuild?.nativeBuild?.buildID, "0.18.0-pg1")
            let native = (record.nativeLogLines ?? []).joined(separator: "\n")
            XCTAssertTrue(native.contains("PG_COMPONENT vision_resources=engine_pool"), native)
            XCTAssertTrue(native.contains(kernel == .builtin ? "vision_cpu_kernel=builtin_no_xnnpack" : "vision_cpu_kernel=delegate_xnnpack"), native)
            XCTAssertGreaterThan(record.sampledPeakVirtualSize ?? 0, 0)
        }
    }
    func testE2BIsolatedCPUComponents() async throws { try await isolatedComponents(.e2b) }
    func testE4BIsolatedCPUComponents() async throws { try await isolatedComponents(.e4b) }
    private func isolatedComponents(_ spec: ModelSpec) async throws {
        executionTimeAllowance = 900
        for kind in [VisionProbeKind.encoderDelegate, .encoderBuiltin, .adapterDelegate, .adapterBuiltin] {
            do {
                let description = try await VisionDiagnosticRunner.run(model: spec, kind: kind, main: .cpu, vision: .cpu)
                print("NATIVE_COMPONENT_RESULT \(spec.id) \(kind.rawValue) \(description)")
                exportProbe()
                let record = try XCTUnwrap(InferenceDiagnostic.load())
                XCTAssertEqual(record.result, "success")
                XCTAssertEqual(record.outputFinite, true)
                XCTAssertEqual(record.inputPath, "isolated_component_synthetic_tensors")
                XCTAssertEqual(record.testedComponent, kind.isEncoder ? "vision_encoder" : "vision_adapter")
                XCTAssertEqual(record.modelSHA256, spec.sha256)
            } catch {
                exportProbe()
                XCTFail("\(spec.id) \(kind.rawValue) failed: \(error.localizedDescription)")
            }
        }
    }
    private func exportProbe() {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]; encoder.dateEncodingStrategy = .iso8601
        if let record = InferenceDiagnostic.load(), let data = try? encoder.encode(record) {
            print("NATIVE_PROBE_JSON \(data.base64EncodedString())")
        }
    }

    func testE2BProductionImage() async throws { try await productionImage(.e2b) }
    func testE4BProductionImage() async throws { try await productionImage(.e4b) }
    func testE2BProductionCPUImage() async throws { try await productionImage(.e2b, backend: .cpu) }
    func testE4BProductionCPUImage() async throws { try await productionImage(.e4b, backend: .cpu) }
    func productionImage(_ spec: ModelSpec, backend: ExecutionBackend = .gpu) async throws {
        let service = GemmaService(), image = try await fixture()
        let reply = try await production(service, spec, image: image, backend: backend)
        XCTAssertTrue(reply.contains("red") && (reply.contains("square") || reply.contains("rectangle")), reply)
        let text = try await production(service, spec, image: nil, backend: backend, text: "What is 2 plus 3? Answer only with the number.")
        XCTAssertTrue(text.contains("5"), text)
        await service.unload()
    }
    func testE2BProductionBudget70() async throws { try await budget70(.e2b) }
    func testE4BProductionBudget70() async throws { try await budget70(.e4b) }
    func budget70(_ spec: ModelSpec) async throws {
        let service = GemmaService(), image = try await fixture()
        let reply = try await production(service, spec, image: image, budget: 70)
        XCTAssertTrue(reply.contains("red"), reply)
        await service.unload()
    }
    func testE2BNativeCPUEncoder() async throws { try await cpuEncoder(.e2b) }
    func testE4BNativeCPUEncoder() async throws { try await cpuEncoder(.e4b) }
    func testE2BNativeCPUEncoder280() async throws { try await cpuEncoder(.e2b, budget: 280) }
    func testE4BNativeCPUEncoder280() async throws { try await cpuEncoder(.e4b, budget: 280) }
    func testE2BNativeGPUEncoder70() async throws { try await cpuEncoder(.e2b, vision: .gpu) }
    func testE4BNativeGPUEncoder70() async throws { try await cpuEncoder(.e4b, vision: .gpu) }
    func testE2BNativeGPUEncoderFloat32() async throws { try await cpuEncoder(.e2b, vision: .gpu, precision: .float32) }
    func testE4BNativeGPUEncoderFloat32() async throws { try await cpuEncoder(.e4b, vision: .gpu, precision: .float32) }
    func testE2BAllCPU70() async throws { try await cpuEncoder(.e2b, main: .cpu(threadCount: 3)) }
    func testE4BAllCPU70() async throws { try await cpuEncoder(.e4b, main: .cpu(threadCount: 3)) }
    func testE2BAllCPU280() async throws { try await cpuEncoder(.e2b, budget: 280, main: .cpu(threadCount: 3)) }
    func testE4BAllCPU280() async throws { try await cpuEncoder(.e4b, budget: 280, main: .cpu(threadCount: 3)) }
    func testE2BMainCPUVisionGPU70() async throws { try await cpuEncoder(.e2b, vision: .gpu, main: .cpu(threadCount: 3)) }
    func testE4BMainCPUVisionGPU70() async throws { try await cpuEncoder(.e4b, vision: .gpu, main: .cpu(threadCount: 3)) }
    func cpuEncoder(_ spec: ModelSpec, budget: Int32 = 70, vision: Backend = .cpu(threadCount: 3),
                    precision: ActivationDataType? = nil, main: Backend = .gpu) async throws {
        let image = try await fixture()
        ExperimentalFlags.optIntoExperimentalAPIs(); ExperimentalFlags.visualTokenBudget = budget
        defer { ExperimentalFlags.visualTokenBudget = nil }
        let cache = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: cache, withIntermediateDirectories: true)
        let engine = Engine(engineConfig: try EngineConfig(modelPath: AppFiles.model(spec).path,
            backend: main, visionBackend: vision, maxNumTokens: 2048, cacheDir: cache.path, activationDataType: precision))
        print("NATIVE_ENCODER_STAGE initialize \(spec.id) main=\(main) vision=\(vision) budget=\(budget) precision=\(String(describing: precision))")
        try await engine.initialize()
        let chat = try await engine.createConversation(with: ConversationConfig(
            samplerConfig: try SamplerConfig(topK: 1, topP: 1, temperature: 0),
            thinkingConfig: ThinkingConfig(enableThinking: false, thinkingTokenBudget: 0),
            automaticToolCalling: false, visualTokenBudget: budget, enableSpeculativeDecoding: false))
        print("NATIVE_ENCODER_STAGE image \(spec.id)")
        var reply = ""
        for try await part in chat.sendMessageStream(Message(contents: [
            .imageFile(try XCTUnwrap(AttachmentStorage.url(image.imageNames[0])).path),
            .text("Describe the main shape and its color in English with one short sentence.")]), maxOutputTokens: 128) {
            reply += part.toString
        }
        print("NATIVE_ENCODER_REPLY \(spec.id) \(reply)")
        XCTAssertTrue(reply.lowercased().contains("red"), reply)
    }

    func testModelSwitchImagesAndText() async throws {
        try await modelSwitch(backend: .gpu)
    }
    func testCPUModelSwitchImagesAndText() async throws {
        try await modelSwitch(backend: .cpu)
    }
    func modelSwitch(backend: ExecutionBackend) async throws {
        executionTimeAllowance = 900
        let service = GemmaService(), image = try await fixture()
        for spec in [ModelSpec.e2b, .e4b, .e2b] {
            let text = try await production(service, spec, image: nil, backend: backend, text: "What is 4 plus 4? Answer only with the number.")
            XCTAssertTrue(text.contains("8"), text)
            let reply = try await production(service, spec, image: image, backend: backend)
            XCTAssertTrue(reply.contains("red"), reply)
        }
        await service.unload()
    }

    func testBadImageErrorThenGoodImage() async throws {
        try await recovery(backend: .gpu)
    }
    func testCPUBadImageErrorThenGoodImage() async throws {
        try await recovery(backend: .cpu)
    }
    func testE4BCPUBadImageErrorThenGoodImage() async throws {
        try await recovery(.e4b, backend: .cpu)
    }
    func testBuiltinVisionRecoverySwitchAndMemoryPlateau() async throws {
        executionTimeAllowance = 1800
        let service = GemmaService()
        let red = try await fixture(), green = try await fixture(circle: true)
        var records: [[String: String]] = []
        // Three passes per model use the same engine and fresh conversations.
        // Alternating unseen pixel content prevents a constant "red square"
        // response from passing as image recognition.
        for spec in [ModelSpec.e2b, .e4b] {
            var footprints: [UInt64] = []
            var virtualSizes: [UInt64] = []
            for index in 0..<3 {
                let circle = index % 2 == 1
                let reply = try await production(service, spec, image: circle ? green : red,
                    backend: .cpu, kernel: .builtin)
                XCTAssertTrue(reply.contains(circle ? "green" : "red"), reply)
                XCTAssertTrue((circle ? (reply.contains("circle") || reply.contains("circular") || reply.contains("round")) : (reply.contains("square") || reply.contains("rectangle"))), reply)
                footprints.append(PGProcessMemoryFootprint()); virtualSizes.append(PGProcessVirtualSize())
                records.append(["model": spec.id, "iteration": String(index), "footprint": String(footprints.last!),
                    "virtualSize": String(virtualSizes.last!), "kernel": "builtin", "reply": reply])
            }
            // Allow the allocator to retain scratch buffers; reject large
            // continuing growth after warmup. This is a simulator bound only.
            XCTAssertLessThanOrEqual(footprints[2], footprints[1] + 128 * 1024 * 1024)
            XCTAssertLessThanOrEqual(virtualSizes[2], virtualSizes[1] + 512 * 1024 * 1024)
            let text = try await production(service, spec, image: nil, backend: .cpu,
                text: "What is 2 plus 3? Answer only with the number.", kernel: .builtin)
            XCTAssertTrue(text.contains("5"), text)
        }
        let name = UUID().uuidString + ".jpg"
        try Data([0, 1, 2]).write(to: XCTUnwrap(AttachmentStorage.url(name)))
        let broken = ChatAttachment(kind: .image, name: "synthetic invalid JPEG", storedName: name, imageNames: [name])
        do {
            _ = try await production(service, .e4b, image: broken, backend: .cpu, kernel: .builtin)
            XCTFail("Invalid JPEG unexpectedly accepted")
        } catch { print("NATIVE_EXPECTED_BUILTIN_ERROR \(error.localizedDescription)") }
        let recovered = try await production(service, .e4b, image: green, backend: .cpu, kernel: .builtin)
        XCTAssertTrue(recovered.contains("green") && (recovered.contains("circle") || recovered.contains("circular") || recovered.contains("round")), recovered)
        let switched = try await production(service, .e2b, image: red, backend: .cpu, kernel: .builtin)
        XCTAssertTrue(switched.contains("red") && (switched.contains("square") || switched.contains("rectangle")), switched)
        let data = try JSONEncoder().encode(records)
        print("NATIVE_STABILITY_JSON \(data.base64EncodedString())")
        await service.unload()
    }
    func recovery(_ spec: ModelSpec = .e2b, backend: ExecutionBackend) async throws {
        let service = GemmaService(), image = try await fixture()
        let name = UUID().uuidString + ".jpg"
        try Data([0, 1, 2]).write(to: XCTUnwrap(AttachmentStorage.url(name)))
        let broken = ChatAttachment(kind: .image, name: "synthetic invalid JPEG", storedName: name, imageNames: [name])
        do {
            _ = try await production(service, spec, image: broken, backend: backend)
            XCTFail("Invalid JPEG unexpectedly accepted")
        } catch { print("NATIVE_EXPECTED_ERROR \(error.localizedDescription)") }
        let recovered = try await production(service, spec, image: image, backend: backend)
        XCTAssertTrue(recovered.contains("red"), recovered)
        await service.unload()
    }
}
