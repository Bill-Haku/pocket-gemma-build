import XCTest
import UIKit
import Metal
import LiteRTLM
import PocketCore
@testable import PocketGemma

actor ProbeReply {
    var text = ""
    func append(_ chunk: String) { text += chunk }
    func value() -> String { text.lowercased() }
}

final class NativeVisionTests: XCTestCase {
    override func setUpWithError() throws {
        executionTimeAllowance = 240
        try AppFiles.prepareModels()
        let fixtures = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("NativeModels")
        for spec in [ModelSpec.e2b, .e4b] where !AppFiles.hasVerifiedModel(spec) {
            let source = fixtures.appendingPathComponent(spec.fileName)
            guard FileManager.default.fileExists(atPath: source.path) else {
                throw XCTSkip("Real pinned model fixture missing; never substitute mock inference.")
            }
            let pending = AppFiles.pendingModel(spec)
            if FileManager.default.fileExists(atPath: pending.path) { try FileManager.default.removeItem(at: pending) }
            try FileManager.default.moveItem(at: source, to: pending)
            try ModelValidator.validate(pending, spec: spec)
            try AppFiles.installVerifiedModel(spec)
        }
        print("NATIVE_ENV iOS=\(UIDevice.current.systemVersion) physicalMemory=\(ProcessInfo.processInfo.physicalMemory) Metal=\(MTLCreateSystemDefaultDevice()?.name ?? "unavailable") SDK=0.18.0")
    }

    func fixture(circle: Bool = false) async throws -> ChatAttachment {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".jpg")
        let image = UIGraphicsImageRenderer(size: CGSize(width: 512, height: 512)).image { ctx in
            UIColor.white.setFill(); ctx.fill(CGRect(x: 0, y: 0, width: 512, height: 512))
            (circle ? UIColor.green : UIColor.red).setFill()
            let bounds = CGRect(x: 96, y: 96, width: 320, height: 320)
            if circle { ctx.cgContext.fillEllipse(in: bounds) } else { ctx.fill(bounds) }
        }
        try XCTUnwrap(image.jpegData(compressionQuality: 0.85)).write(to: url)
        // Exercise the production EXIF/resize/JPEG import, not an alternate codec.
        return try await AttachmentStorage.importFile(url)
    }

    func production(_ service: GemmaService, _ spec: ModelSpec, image: ChatAttachment?,
                    budget: Int = 280, backend: ExecutionBackend = .gpu, thread: UUID = UUID(), history: [ChatMessage] = [],
                    text: String = "Describe the main shape and its color in English with one short sentence.") async throws -> String {
        let result = ProbeReply()
        var settings = GenerationSettings(); settings.maxTokens = 2048
        settings.maxOutputTokens = 128; settings.topK = 1; settings.topP = 1
        settings.temperature = 0; settings.visualTokenBudget = budget; settings.backend = backend
        try await service.generate(threadID: thread, prompt: text, history: history, model: spec,
            settings: settings, attachments: image.map { [$0] } ?? [],
            onStage: { print("NATIVE_STAGE \(spec.id) \($0)") },
            onText: { await result.append($0) })
        let reply = await result.value()
        print("NATIVE_REPLY \(spec.id) \(reply)")
        XCTAssertFalse(reply.isEmpty)
        return reply
    }

    func testE2BProductionImage() async throws { try await productionImage(.e2b) }
    func testE4BProductionImage() async throws { try await productionImage(.e4b) }
    func testE2BProductionCPUImage() async throws { try await productionImage(.e2b, backend: .cpu) }
    func testE4BProductionCPUImage() async throws { try await productionImage(.e4b, backend: .cpu) }
    func productionImage(_ spec: ModelSpec, backend: ExecutionBackend = .gpu) async throws {
        let service = GemmaService(), image = try await fixture()
        let reply = try await production(service, spec, image: image, backend: backend)
        XCTAssertTrue(reply.contains("red") && (reply.contains("square") || reply.contains("rectangle")), reply)
        let text = try await production(service, spec, image: nil, backend: backend, text: "What is 2 plus 3? Answer only with the number.")
        XCTAssertTrue(text.contains("5"), text)
        await service.unload()
    }
    func testE2BProductionBudget70() async throws { try await budget70(.e2b) }
    func testE4BProductionBudget70() async throws { try await budget70(.e4b) }
    func budget70(_ spec: ModelSpec) async throws {
        let service = GemmaService(), image = try await fixture()
        let reply = try await production(service, spec, image: image, budget: 70)
        XCTAssertTrue(reply.contains("red"), reply)
        await service.unload()
    }
    func testE2BNativeCPUEncoder() async throws { try await cpuEncoder(.e2b) }
    func testE4BNativeCPUEncoder() async throws { try await cpuEncoder(.e4b) }
    func testE2BNativeCPUEncoder280() async throws { try await cpuEncoder(.e2b, budget: 280) }
    func testE4BNativeCPUEncoder280() async throws { try await cpuEncoder(.e4b, budget: 280) }
    func testE2BNativeGPUEncoder70() async throws { try await cpuEncoder(.e2b, vision: .gpu) }
    func testE4BNativeGPUEncoder70() async throws { try await cpuEncoder(.e4b, vision: .gpu) }
    func testE2BNativeGPUEncoderFloat32() async throws { try await cpuEncoder(.e2b, vision: .gpu, precision: .float32) }
    func testE4BNativeGPUEncoderFloat32() async throws { try await cpuEncoder(.e4b, vision: .gpu, precision: .float32) }
    func testE2BAllCPU70() async throws { try await cpuEncoder(.e2b, main: .cpu(threadCount: 3)) }
    func testE4BAllCPU70() async throws { try await cpuEncoder(.e4b, main: .cpu(threadCount: 3)) }
    func testE2BAllCPU280() async throws { try await cpuEncoder(.e2b, budget: 280, main: .cpu(threadCount: 3)) }
    func testE4BAllCPU280() async throws { try await cpuEncoder(.e4b, budget: 280, main: .cpu(threadCount: 3)) }
    func testE2BMainCPUVisionGPU70() async throws { try await cpuEncoder(.e2b, vision: .gpu, main: .cpu(threadCount: 3)) }
    func testE4BMainCPUVisionGPU70() async throws { try await cpuEncoder(.e4b, vision: .gpu, main: .cpu(threadCount: 3)) }
    func cpuEncoder(_ spec: ModelSpec, budget: Int32 = 70, vision: Backend = .cpu(threadCount: 3),
                    precision: ActivationDataType? = nil, main: Backend = .gpu) async throws {
        let image = try await fixture()
        ExperimentalFlags.optIntoExperimentalAPIs(); ExperimentalFlags.visualTokenBudget = budget
        defer { ExperimentalFlags.visualTokenBudget = nil }
        let cache = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: cache, withIntermediateDirectories: true)
        let engine = Engine(engineConfig: try EngineConfig(modelPath: AppFiles.model(spec).path,
            backend: main, visionBackend: vision, maxNumTokens: 2048, cacheDir: cache.path, activationDataType: precision))
        print("NATIVE_ENCODER_STAGE initialize \(spec.id) main=\(main) vision=\(vision) budget=\(budget) precision=\(String(describing: precision))")
        try await engine.initialize()
        let chat = try await engine.createConversation(with: ConversationConfig(
            samplerConfig: try SamplerConfig(topK: 1, topP: 1, temperature: 0),
            thinkingConfig: ThinkingConfig(enableThinking: false, thinkingTokenBudget: 0),
            automaticToolCalling: false, visualTokenBudget: budget, enableSpeculativeDecoding: false))
        print("NATIVE_ENCODER_STAGE image \(spec.id)")
        var reply = ""
        for try await part in chat.sendMessageStream(Message(contents: [
            .imageFile(try XCTUnwrap(AttachmentStorage.url(image.imageNames[0])).path),
            .text("Describe the main shape and its color in English with one short sentence.")]), maxOutputTokens: 128) {
            reply += part.toString
        }
        print("NATIVE_ENCODER_REPLY \(spec.id) \(reply)")
        XCTAssertTrue(reply.lowercased().contains("red"), reply)
    }

    func testModelSwitchImagesAndText() async throws {
        try await modelSwitch(backend: .gpu)
    }
    func testCPUModelSwitchImagesAndText() async throws {
        try await modelSwitch(backend: .cpu)
    }
    func modelSwitch(backend: ExecutionBackend) async throws {
        let service = GemmaService(), image = try await fixture()
        for spec in [ModelSpec.e2b, .e4b, .e2b] {
            let text = try await production(service, spec, image: nil, backend: backend, text: "What is 4 plus 4? Answer only with the number.")
            XCTAssertTrue(text.contains("8"), text)
            let reply = try await production(service, spec, image: image, backend: backend)
            XCTAssertTrue(reply.contains("red"), reply)
        }
        await service.unload()
    }

    func testBadImageErrorThenGoodImage() async throws {
        try await recovery(backend: .gpu)
    }
    func testCPUBadImageErrorThenGoodImage() async throws {
        try await recovery(backend: .cpu)
    }
    func testE4BCPUBadImageErrorThenGoodImage() async throws {
        try await recovery(.e4b, backend: .cpu)
    }
    func recovery(_ spec: ModelSpec = .e2b, backend: ExecutionBackend) async throws {
        let service = GemmaService(), image = try await fixture()
        let name = UUID().uuidString + ".jpg"
        try Data([0, 1, 2]).write(to: XCTUnwrap(AttachmentStorage.url(name)))
        let broken = ChatAttachment(kind: .image, name: "synthetic invalid JPEG", storedName: name, imageNames: [name])
        do {
            _ = try await production(service, spec, image: broken, backend: backend)
            XCTFail("Invalid JPEG unexpectedly accepted")
        } catch { print("NATIVE_EXPECTED_ERROR \(error.localizedDescription)") }
        let recovered = try await production(service, spec, image: image, backend: backend)
        XCTAssertTrue(recovered.contains("red"), recovered)
        await service.unload()
    }
}
