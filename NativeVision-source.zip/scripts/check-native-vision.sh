#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/select-xcode.sh
mkdir -p build/NativeVision
xcodegen generate --spec native-test-project.yml
xcrun simctl list runtimes -j > build/NativeVision/runtimes.json
runtime_id="$(python3 - <<'PY'
import json
d=json.load(open('build/NativeVision/runtimes.json'))['runtimes']
print(max((r for r in d if r.get('isAvailable') and r['name'].startswith('iOS') and int(r['version'].split('.')[0])>=26), key=lambda r:tuple(map(int,r['version'].split('.'))))['identifier'])
PY
)"
simulator_id="$(xcrun simctl create 'Pocket Gemma actual native vision' 'com.apple.CoreSimulator.SimDeviceType.iPhone-17-Pro' "$runtime_id")"
log_pid=""
cleanup() {
  if [[ -n "$log_pid" ]]; then kill "$log_pid" 2>/dev/null || true; fi
  xcrun simctl shutdown "$simulator_id" || true
}
trap cleanup EXIT
xcrun simctl boot "$simulator_id"
xcrun simctl bootstatus "$simulator_id" -b
xcodebuild -project PocketGemma.xcodeproj -scheme NativeVision \
  -destination "platform=iOS Simulator,id=$simulator_id" -derivedDataPath build/NativeDerived \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build-for-testing \
  > build/NativeVision/build.log 2>&1
xcrun simctl install "$simulator_id" build/NativeDerived/Build/Products/Debug-iphonesimulator/PocketGemma.app
data_container="$(xcrun simctl get_app_container "$simulator_id" app.pocketgemma.personal data)"
python3 scripts/download-vision-models.py "$data_container/Documents/NativeModels"
xcrun simctl spawn "$simulator_id" log stream --level debug --predicate 'process == "PocketGemma"' \
  > build/NativeVision/native-system.log 2>&1 &
log_pid=$!
set +e
xcodebuild -project PocketGemma.xcodeproj -scheme NativeVision \
  -destination "platform=iOS Simulator,id=$simulator_id" -derivedDataPath build/NativeDerived \
  -resultBundlePath build/NativeVision/NativeVision.xcresult -parallel-testing-enabled NO \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BAllCPU70 \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BAllCPU70 \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BAllCPU280 \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BAllCPU280 \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BMainCPUVisionGPU70 \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BMainCPUVisionGPU70 \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BProductionCPUImage \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BProductionCPUImage \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testCPUModelSwitchImagesAndText \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testCPUBadImageErrorThenGoodImage \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO test-without-building \
  > build/NativeVision/tests.log 2>&1
test_exit=$?
set -e
if [[ -d build/NativeVision/NativeVision.xcresult ]]; then
  xcrun xcresulttool get test-results summary --path build/NativeVision/NativeVision.xcresult \
    > build/NativeVision/summary.json || true
fi
tail -150 build/NativeVision/tests.log
exit "$test_exit"
