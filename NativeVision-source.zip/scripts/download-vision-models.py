"""Download public pinned test weights. Never include them in source/artifacts."""
from pathlib import Path
import urllib.request, hashlib, sys
out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
for name, rev, size, digest in [
    ('E2B', 'b3ca0d2f076785a8f4b2219ddbd2bdb99954eae1', 2588147712, '181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c'),
    ('E4B', '28299f30ee4d43294517a4ac93abd6163412f07f', 3659530240, '0b2a8980ce155fd97673d8e820b4d29d9c7d99b8fa6806f425d969b145bd52e0'),
]:
    file = f'gemma-4-{name}-it.litertlm'; sha = hashlib.sha256()
    url = f'https://huggingface.co/litert-community/gemma-4-{name}-it-litert-lm/resolve/{rev}/{file}?download=true'
    print('Downloading', name, flush=True)
    with urllib.request.urlopen(url, timeout=180) as response, (out/file).open('wb') as target:
        while chunk := response.read(8*1024*1024): target.write(chunk); sha.update(chunk)
    assert (out/file).stat().st_size == size and sha.hexdigest() == digest, 'Pinned model integrity mismatch'
    print('Verified', name, digest, flush=True)
