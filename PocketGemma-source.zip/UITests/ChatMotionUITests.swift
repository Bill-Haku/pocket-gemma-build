import XCTest

final class ChatMotionUITests: XCTestCase {
    @MainActor func testFirstLaunchModelChoiceAndCompletionPersist() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--startup", "--reset-startup"]
        app.launch()
        XCTAssertTrue(app.buttons["startup-skip"].waitForExistence(timeout: 10))
        capture("first-launch-models", app: app)
        let choice = app.buttons["startup-model-qwen3-06b"]
        let list = app.scrollViews["startup-model-list"]
        for _ in 0..<5 {
            if choice.exists && choice.isHittable && choice.frame.minY >= list.frame.minY
                && choice.frame.maxY < app.buttons["startup-continue"].frame.minY { break }
            list.swipeUp()
        }
        XCTAssertTrue(choice.isHittable); choice.tap()
        capture("first-launch-qwen-gauges", app: app)
        XCTAssertTrue(app.buttons["startup-continue"].isEnabled)
        app.buttons["startup-continue"].tap()
        XCTAssertTrue(app.staticTexts["Qwen3 0.6B"].waitForExistence(timeout: 5))
        app.terminate(); app.launchArguments = ["--startup"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        XCTAssertFalse(app.buttons["startup-skip"].exists)
    }

    @MainActor func testShortConversationAndGrowingReplyStayStableWithKeyboard() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--growing-reply", "--dark"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap()
        let modelName = app.staticTexts["Gemma 4 E4B"].firstMatch
        let firstY = modelName.frame.minY
        input.typeText("Short send")
        XCTAssertEqual(modelName.frame.minY, firstY, accuracy: 3, "Typing in a short chat must not reposition its content")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["Short send"].waitForExistence(timeout: 4))
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 8))
        XCTAssertFalse(app.buttons["chat-jump-latest"].exists)
        let reply = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "返信の確認12：")).firstMatch
        XCTAssertTrue(reply.exists)
        XCTAssertLessThanOrEqual(reply.frame.maxY, input.frame.minY)
        capture("short-send-long-reply-keyboard", app: app)
        let reading = app.scrollViews["chat-conversation"]
        // The scroll view extends behind the bars and keyboard. Its default
        // swipe coordinates can hit those controls instead of the text area.
        func swipeReading(up: Bool) {
            let top = max(reading.frame.minY, app.buttons["chat-model-settings"].frame.maxY + 16)
            let bottom = min(reading.frame.maxY, input.frame.minY - 20)
            XCTAssertGreaterThan(bottom - top, 80)
            let origin = app.coordinate(withNormalizedOffset: .zero)
            let x = reading.frame.midX
            let start = origin.withOffset(CGVector(dx: x, dy: top + (bottom - top) * (up ? 0.8 : 0.2)))
            let end = origin.withOffset(CGVector(dx: x, dy: top + (bottom - top) * (up ? 0.2 : 0.8)))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        swipeReading(up: false); swipeReading(up: false)
        XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 4))
        for _ in 0..<8 {
            if reply.exists && reply.frame.maxY <= input.frame.minY
                && reply.frame.maxY > input.frame.minY - 48 { break }
            swipeReading(up: true)
        }
        XCTAssertLessThanOrEqual(reply.frame.maxY, input.frame.minY)
        XCTAssertGreaterThan(reply.frame.maxY, input.frame.minY - 48, "The manual scroll must actually reach the reply's end")
        expectation(for: NSPredicate(format: "exists == false"), evaluatedWith: app.buttons["chat-jump-latest"])
        waitForExpectations(timeout: 4)
        capture("manual-return-no-jump", app: app)
    }

    @MainActor func testMenuSendAndInteractiveBack() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--gesture-diagnostics"]
        app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        XCTAssertEqual(menu.frame.height, 44, accuracy: 1)
        XCTAssertEqual(menu.frame.width, 44, accuracy: 1)
        let controlHeight = menu.frame.height
        menu.tap()
        capture("after-plus-tap", app: app)
        XCTAssertTrue(app.buttons["新しい会話"].waitForExistence(timeout: 3))
        capture("expanded-menu", app: app)
        app.buttons["新しい会話"].tap()
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        XCTAssertTrue(input.waitForExistence(timeout: 3))
        input.tap()
        input.typeText("Animation check")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["Animation check"].waitForExistence(timeout: 3))
        XCTAssertTrue(app.staticTexts["プレビュー用の返信です。入力欄・吹き出し・スクロールを確認できます。"].waitForExistence(timeout: 5))
        capture("sent-message-keyboard", app: app)
        app.buttons["会話一覧を開く"].tap()
        XCTAssertTrue(app.staticTexts["history-title"].waitForExistence(timeout: 4))
        app.buttons["会話を開く: Animation check"].tap()
        XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 3))
        let edge = app.coordinate(withNormalizedOffset: CGVector(dx: 0.015, dy: 0.45))
        let end = app.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.45))
        edge.press(forDuration: 0.1, thenDragTo: end)
        capture("after-edge-swipe", app: app)
        XCTAssertTrue(app.staticTexts["history-title"].waitForExistence(timeout: 4))
        capture("conversation-list", app: app)
        XCTAssertEqual(app.staticTexts.matching(identifier: "history-title").count, 1)
        for _ in 0..<2 {
            app.buttons["会話を開く: Animation check"].tap()
            XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 3))
            app.buttons["会話一覧を開く"].tap()
            XCTAssertTrue(app.staticTexts["history-title"].waitForExistence(timeout: 4))
            XCTAssertEqual(app.staticTexts.matching(identifier: "history-title").count, 1)
        }
        XCTAssertEqual(app.buttons["history-compose"].frame.height, controlHeight, accuracy: 1)
    }

    @MainActor func testLongConversationJumpControlAndHeader() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--long-chat"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        capture("long-chat-latest", app: app)
        let reading = app.scrollViews["chat-conversation"]
        XCTAssertTrue(reading.waitForExistence(timeout: 3))
        reading.swipeDown()
        reading.swipeDown()
        let jump = app.buttons["chat-jump-latest"]
        XCTAssertTrue(jump.waitForExistence(timeout: 3))
        XCTAssertEqual(jump.frame.height, 44, accuracy: 1)
        XCTAssertLessThan(jump.frame.maxY, app.buttons["chat-add-menu"].frame.minY)
        capture("jump-from-composer", app: app)
        jump.tap()
        let disappeared = NSPredicate(format: "exists == false")
        expectation(for: disappeared, evaluatedWith: jump)
        waitForExpectations(timeout: 4)
        capture("jump-returned-to-latest", app: app)
        // Selectable reply text is reading content, not a tappable control.
        // Check its actual viewport bounds rather than XCTest's hit point.
        let latest = app.staticTexts["最新の返信です。ここまで戻りました。"].firstMatch
        XCTAssertTrue(latest.exists)
        XCTAssertGreaterThan(latest.frame.width, 0)
        XCTAssertGreaterThan(latest.frame.height, 0)
        XCTAssertGreaterThanOrEqual(latest.frame.minY, reading.frame.minY)
        XCTAssertLessThanOrEqual(latest.frame.maxY, app.buttons["chat-add-menu"].frame.minY)
    }

    @MainActor func testStreamingReplyRemainsReadableAndFinishes() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--slow-reply"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap()
        input.typeText("Text animation")
        app.buttons["送信する"].tap()
        let partial = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "新しい文字が")).firstMatch
        XCTAssertTrue(partial.waitForExistence(timeout: 5))
        capture("reply-revealing", app: app)
        let finished = app.staticTexts["新しい文字がぼやけた状態から少しずつくっきり表示されます。\nすでに読んだ文章は鮮明なままです。日本語と絵文字もそのまま表示します。😊"]
        XCTAssertTrue(finished.waitForExistence(timeout: 8))
        expectation(for: NSPredicate(format: "exists == false"),
                    evaluatedWith: app.buttons["回答を停止する"])
        waitForExpectations(timeout: 3)
        capture("reply-fully-clear", app: app)
        XCTAssertTrue(app.staticTexts["Text animation"].exists)
    }

    @MainActor func testDarkModeWithReducedMotion() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--dark", "--reduce-motion", "--long-chat"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap()
        capture("dark-after-plus-tap", app: app)
        XCTAssertTrue(app.buttons["モデルと設定"].waitForExistence(timeout: 3))
        capture("dark-reduced-motion-menu", app: app)
        app.buttons["メニューを閉じる"].tap()
        XCTAssertTrue(app.buttons["会話の操作を開く"].waitForExistence(timeout: 3))
        let reading = app.scrollViews["chat-conversation"]
        reading.swipeDown()
        reading.swipeDown()
        XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 3))
        capture("dark-glass-scrolling", app: app)
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap()
        input.typeText("Glass check")
        XCTAssertTrue(app.buttons["送信する"].isHittable)
        capture("dark-glass-keyboard", app: app)
    }

    @MainActor func testModelCatalogSwitchPreservesGemmaHistory() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launch()
        XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(app.navigationBars["モデルと設定"].waitForExistence(timeout: 3))
        capture("model-catalog", app: app)
        let use = app.buttons["model-use-qwen3-06b"]
        for _ in 0..<8 {
            if use.isHittable { break }
            app.scrollViews["model-list"].swipeUp()
        }
        XCTAssertTrue(use.isHittable)
        capture("model-qwen-ready", app: app)
        use.tap()
        XCTAssertTrue(app.staticTexts["Qwen3 0.6B"].waitForExistence(timeout: 4))
        XCTAssertFalse(app.staticTexts["画面の動きを確認"].exists)
        capture("qwen-new-chat", app: app)
        app.buttons["会話一覧を開く"].tap()
        XCTAssertTrue(app.staticTexts["history-title"].waitForExistence(timeout: 3))
        app.buttons["会話を開く: 画面の動きを確認"].tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E4B"].waitForExistence(timeout: 3))
        XCTAssertTrue(app.staticTexts["画面の動きを確認"].exists)
        capture("gemma-history-preserved", app: app)
    }

    @MainActor func testTallReplyBubbleAndFeatheredChrome() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--tall-bubble"]
        app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        XCTAssertTrue(app.buttons["chat-model-settings"].isHittable)
        capture("tall-bubble-bottom", app: app)
        let reading = app.scrollViews["chat-conversation"]
        reading.swipeDown()
        capture("light-feathered-chrome", app: app)
        menu.tap()
        XCTAssertTrue(app.buttons["新しい会話"].waitForExistence(timeout: 3))
        capture("light-feathered-menu", app: app)
        app.buttons["メニューを閉じる"].tap()
        XCTAssertTrue(app.buttons["会話の操作を開く"].waitForExistence(timeout: 3))
        let greeting = app.staticTexts["こんにちは"].firstMatch
        for _ in 0..<10 {
            if greeting.exists && greeting.frame.minY >= reading.frame.minY
                && greeting.frame.maxY < menu.frame.minY { break }
            reading.swipeDown()
        }
        XCTAssertTrue(greeting.exists)
        XCTAssertGreaterThan(greeting.frame.width, 0)
        XCTAssertLessThan(greeting.frame.width, reading.frame.width * 0.75)
        capture("short-bubble-shapes", app: app)
    }

    @MainActor func testSendFromOlderMessagesWithMultilineKeyboardKeepsLatestAndCanScroll() {
        continueAfterFailure = false
        for dark in [false, true] {
            let app = XCUIApplication()
            app.launchArguments = ["--long-chat"] + (dark ? ["--dark"] : [])
            app.launch()
            XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
            let reading = app.scrollViews["chat-conversation"]
            reading.swipeDown(); reading.swipeDown()
            XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 3))
            let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
            input.tap(); input.typeText("Send scroll regression\nSecond line\nThird line")
            let beforeHeight = input.frame.height
            app.buttons["送信する"].tap()
            let sent = app.staticTexts["Send scroll regression\nSecond line\nThird line"].firstMatch
            XCTAssertTrue(sent.waitForExistence(timeout: 4))
            XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 6))
            XCTAssertFalse(app.buttons["chat-jump-latest"].exists)
            XCTAssertLessThan(input.frame.height, beforeHeight)
            XCTAssertGreaterThanOrEqual(sent.frame.minY, reading.frame.minY)
            XCTAssertLessThanOrEqual(sent.frame.maxY, input.frame.minY)
            capture(dark ? "dark-send-scroll-settled" : "light-send-scroll-settled", app: app)
            input.tap(); input.typeText("Second send still works")
            app.buttons["送信する"].tap()
            XCTAssertTrue(app.staticTexts["Second send still works"].waitForExistence(timeout: 4))
            XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 6))
            reading.swipeDown(); reading.swipeDown()
            XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 4))
            XCTAssertTrue(app.buttons["chat-jump-latest"].isHittable)
            app.buttons["chat-jump-latest"].tap()
            capture(dark ? "dark-second-send-responsive" : "light-second-send-responsive", app: app)
            app.terminate()
        }
    }

    @MainActor func testGenerationSettingsCancelSaveAndPromptPersist() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--reset-settings"]
        app.launch()
        openConfiguration(app)
        let topK = app.textFields["setting-TopK"]
        revealConfigurationControl(topK, app: app)
        XCTAssertTrue(app.staticTexts["setting-help-TopK"].exists)
        XCTAssertEqual(topK.value as? String, "40")
        replace(topK, with: "12")
        app.buttons["キャンセル"].tap()
        app.buttons["model-generation-settings"].tap()
        XCTAssertTrue(topK.waitForExistence(timeout: 3))
        XCTAssertEqual(topK.value as? String, "40", "Cancel must discard draft settings")
        revealConfigurationControl(topK, app: app)
        replace(topK, with: "12")
        let cpu = app.segmentedControls["execution-backend"].buttons["CPU"]
        revealConfigurationControl(cpu, app: app)
        cpu.tap()
        XCTAssertTrue(cpu.isSelected, "CPU must be selected before saving")
        let thinking = app.switches["enable-thinking"]
        let speculation = app.switches["enable-speculation"]
        revealConfigurationControl(thinking, app: app)
        XCTAssertTrue(thinking.isEnabled)
        XCTAssertTrue(app.staticTexts["setting-help-enable-thinking"].exists)
        // SwiftUI exposes the labeled row as the switch's accessibility frame.
        // Tap the visible switch at the trailing edge rather than its label.
        thinking.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(thinking.value as? String, "1")
        revealConfigurationControl(speculation, app: app)
        XCTAssertTrue(speculation.isEnabled)
        XCTAssertTrue(app.staticTexts["setting-help-enable-speculation"].exists)
        speculation.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(speculation.value as? String, "1")
        capture("model-configuration-controls", app: app)
        app.segmentedControls.buttons["システムプロンプト"].tap()
        let prompt = app.textViews["system-prompt-input"]
        XCTAssertTrue(prompt.waitForExistence(timeout: 3))
        replace(prompt, with: "Reply briefly in Japanese.")
        capture("custom-system-prompt", app: app)
        app.buttons["configuration-save"].tap()
        app.buttons["model-generation-settings"].tap()
        XCTAssertTrue(topK.waitForExistence(timeout: 3))
        XCTAssertEqual(topK.value as? String, "12")
        app.segmentedControls.buttons["システムプロンプト"].tap()
        XCTAssertEqual(prompt.value as? String, "Reply briefly in Japanese.")
        app.buttons["configuration-save"].tap()
        app.terminate()
        app.launchArguments = []
        app.launch()
        openConfiguration(app)
        XCTAssertEqual(topK.value as? String, "12", "Saved model configuration must survive relaunch")
        capture("saved-model-configuration", app: app)
        revealConfigurationControl(cpu, app: app)
        XCTAssertTrue(cpu.isSelected)
        revealConfigurationControl(thinking, app: app)
        XCTAssertEqual(thinking.value as? String, "1")
        revealConfigurationControl(speculation, app: app)
        XCTAssertEqual(speculation.value as? String, "1")
        app.segmentedControls.buttons["システムプロンプト"].tap()
        XCTAssertEqual(prompt.value as? String, "Reply briefly in Japanese.")
    }

    @MainActor func testImagePdfTextImportsPreviewAndArchiveRestore() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--attachment-fixtures"]
        app.launch()
        importFixture("sample-image", extension: "png", app: app)
        importFixture("sample-document", extension: "pdf", app: app)
        app.buttons["添付ファイルを開く: sample-document.pdf"].tap()
        XCTAssertTrue(app.navigationBars["sample-document.pdf"].waitForExistence(timeout: 4))
        capture("pdf-preview", app: app)
        app.buttons["完了"].tap()
        importFixture("sample-text", extension: "txt", app: app)
        capture("image-and-files-ready", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["添付の読み込み確認: 画像1枚・本文: PDF fixture content・本文: 日本語の添付テスト😊"].waitForExistence(timeout: 6))
        capture("image-and-files-sent", app: app)
        app.terminate()
        app.launchArguments = ["--attachment-fixtures", "--restore-fixture-chat"]
        app.launch()
        XCTAssertTrue(app.buttons["添付ファイルを開く: sample-document.pdf"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.buttons["添付ファイルを開く: sample-text.txt"].exists)
        capture("attachment-archive-restored", app: app)
        app.buttons["chat-add-menu"].tap()
        chooseMenuAction("sample-unsupported", app: app)
        XCTAssertTrue(app.alerts["お知らせ"].waitForExistence(timeout: 4))
        app.alerts.buttons["閉じる"].tap()
        XCTAssertFalse(app.otherElements["draft-attachments"].exists)
        importFixture("sample-sjis", extension: "txt", app: app)
        importFixture("sample-utf16", extension: "txt", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["添付の読み込み確認: 本文: 日本語の添付確認・本文: 日本語UTF16😊"].waitForExistence(timeout: 6))
    }

    @MainActor func testVideoImportSamplesThreeScenesAndDraftRemoval() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--attachment-fixtures", "--dark"]
        app.launch()
        importFixture("sample-video", extension: "mp4", app: app)
        capture("video-draft", app: app)
        app.buttons["添付を外す: sample-video.mp4"].tap()
        XCTAssertFalse(app.buttons["添付ファイルを開く: sample-video.mp4"].exists)
        importFixture("sample-video", extension: "mp4", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["添付の読み込み確認: 動画3場面"].waitForExistence(timeout: 6))
        XCTAssertTrue(app.staticTexts["動画は開始・中間・終了付近の3場面を読み込みます。音声は解析しません。"].exists)
        capture("video-three-scenes-sent", app: app)
    }

    @MainActor private func importFixture(_ name: String, extension suffix: String, app: XCUIApplication) {
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap()
        chooseMenuAction(name, app: app)
        XCTAssertTrue(app.buttons["添付ファイルを開く: \(name).\(suffix)"].waitForExistence(timeout: 8))
    }

    @MainActor private func chooseMenuAction(_ name: String, app: XCUIApplication) {
        let button = app.buttons[name]
        XCTAssertTrue(button.waitForExistence(timeout: 3))
        let panel = app.scrollViews["chat-action-panel"]
        for _ in 0..<6 {
            if button.isHittable { break }
            panel.swipeUp()
        }
        XCTAssertTrue(button.isHittable); button.tap()
    }

    @MainActor private func openConfiguration(_ app: XCUIApplication) {
        XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(app.buttons["model-generation-settings"].waitForExistence(timeout: 3))
        app.buttons["model-generation-settings"].tap()
        XCTAssertTrue(app.textFields["setting-Max Tokens"].waitForExistence(timeout: 3))
    }

    @MainActor private func replace(_ field: XCUIElement, with text: String) {
        field.tap()
        // Place the caret after the last line, including a multi-line editor.
        field.coordinate(withNormalizedOffset: CGVector(dx: 0.95, dy: 0.9)).tap()
        let old = field.value as? String ?? ""
        field.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: old.count) + text)
    }

    @MainActor private func revealConfigurationControl(_ control: XCUIElement, app: XCUIApplication) {
        let form = app.collectionViews["generation-configuration"]
        XCTAssertTrue(form.waitForExistence(timeout: 3))
        for _ in 0..<12 {
            let bounds = form.frame
            let keyboard = app.keyboards.firstMatch
            let bottom = min(bounds.maxY, keyboard.exists ? keyboard.frame.minY : app.frame.maxY) - 16
            if control.exists && control.isHittable && control.frame.minY >= bounds.minY + 8 && control.frame.maxY <= bottom { return }
            // SwiftUI can report offscreen segmented buttons as hittable. Drag the
            // visible Form gutter above the keyboard instead of swiping the app.
            let height = max(1, bottom - bounds.minY)
            let start = form.coordinate(withNormalizedOffset: .zero).withOffset(CGVector(dx: 8, dy: height * 0.8))
            let end = form.coordinate(withNormalizedOffset: .zero).withOffset(CGVector(dx: 8, dy: height * 0.15))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        XCTFail("Configuration control must be fully visible before interaction: \(control.identifier)")
    }

    @MainActor private func capture(_ name: String, app: XCUIApplication) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
