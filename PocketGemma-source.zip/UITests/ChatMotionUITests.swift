import XCTest

final class ChatMotionUITests: XCTestCase {
    @MainActor func testMenuSendAndInteractiveBack() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--gesture-diagnostics"]
        app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        XCTAssertEqual(menu.frame.height, 44, accuracy: 1)
        XCTAssertEqual(menu.frame.width, 44, accuracy: 1)
        let controlHeight = menu.frame.height
        menu.tap()
        capture("after-plus-tap", app: app)
        XCTAssertTrue(app.buttons["新しい会話"].waitForExistence(timeout: 3))
        capture("expanded-menu", app: app)
        app.buttons["新しい会話"].tap()
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        XCTAssertTrue(input.waitForExistence(timeout: 3))
        input.tap()
        input.typeText("Animation check")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["Animation check"].waitForExistence(timeout: 3))
        XCTAssertTrue(app.staticTexts["プレビュー用の返信です。入力欄・吹き出し・スクロールを確認できます。"].waitForExistence(timeout: 5))
        capture("sent-message-keyboard", app: app)
        app.buttons["会話一覧を開く"].tap()
        XCTAssertTrue(app.navigationBars["メッセージ"].waitForExistence(timeout: 4))
        app.buttons["会話を開く: Animation check"].tap()
        XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 3))
        let edge = app.coordinate(withNormalizedOffset: CGVector(dx: 0.015, dy: 0.45))
        let end = app.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.45))
        edge.press(forDuration: 0.1, thenDragTo: end)
        capture("after-edge-swipe", app: app)
        XCTAssertTrue(app.navigationBars["メッセージ"].waitForExistence(timeout: 4))
        capture("conversation-list", app: app)
        XCTAssertEqual(app.buttons["history-compose"].frame.height, controlHeight, accuracy: 1)
    }

    @MainActor func testLongConversationJumpControlAndHeader() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--long-chat"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        capture("long-chat-latest", app: app)
        let reading = app.scrollViews["chat-conversation"]
        XCTAssertTrue(reading.waitForExistence(timeout: 3))
        reading.swipeDown()
        reading.swipeDown()
        let jump = app.buttons["chat-jump-latest"]
        XCTAssertTrue(jump.waitForExistence(timeout: 3))
        XCTAssertEqual(jump.frame.height, 44, accuracy: 1)
        XCTAssertLessThan(jump.frame.maxY, app.buttons["chat-add-menu"].frame.minY)
        capture("jump-from-composer", app: app)
        jump.tap()
        let disappeared = NSPredicate(format: "exists == false")
        expectation(for: disappeared, evaluatedWith: jump)
        waitForExpectations(timeout: 4)
        capture("jump-returned-to-latest", app: app)
        // Selectable reply text is reading content, not a tappable control.
        // Check its actual viewport bounds rather than XCTest's hit point.
        let latest = app.staticTexts["最新の返信です。ここまで戻りました。"].firstMatch
        XCTAssertTrue(latest.exists)
        XCTAssertGreaterThan(latest.frame.width, 0)
        XCTAssertGreaterThan(latest.frame.height, 0)
        XCTAssertGreaterThanOrEqual(latest.frame.minY, reading.frame.minY)
        XCTAssertLessThanOrEqual(latest.frame.maxY, app.buttons["chat-add-menu"].frame.minY)
    }

    @MainActor func testStreamingReplyRemainsReadableAndFinishes() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--slow-reply"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap()
        input.typeText("Text animation")
        app.buttons["送信する"].tap()
        let partial = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "新しい文字が")).firstMatch
        XCTAssertTrue(partial.waitForExistence(timeout: 5))
        capture("reply-revealing", app: app)
        let finished = app.staticTexts["新しい文字がぼやけた状態から少しずつくっきり表示されます。\nすでに読んだ文章は鮮明なままです。日本語と絵文字もそのまま表示します。😊"]
        XCTAssertTrue(finished.waitForExistence(timeout: 8))
        expectation(for: NSPredicate(format: "exists == false"),
                    evaluatedWith: app.buttons["回答を停止する"])
        waitForExpectations(timeout: 3)
        capture("reply-fully-clear", app: app)
        XCTAssertTrue(app.staticTexts["Text animation"].exists)
    }

    @MainActor func testDarkModeWithReducedMotion() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--dark", "--reduce-motion", "--long-chat"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap()
        capture("dark-after-plus-tap", app: app)
        XCTAssertTrue(app.buttons["モデルと設定"].waitForExistence(timeout: 3))
        capture("dark-reduced-motion-menu", app: app)
        app.buttons["メニューを閉じる"].tap()
        XCTAssertTrue(app.buttons["会話の操作を開く"].waitForExistence(timeout: 3))
        let reading = app.scrollViews["chat-conversation"]
        reading.swipeDown()
        reading.swipeDown()
        XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 3))
        capture("dark-glass-scrolling", app: app)
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap()
        input.typeText("Glass check")
        XCTAssertTrue(app.buttons["送信する"].isHittable)
        capture("dark-glass-keyboard", app: app)
    }

    @MainActor func testModelCatalogSwitchPreservesGemmaHistory() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launch()
        XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(app.navigationBars["モデルと設定"].waitForExistence(timeout: 3))
        capture("model-catalog", app: app)
        let use = app.buttons["model-use-qwen3-06b"]
        for _ in 0..<3 {
            if use.isHittable { break }
            app.scrollViews["model-list"].swipeUp()
        }
        XCTAssertTrue(use.isHittable)
        capture("model-qwen-ready", app: app)
        use.tap()
        XCTAssertTrue(app.staticTexts["Qwen3 0.6B"].waitForExistence(timeout: 4))
        XCTAssertFalse(app.staticTexts["画面の動きを確認"].exists)
        capture("qwen-new-chat", app: app)
        app.buttons["会話一覧を開く"].tap()
        XCTAssertTrue(app.navigationBars["メッセージ"].waitForExistence(timeout: 3))
        app.buttons["会話を開く: 画面の動きを確認"].tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E4B"].waitForExistence(timeout: 3))
        XCTAssertTrue(app.staticTexts["画面の動きを確認"].exists)
        capture("gemma-history-preserved", app: app)
    }

    @MainActor func testTallReplyBubbleAndFeatheredChrome() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--tall-bubble"]
        app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        XCTAssertTrue(app.buttons["chat-model-settings"].isHittable)
        capture("tall-bubble-bottom", app: app)
        let reading = app.scrollViews["chat-conversation"]
        reading.swipeDown()
        capture("light-feathered-chrome", app: app)
        menu.tap()
        XCTAssertTrue(app.buttons["新しい会話"].waitForExistence(timeout: 3))
        capture("light-feathered-menu", app: app)
        app.buttons["メニューを閉じる"].tap()
        XCTAssertTrue(app.buttons["会話の操作を開く"].waitForExistence(timeout: 3))
        let greeting = app.staticTexts["こんにちは"].firstMatch
        for _ in 0..<10 {
            if greeting.exists && greeting.frame.minY >= reading.frame.minY
                && greeting.frame.maxY < menu.frame.minY { break }
            reading.swipeDown()
        }
        XCTAssertTrue(greeting.exists)
        XCTAssertGreaterThan(greeting.frame.width, 0)
        XCTAssertLessThan(greeting.frame.width, reading.frame.width * 0.75)
        capture("short-bubble-shapes", app: app)
    }

    @MainActor private func capture(_ name: String, app: XCUIApplication) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
