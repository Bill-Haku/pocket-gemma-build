# Pocket Gemma

iPhoneで対応するローカルAIモデルを使う、SwiftUIのチャットアプリです。

## AltStore用IPAのビルド

Actionsの **Build iPhone app** を手動実行します。標準のmacOSランナーで
コアテスト・UI操作テストを実行し、unsigned iPhone IPAを作成します。
成功した実行の **PocketGemma-AltStore** 成果物にIPAが含まれます。
署名とインストールはAltStore側で行います。成果物の保存期間は1日です。

## ソース

`PocketGemma-source.zip` にSwiftソース、ビルド設定、アセット、テストが
入っています。ワークフローはZIPを展開してからビルドします。
モデル本体・ユーザーの会話履歴・写真・署名証明書は含みません。
UI操作テストはサンプルの会話で実行し、実際のAI推論とは別に検証します。

必要環境は、対応するmacOSとXcode 26以降、XcodeGenです。
ZIPを展開したMacでは `brew install xcodegen` と
`bash scripts/build-ios.sh` でunsigned IPAを作成できます。

詳細は `docs/PUBLIC-BUILD.md` を参照してください。

変更と添付の対応範囲は `docs/1.0.8.md` に記載しています。

変更と添付の対応範囲は `docs/1.0.9.md` に記載しています。

1.0.10候補の変更と検証範囲は `docs/UPDATE-1.0.10.md` に記載しています。

1.0.11候補の画像推論の調査は docs/VISION-INVESTIGATION.md に記載しています。実機未検証です。

1.0.12: 言語と画像のCPU/GPUを個別に設定できます。画像の初期設定はCPU。比較診断とネイティブバイナリ照合を追加しました。実機のGPU/CPU構成は未検証です。docs/UPDATE-1.0.12.md を参照してください。
