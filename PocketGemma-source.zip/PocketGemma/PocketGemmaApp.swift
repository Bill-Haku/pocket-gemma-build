import SwiftUI
import UIKit

final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String,
                     completionHandler: @escaping () -> Void) {
        ModelStore.shared.attachBackgroundCompletion(completionHandler)
    }
}

@main
struct PocketGemmaApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var delegate
    @StateObject private var chats = ChatStore()
    @StateObject private var model = ModelStore.shared
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ChatNavigationView()
                .environmentObject(chats)
                .environmentObject(model)
                .onChange(of: scenePhase) { _, phase in
                    if phase == .background { chats.didEnterBackground() }
                }
                .onReceive(NotificationCenter.default.publisher(for: UIApplication.didReceiveMemoryWarningNotification)) { _ in
                    chats.releaseModelMemory()
                }
        }
    }
}
