import Foundation
import PocketCore

enum AppFiles {
    static var root: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("PocketGemma", isDirectory: true)
    }
    static var models: URL { root.appendingPathComponent("Models", isDirectory: true) }
    static var library: ModelLibrary { ModelLibrary(directory: models) }
    static func model(_ spec: ModelSpec) -> URL { library.modelURL(spec) }
    static func pendingModel(_ spec: ModelSpec) -> URL { library.pendingURL(spec) }
    static var archive: URL { root.appendingPathComponent("conversations.json") }

    static func prepareModels() throws {
        try FileManager.default.createDirectory(at: models, withIntermediateDirectories: true)
        var url = models
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        try url.setResourceValues(values)
    }

    static func hasVerifiedModel(_ spec: ModelSpec) -> Bool { library.isInstalled(spec) }
    static func installVerifiedModel(_ spec: ModelSpec) throws { try library.installValidated(spec) }
}

