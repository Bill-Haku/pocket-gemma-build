import Foundation
import LiteRTLM
import PocketCore
import os
import ImageIO

actor GemmaService {
    private var engine: Engine?
    private var enginePlan: InferenceEnginePlan?
    private var rebuildRequired = false
    private var diagnostic: InferenceDiagnostic?
    private var conversation: Conversation?
    private var running = false
    private var cancelRequested = false
    private var context = ConversationContext()
    private var conversationSettings: GenerationSettings?

    enum Stage: String, Sendable {
        case loading = "モデルを読み込んでいます…"
        case preparing = "会話を準備しています…"
        case waiting = "返信を考えています…"
    }

    func generate(threadID: UUID, prompt: String, history: [ChatMessage], model spec: ModelSpec,
                  settings: GenerationSettings, attachments: [ChatAttachment],
                  onStage: @escaping @Sendable (Stage) async -> Void,
                  onText: @escaping @Sendable (String) async -> Void) async throws {
        guard !running else { throw ServiceError.busy }
        running = true
        cancelRequested = false
        defer {
            running = false
        }
        let settings = settings.normalized(for: spec)
        let images = (attachments + history.flatMap(\.media)).reduce(0) { $0 + $1.imageNames.count }
        let plan = InferenceEnginePlan(model: spec, settings: settings, needsVision: images > 0)
        diagnostic = InferenceDiagnostic(plan: plan, imageCount: images, settings: settings, previous: diagnostic)
        diagnostic?.inputPath = "application_attachment_image_file"
        diagnostic?.inputImageDimensions = (attachments + history.flatMap(\.media)).flatMap(\.imageNames).prefix(4).compactMap { name in
            guard let url = AttachmentStorage.url(name), let source = CGImageSourceCreateWithURL(url as CFURL, nil),
                  let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any],
                  let width = properties[kCGImagePropertyPixelWidth] as? Int,
                  let height = properties[kCGImagePropertyPixelHeight] as? Int else { return nil }
            return "\(width)x\(height)"
        }
        diagnostic?.advance("validation")
        let nativeLog = NativeLogCapture(includeInfo: images > 0)
        let memory = InferenceMemoryCapture()
        defer { _ = nativeLog?.finish() }
        do {
            try await perform(threadID: threadID, prompt: prompt, history: history, model: spec,
                settings: settings, attachments: attachments, plan: plan, onStage: onStage, onText: onText)
            diagnostic?.result = "success"
            diagnostic?.recordNativeLog(nativeLog?.finish())
            diagnostic?.recordMemory(memory.finish())
            diagnostic?.advance("complete")
        } catch {
            context.invalidate()
            // Keep native objects alive through the final C callback; release
            // them on the next request, outside that callback's stack.
            rebuildRequired = true
            diagnostic?.result = error is CancellationError || cancelRequested ? "cancelled" : "failed"
            diagnostic?.failureKind = NativeFailureKind(description: error.localizedDescription)
            let nativeError = InferenceDiagnostic.sanitize(error.localizedDescription)
            diagnostic?.nativeError = nativeError
            diagnostic?.recordNativeLog(nativeLog?.finish(), error: nativeError)
            diagnostic?.recordMemory(memory.finish())
            diagnostic?.availableMemoryAtFailure = UInt64(os_proc_available_memory())
            diagnostic?.save()
            if error is CancellationError || cancelRequested { throw CancellationError() }
            throw InferenceFailure(stage: diagnostic?.stage ?? "unknown", cause: error)
        }
    }

    private func perform(threadID: UUID, prompt: String, history: [ChatMessage], model spec: ModelSpec,
                         settings: GenerationSettings, attachments: [ChatAttachment], plan: InferenceEnginePlan,
                         onStage: @escaping @Sendable (Stage) async -> Void,
                         onText: @escaping @Sendable (String) async -> Void) async throws {
        guard AppFiles.hasVerifiedModel(spec) else { throw ServiceError.modelMissing }
        let needsVision = plan.visionBackend != nil
        diagnostic?.engineWasReused = engine != nil && enginePlan == plan && !rebuildRequired
        if needsVision && !spec.supportsVision { throw ServiceError.visionUnsupported }
        if engine == nil || enginePlan != plan || rebuildRequired {
            await onStage(.loading)
            conversation = nil
            context.invalidate()
            engine = nil
            enginePlan = nil
            if spec.isExperimental {
                let device = await MainActor.run { DeviceOverview.capacity }
                guard !ModelRecommendation.fit(spec, device: device, isInstalled: true).memoryIsTight else {
                    throw ServiceError.insufficientMemory
                }
            }
            let cache = AppFiles.root.appendingPathComponent("InferenceCache", isDirectory: true)
                .appendingPathComponent(plan.cacheComponent, isDirectory: true)
            try FileManager.default.createDirectory(at: cache, withIntermediateDirectories: true)
            let config = try EngineConfig(modelPath: AppFiles.model(spec).path,
                backend: plan.backend == .gpu ? .gpu : .cpu(),
                visionBackend: plan.visionBackend.map { $0 == .gpu ? .gpu : .cpu() },
                maxNumTokens: settings.maxTokens, cacheDir: cache.path)
            let newEngine = Engine(engineConfig: config)
            // The app has one inference service and serializes its requests.
            // These SDK flags are process-global and must be set before the
            // Engine actor allocates encoder/adapter signatures, not just on
            // ConversationConfig. Clearing nil on text turns avoids inheritance.
            ExperimentalFlags.optIntoExperimentalAPIs()
            ExperimentalFlags.visualTokenBudget = plan.visualTokenBudget.map(Int32.init)
            ExperimentalFlags.enableSpeculativeDecoding = plan.speculativeDecoding
            diagnostic?.advance("engine_initialization")
            // The SDK owns a separate Engine actor. Await it so this service
            // can still receive stop/timeout requests during initialization.
            try await newEngine.initialize()
            if cancelRequested { throw CancellationError() }
            engine = newEngine
            enginePlan = plan
            rebuildRequired = false
            conversationSettings = nil
        }
        guard let engine else { throw ServiceError.modelMissing }
        if cancelRequested { throw CancellationError() }
        var reuse = false
        if let conversation, conversationSettings == settings, context.canReuse(threadID: threadID, history: history) {
            reuse = try conversation.getTokenCount() < settings.maxTokens - settings.maxOutputTokens - settings.reservedTokens
        }
        if !reuse {
            await onStage(.preparing)
            diagnostic?.advance("conversation_creation")
            // The previous completed stream's conversation stays alive between
            // turns. Release it here, rather than inside its final C callback.
            conversation = nil
            context.invalidate()
            let initialMessages = try history.map { message in
                try nativeMessage(text: message.text, attachments: message.media,
                                  role: message.role == .user ? .user : .model)
            }
            let config = ConversationConfig(
                systemMessage: Message(settings.systemPrompt, role: .system),
                initialMessages: initialMessages,
                samplerConfig: try SamplerConfig(topK: settings.topK, topP: Float(settings.topP), temperature: Float(settings.temperature)),
                thinkingConfig: ThinkingConfig(enableThinking: settings.enableThinking,
                    thinkingTokenBudget: settings.enableThinking ? min(1024, settings.maxOutputTokens / 2) : 0),
                automaticToolCalling: false, visualTokenBudget: Int32(settings.visualTokenBudget),
                enableSpeculativeDecoding: settings.enableSpeculativeDecoding)
            conversation = try await engine.createConversation(with: config)
            conversationSettings = settings
        }
        diagnostic?.conversationWasReused = reuse
        guard let active = conversation else { throw ServiceError.modelMissing }
        if cancelRequested { throw CancellationError() }
        await onStage(.waiting)
        diagnostic?.advance(needsVision ? "image_prefill" : "text_generation")
        var reply = ""
        // The SDK starts inference synchronously, so keep startup off this actor.
        do {
            let message = try nativeMessage(text: prompt, attachments: attachments)
            let stream = await Task.detached(priority: .userInitiated) {
                active.sendMessageStream(message, maxOutputTokens: settings.maxOutputTokens)
            }.value
            for try await chunk in stream {
                // Drain the native stream after cancellation, keeping the engine
                // alive until its final callback before permitting another request.
                if cancelRequested { continue }
                let text = chunk.toString
                if !text.isEmpty {
                    if reply.isEmpty { diagnostic?.advance("decode") }
                    reply += text
                    await onText(text)
                }
            }
            if cancelRequested { throw CancellationError() }
            guard !reply.isEmpty else { throw ServiceError.emptyReply }
            context.completeTurn(threadID: threadID, history: history, prompt: prompt, reply: reply, attachments: attachments)
        } catch {
            context.invalidate()
            try? active.cancel()
            throw error
        }
    }

    private func nativeMessage(text: String, attachments: [ChatAttachment], role: Role = .user) throws -> Message {
        var contents: [Content] = []
        for attachment in attachments {
            if let body = attachment.extractedText {
                contents.append(.text("\n添付ファイル: \(attachment.name)\n以下はファイルの内容です。\n\(body)"))
            }
            if attachment.kind == .video {
                contents.append(.text("\n動画 \(attachment.name) の開始・中間・終了付近の代表フレームです。音声は含みません。"))
            }
            for name in attachment.imageNames {
                guard let url = AttachmentStorage.url(name), FileManager.default.fileExists(atPath: url.path) else { throw ServiceError.attachmentMissing }
                contents.append(.imageFile(url.path))
            }
        }
        contents.append(.text(text))
        return Message(contents: contents, role: role)
    }

    func cancel() {
        guard running else { return }
        cancelRequested = true
        context.invalidate()
        try? conversation?.cancel()
    }

    func runVisionProbe(model: ModelSpec, kind: VisionProbeKind, main: ExecutionBackend,
                        vision: ExecutionBackend) async throws -> String {
        guard !running else { throw ServiceError.busy }
        // Release the chat's language engine before the component-only test.
        // The next normal message rebuilds the original saved configuration.
        unload()
        running = true
        defer { running = false }
        return try await VisionDiagnosticRunner.run(model: model, kind: kind, main: main, vision: vision)
    }

    func unload() {
        guard !running else { return }
        conversation = nil
        context.invalidate()
        engine = nil
        enginePlan = nil
        rebuildRequired = false
        conversationSettings = nil
    }
}

private struct InferenceFailure: LocalizedError {
    let stage: String
    let cause: Error
    var errorDescription: String? {
        "処理段階: \(stage)\n\(cause.localizedDescription)"
    }
}

private enum ServiceError: LocalizedError {
    case busy, modelMissing, visionUnsupported, attachmentMissing, insufficientMemory, emptyReply
    var errorDescription: String? {
        switch self {
        case .busy: return "前の回答が終了するまでお待ちください。"
        case .modelMissing: return "この会話のモデルをダウンロードするか、対応するファイルを取り込んでください。"
        case .visionUnsupported: return "このモデルは画像・動画に対応していません。Gemma 4を選んでください。"
        case .attachmentMissing: return "保存した添付ファイルが見つかりません。もう一度添付してください。"
        case .insufficientMemory: return "Gemma 4 12Bを安全に動かすメモリの余裕がありません。モデルと設定から、この端末に合うモデルを自動選択してください。"
        case .emptyReply: return "推論は終了しましたが、モデルからテキスト回答が届きませんでした。"
        }
    }
}

