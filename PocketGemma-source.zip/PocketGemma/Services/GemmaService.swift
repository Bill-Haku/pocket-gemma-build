import Foundation
import LiteRTLM
import PocketCore

actor GemmaService {
    private var engine: Engine?
    private var backend: ExecutionBackend?
    private var modelID: String?
    private var conversation: Conversation?
    private var running = false
    private var cancelRequested = false
    private var context = ConversationContext()
    private var engineTokenLimit = 0
    private var visionEnabled = false
    private var conversationSettings: GenerationSettings?

    enum Stage: String, Sendable {
        case loading = "モデルを読み込んでいます…"
        case preparing = "会話を準備しています…"
        case waiting = "返信を考えています…"
    }

    func generate(threadID: UUID, prompt: String, history: [ChatMessage], model spec: ModelSpec,
                  settings: GenerationSettings, attachments: [ChatAttachment],
                  onStage: @escaping @Sendable (Stage) async -> Void,
                  onText: @escaping @Sendable (String) async -> Void) async throws {
        guard !running else { throw ServiceError.busy }
        running = true
        cancelRequested = false
        defer {
            running = false
        }
        guard AppFiles.hasVerifiedModel(spec) else { throw ServiceError.modelMissing }
        let requestedBackend = settings.backend
        let needsVision = (attachments + history.flatMap(\.media)).contains { !$0.imageNames.isEmpty }
        if needsVision && !spec.supportsVision { throw ServiceError.visionUnsupported }
        if engine == nil || backend != requestedBackend || modelID != spec.id
            || engineTokenLimit != settings.maxTokens || needsVision != visionEnabled {
            await onStage(.loading)
            conversation = nil
            context.invalidate()
            engine = nil
            let cache = AppFiles.root.appendingPathComponent("InferenceCache", isDirectory: true)
                .appendingPathComponent(spec.id, isDirectory: true)
            try FileManager.default.createDirectory(at: cache, withIntermediateDirectories: true)
            let config = try EngineConfig(modelPath: AppFiles.model(spec).path,
                backend: requestedBackend == .gpu ? .gpu : .cpu(),
                visionBackend: needsVision ? .cpu() : nil,
                maxNumTokens: settings.maxTokens, cacheDir: cache.path)
            let newEngine = Engine(engineConfig: config)
            // The SDK owns a separate Engine actor. Await it so this service
            // can still receive stop/timeout requests during initialization.
            try await newEngine.initialize()
            if cancelRequested { throw CancellationError() }
            engine = newEngine
            backend = requestedBackend
            modelID = spec.id
            engineTokenLimit = settings.maxTokens
            visionEnabled = needsVision
            conversationSettings = nil
        }
        guard let engine else { throw ServiceError.modelMissing }
        if cancelRequested { throw CancellationError() }
        var reuse = false
        if let conversation, conversationSettings == settings, context.canReuse(threadID: threadID, history: history) {
            reuse = try conversation.getTokenCount() < settings.maxTokens - settings.maxOutputTokens - settings.reservedTokens
        }
        if !reuse {
            await onStage(.preparing)
            // The previous completed stream's conversation stays alive between
            // turns. Release it here, rather than inside its final C callback.
            conversation = nil
            context.invalidate()
            let initialMessages = try history.map { message in
                try nativeMessage(text: message.text, attachments: message.media,
                                  role: message.role == .user ? .user : .model)
            }
            let config = ConversationConfig(
                systemMessage: Message(settings.systemPrompt, role: .system),
                initialMessages: initialMessages,
                samplerConfig: try SamplerConfig(topK: settings.topK, topP: Float(settings.topP), temperature: Float(settings.temperature)),
                thinkingConfig: ThinkingConfig(enableThinking: settings.enableThinking,
                    thinkingTokenBudget: settings.enableThinking ? min(1024, settings.maxOutputTokens / 2) : 0),
                automaticToolCalling: false, visualTokenBudget: Int32(settings.visualTokenBudget),
                enableSpeculativeDecoding: settings.enableSpeculativeDecoding)
            conversation = try await engine.createConversation(with: config)
            conversationSettings = settings
        }
        guard let active = conversation else { throw ServiceError.modelMissing }
        if cancelRequested { throw CancellationError() }
        await onStage(.waiting)
        var reply = ""
        // The SDK starts inference synchronously, so keep startup off this actor.
        do {
            let message = try nativeMessage(text: prompt, attachments: attachments)
            let stream = await Task.detached(priority: .userInitiated) {
                active.sendMessageStream(message, maxOutputTokens: settings.maxOutputTokens)
            }.value
            for try await chunk in stream {
                // Drain the native stream after cancellation, keeping the engine
                // alive until its final callback before permitting another request.
                if cancelRequested { continue }
                let text = chunk.toString
                if !text.isEmpty {
                    reply += text
                    await onText(text)
                }
            }
            if cancelRequested { throw CancellationError() }
            if reply.isEmpty { context.invalidate() }
            else { context.completeTurn(threadID: threadID, history: history, prompt: prompt, reply: reply, attachments: attachments) }
        } catch {
            context.invalidate()
            try? active.cancel()
            throw error
        }
    }

    private func nativeMessage(text: String, attachments: [ChatAttachment], role: Role = .user) throws -> Message {
        var contents: [Content] = [.text(text)]
        for attachment in attachments {
            if let body = attachment.extractedText {
                contents.append(.text("\n添付ファイル: \(attachment.name)\n以下はファイルの内容です。\n\(body)"))
            }
            if attachment.kind == .video {
                contents.append(.text("\n動画 \(attachment.name) の開始・中間・終了付近の代表フレームです。音声は含みません。"))
            }
            for name in attachment.imageNames {
                guard let url = AttachmentStorage.url(name), FileManager.default.fileExists(atPath: url.path) else { throw ServiceError.attachmentMissing }
                contents.append(.imageFile(url.path))
            }
        }
        return Message(contents: contents, role: role)
    }

    func cancel() {
        guard running else { return }
        cancelRequested = true
        context.invalidate()
        try? conversation?.cancel()
    }

    func unload() {
        guard !running else { return }
        conversation = nil
        context.invalidate()
        engine = nil
        backend = nil
        modelID = nil
        conversationSettings = nil
    }
}

private enum ServiceError: LocalizedError {
    case busy, modelMissing, visionUnsupported, attachmentMissing
    var errorDescription: String? {
        switch self {
        case .busy: return "前の回答が終了するまでお待ちください。"
        case .modelMissing: return "この会話のモデルをダウンロードするか、対応するファイルを取り込んでください。"
        case .visionUnsupported: return "このモデルは画像・動画に対応していません。Gemma 4を選んでください。"
        case .attachmentMissing: return "保存した添付ファイルが見つかりません。もう一度添付してください。"
        }
    }
}

