import Foundation
import LiteRTLM
import PocketCore

enum ExecutionBackend: String, CaseIterable, Identifiable, Sendable {
    case gpu = "GPU", cpu = "CPU"
    var id: String { rawValue }
}

actor GemmaService {
    private var engine: Engine?
    private var backend: ExecutionBackend?
    private var modelID: String?
    private var conversation: Conversation?
    private var running = false
    private var cancelRequested = false
    private var context = ConversationContext()

    enum Stage: String, Sendable {
        case loading = "モデルを読み込んでいます…"
        case preparing = "会話を準備しています…"
        case waiting = "返信を考えています…"
    }

    func generate(threadID: UUID, prompt: String, history: [ChatMessage], model spec: ModelSpec,
                  backend requestedBackend: ExecutionBackend,
                  onStage: @escaping @Sendable (Stage) async -> Void,
                  onText: @escaping @Sendable (String) async -> Void) async throws {
        guard !running else { throw ServiceError.busy }
        running = true
        cancelRequested = false
        defer {
            running = false
        }
        guard AppFiles.hasVerifiedModel(spec) else { throw ServiceError.modelMissing }
        if engine == nil || backend != requestedBackend || modelID != spec.id {
            await onStage(.loading)
            conversation = nil
            context.invalidate()
            engine = nil
            let cache = AppFiles.root.appendingPathComponent("InferenceCache", isDirectory: true)
                .appendingPathComponent(spec.id, isDirectory: true)
            try FileManager.default.createDirectory(at: cache, withIntermediateDirectories: true)
            let config = try EngineConfig(modelPath: AppFiles.model(spec).path,
                backend: requestedBackend == .gpu ? .gpu : .cpu(),
                maxNumTokens: 4096, cacheDir: cache.path)
            let newEngine = Engine(engineConfig: config)
            // The SDK owns a separate Engine actor. Await it so this service
            // can still receive stop/timeout requests during initialization.
            try await newEngine.initialize()
            if cancelRequested { throw CancellationError() }
            engine = newEngine
            backend = requestedBackend
            modelID = spec.id
        }
        guard let engine else { throw ServiceError.modelMissing }
        if cancelRequested { throw CancellationError() }
        var reuse = false
        if let conversation, context.canReuse(threadID: threadID, history: history) {
            reuse = try conversation.getTokenCount() < 2800
        }
        if !reuse {
            await onStage(.preparing)
            // The previous completed stream's conversation stays alive between
            // turns. Release it here, rather than inside its final C callback.
            conversation = nil
            context.invalidate()
            let initialMessages = history.map { message in
                Message(message.text, role: message.role == .user ? .user : .model)
            }
            let config = ConversationConfig(
                systemMessage: Message("あなたは親切で率直なアシスタントです。ユーザーと同じ言語で、わかりやすく回答してください。"),
                initialMessages: initialMessages,
                samplerConfig: try SamplerConfig(topK: 40, topP: 0.95, temperature: 0.7),
                thinkingConfig: ThinkingConfig(enableThinking: false, thinkingTokenBudget: 0),
                automaticToolCalling: false)
            conversation = try await engine.createConversation(with: config)
        }
        guard let active = conversation else { throw ServiceError.modelMissing }
        if cancelRequested { throw CancellationError() }
        await onStage(.waiting)
        var reply = ""
        // The SDK starts inference synchronously, so keep startup off this actor.
        do {
            let stream = await Task.detached(priority: .userInitiated) {
                active.sendMessageStream(Message(prompt), maxOutputTokens: 512)
            }.value
            for try await chunk in stream {
                // Drain the native stream after cancellation, keeping the engine
                // alive until its final callback before permitting another request.
                if cancelRequested { continue }
                let text = chunk.toString
                if !text.isEmpty {
                    reply += text
                    await onText(text)
                }
            }
            if cancelRequested { throw CancellationError() }
            if reply.isEmpty { context.invalidate() }
            else { context.completeTurn(threadID: threadID, history: history, prompt: prompt, reply: reply) }
        } catch {
            context.invalidate()
            try? active.cancel()
            throw error
        }
    }

    func cancel() {
        guard running else { return }
        cancelRequested = true
        context.invalidate()
        try? conversation?.cancel()
    }

    func unload() {
        guard !running else { return }
        conversation = nil
        context.invalidate()
        engine = nil
        backend = nil
        modelID = nil
    }
}

private enum ServiceError: LocalizedError {
    case busy, modelMissing
    var errorDescription: String? {
        switch self {
        case .busy: return "前の回答が終了するまでお待ちください。"
        case .modelMissing: return "この会話のモデルをダウンロードするか、対応するファイルを取り込んでください。"
        }
    }
}

