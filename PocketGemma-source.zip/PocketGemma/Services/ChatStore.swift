import Foundation
import Combine
import PocketCore
import UIKit

@MainActor
final class ChatStore: ObservableObject {
    @Published private(set) var threads: [ChatThread] = []
    @Published private(set) var selectedID: UUID?
    @Published private(set) var isGenerating = false
    @Published private(set) var isStopping = false
    @Published private(set) var status = ""
    @Published var error: String?
    @Published private var configurations = GenerationPreferences.load()
    private let archive = ChatArchive(fileURL: AppFiles.archive)
    private let gemma = GemmaService()
    private var generationTask: Task<Void, Never>?
    private var watchdogTask: Task<Void, Never>?
    private var replyTicket = ReplyTicket()
    private var lastActivity = Date()
    private var stageStarted = Date()
    private var currentStage = GemmaService.Stage.loading.rawValue
    private var archiveWritable = true
    private var lastCheckpoint = Date.distantPast

    init() {
        do {
            threads = try archive.load().sorted { $0.updatedAt > $1.updatedAt }
            selectedID = threads.first?.id
        } catch {
            // Preserve a corrupted archive for recovery, rather than overwrite it.
            archiveWritable = false
            self.error = "会話履歴を開けませんでした。元のファイルを保護するため、この起動中は履歴保存を停止しています。\n\(error.localizedDescription)"
        }
        if selectedID == nil { newChat() }
    }

    var current: ChatThread? { threads.first { $0.id == selectedID } }
    var messages: [ChatMessage] { current?.messages ?? [] }
    var currentModel: ModelSpec { ModelSpec.find(current?.modelID) ?? .e4b }
    var currentSettings: GenerationSettings { (configurations[currentModel.id] ?? GenerationSettings()).normalized(for: currentModel) }
    func updateSettings(_ settings: GenerationSettings) {
        guard !isGenerating else { return }
        configurations[currentModel.id] = settings.normalized(for: currentModel)
        GenerationPreferences.save(configurations)
    }

    func newChat(modelID: String? = nil) {
        guard !isGenerating else { return }
        let modelID = modelID ?? ModelStore.shared.selectedModel.id
        if let empty = threads.first(where: { $0.messages.isEmpty && $0.modelID == modelID }) {
            selectedID = empty.id
        } else {
            let thread = ChatThread(modelID: modelID)
            threads.insert(thread, at: 0)
            selectedID = thread.id
        }
        persist()
    }

    func select(_ id: UUID) {
        guard !isGenerating else { return }
        selectedID = id
    }

    func delete(_ id: UUID) {
        guard !isGenerating else { return }
        threads.removeAll { $0.id == id }
        if selectedID == id {
            selectedID = threads.first?.id
            if selectedID == nil { newChat() }
        }
        persist()
    }

    @discardableResult
    func send(_ raw: String, messageID: UUID = UUID(), attachments: [ChatAttachment] = []) -> Bool {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        let prompt = trimmed.isEmpty && !attachments.isEmpty ? "添付した内容を説明してください。" : trimmed
        guard !prompt.isEmpty, !isGenerating else { return false }
        guard prompt.utf8.count <= 4500 else {
            error = "最初の版では、1回のメッセージは約1,500文字までです。長い文章は分けて送ってください。"
            return false
        }
        let requestedModel = currentModel
        let settings = currentSettings
        let visualCount = attachments.reduce(0) { $0 + $1.imageNames.count }
        guard visualCount == 0 || requestedModel.supportsVision else {
            error = "画像・動画にはGemma 4を選んでください。"; return false
        }
        let currentCost = prompt.utf8.count + attachments.reduce(0) { $0 + $1.contextByteCost }
        let inputBudget = max(0, min(16000, (settings.maxTokens - settings.maxOutputTokens - 512) * 2) - settings.systemPrompt.utf8.count)
        guard visualCount <= 4, currentCost <= inputBudget else {
            error = "添付内容がモデルの入力上限を超えています。添付を減らすか、構成のMax Tokensを増やしてください。"; return false
        }
        guard ModelStore.shared.isInstalled(requestedModel) else {
            error = "モデル画面から\(requestedModel.name)をダウンロードしてください。"
            return false
        }
        guard let id = selectedID, let index = threads.firstIndex(where: { $0.id == id }) else { return false }
        let history = HistoryBuilder.recentPairs(threads[index].messages,
            byteBudget: max(0, inputBudget - currentCost))
        let assistant = ChatMessage(role: .assistant, text: "", state: .generating)
        threads[index].messages.append(ChatMessage(id: messageID, role: .user, text: prompt, attachments: attachments))
        threads[index].messages.append(assistant)
        threads[index].updatedAt = Date()
        isGenerating = true
        isStopping = false
        let ticket = replyTicket.begin()
        lastActivity = Date()
        stageStarted = Date()
        currentStage = GemmaService.Stage.loading.rawValue
        status = currentStage
        persist()
        startWatchdog(ticket: ticket, threadID: id, messageID: assistant.id)
        generationTask = Task {
            var outcome: ReplyState = .complete
            do {
                try await gemma.generate(threadID: id, prompt: prompt, history: history,
                    model: requestedModel, settings: settings, attachments: attachments,
                    onStage: { [weak self] stage in
                        await self?.setStage(stage, ticket: ticket)
                    }, onText: { [weak self] text in
                        await self?.append(text, ticket: ticket, threadID: id, messageID: assistant.id)
                    })
            } catch {
                guard replyTicket.accepts(ticket) else { return }
                if error is CancellationError || isStopping {
                    outcome = .stopped
                } else {
                    outcome = .failed
                    self.error = "回答を生成できませんでした。新しい会話で試すか、設定でCPUに切り替えてください。\n\(error.localizedDescription)"
                }
            }
            guard replyTicket.finish(ticket) else { return }
            watchdogTask?.cancel()
            watchdogTask = nil
            if let threadIndex = threads.firstIndex(where: { $0.id == id }),
               let messageIndex = threads[threadIndex].messages.firstIndex(where: { $0.id == assistant.id }) {
                if outcome == .complete && threads[threadIndex].messages[messageIndex].text.isEmpty {
                    outcome = .failed
                    error = "モデルから回答が届きませんでした。新しい会話でお試しください。"
                }
                threads[threadIndex].messages[messageIndex].state = outcome
            }
            isGenerating = false
            isStopping = false
            status = ""
            generationTask = nil
            persist()
        }
        return true
    }

    private func setStage(_ stage: GemmaService.Stage, ticket: UUID) {
        guard replyTicket.accepts(ticket), !isStopping else { return }
        currentStage = stage.rawValue
        stageStarted = Date()
        status = currentStage
    }

    private func append(_ text: String, ticket: UUID, threadID: UUID, messageID: UUID) {
        guard replyTicket.accepts(ticket), !isStopping else { return }
        guard let ti = threads.firstIndex(where: { $0.id == threadID }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == messageID }) else { return }
        threads[ti].messages[mi].text += text
        lastActivity = Date()
        stageStarted = Date()
        currentStage = "回答中…"
        status = "回答中…"
        if Date().timeIntervalSince(lastCheckpoint) > 2 {
            persist()
            lastCheckpoint = Date()
        }
    }

    func stop() {
        guard isGenerating, !isStopping else { return }
        isStopping = true
        status = "停止しています…"
        Task { await gemma.cancel() }
    }

    private func startWatchdog(ticket: UUID, threadID: UUID, messageID: UUID) {
        watchdogTask?.cancel()
        watchdogTask = Task { [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(for: .seconds(5)) } catch { return }
                guard let self, self.replyTicket.accepts(ticket) else { return }
                if Date().timeIntervalSince(self.lastActivity) >= 120 {
                    guard self.replyTicket.finish(ticket) else { return }
                    if let ti = self.threads.firstIndex(where: { $0.id == threadID }),
                       let mi = self.threads[ti].messages.firstIndex(where: { $0.id == messageID }) {
                        self.threads[ti].messages[mi].state = self.isStopping ? .stopped : .failed
                    }
                    self.error = "返信が届かないため、待機を終了しました。もう一度送信してください。続く場合はアプリを開き直してください。"
                    self.isGenerating = false
                    self.isStopping = false
                    self.status = ""
                    // Keep the native request alive until it really finishes.
                    // Late callbacks are discarded by the ticket above.
                    self.persist()
                    await self.gemma.cancel()
                    return
                }
                if !self.isStopping, Date().timeIntervalSince(self.stageStarted) >= 15 {
                    self.status = "\(self.currentStage) \(Int(Date().timeIntervalSince(self.stageStarted)))秒"
                }
            }
        }
    }

    func didEnterBackground() {
        stop()
        persist()
        let backgroundID = UIApplication.shared.beginBackgroundTask(withName: "FinishGemmaReply", expirationHandler: nil)
        let task = generationTask
        Task {
            await task?.value
            await gemma.unload()
            if backgroundID != .invalid { UIApplication.shared.endBackgroundTask(backgroundID) }
        }
    }

    func releaseModelMemory() {
        guard !isGenerating else { return }
        Task { await gemma.unload() }
    }

    private func persist() {
        guard archiveWritable else { return }
        do { try archive.save(threads) }
        catch { self.error = "会話履歴を保存できませんでした。\n\(error.localizedDescription)" }
    }
}

