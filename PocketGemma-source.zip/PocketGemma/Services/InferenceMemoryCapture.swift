import Foundation
import os
import VisionRuntimeBridge

/// Sample the app footprint, not just free memory before native allocation.
/// Peaks between the 200 ms samples and the OS jetsam limit remain unknown.
final class InferenceMemoryCapture: @unchecked Sendable {
    private let queue = DispatchQueue(label: "app.pocketgemma.memory-probe")
    private let source: DispatchSourceTimer
    private var peak: UInt64 = 0
    private var minimum: UInt64 = .max
    private var count = 0
    init() {
        source = DispatchSource.makeTimerSource(queue: queue)
        source.schedule(deadline: .now(), repeating: .milliseconds(200))
        source.setEventHandler { [weak self] in self?.sample() }
        source.resume()
    }
    private func sample() {
        peak = max(peak, PGProcessMemoryFootprint())
        minimum = min(minimum, UInt64(os_proc_available_memory()))
        count += 1
    }
    func finish() -> (peak: UInt64, minimum: UInt64, samples: Int) {
        source.cancel()
        return queue.sync { sample(); return (peak, minimum, count) }
    }
    deinit { source.cancel() }
}
