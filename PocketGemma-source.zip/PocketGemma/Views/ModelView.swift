import SwiftUI
import UniformTypeIdentifiers
import PocketCore

struct ModelView: View {
    @EnvironmentObject private var model: ModelStore
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.dismiss) private var dismiss
    @State private var showImporter = false
    @State private var importingModel: ModelSpec?
    @State private var showConfiguration = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("あなたのiPhoneに、AIを。")
                            .font(.title2.weight(.semibold))
                        Text("モデルを保存すれば、ネットがなくても会話できます。別のモデルを選ぶと新しい会話が開きます。")
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                    Button { showConfiguration = true } label: {
                        Label("生成設定・システムプロンプト", systemImage: "slider.horizontal.3")
                    }.buttonStyle(.bordered).disabled(chats.isGenerating)
                        .accessibilityIdentifier("model-generation-settings")
                    ForEach(ModelSpec.catalog) { spec in modelCard(spec) }
                    VStack(alignment: .leading, spacing: 12) {
                        Text("動作の設定").font(.headline)
                        Text("現在の実行方法: \(chats.currentSettings.backend.rawValue)。生成設定から変更できます。")
                            .font(.caption).foregroundStyle(.secondary)
                        Button("AIのメモリを解放する") { chats.releaseModelMemory() }
                            .font(.subheadline).disabled(chats.isGenerating)
                    }
                    .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Claudeについて").font(.subheadline.weight(.semibold))
                        Text("Claudeは端末に保存するモデルが公開されていないため、ここではインストールできません。利用にはオンライン接続が必要です。")
                            .font(.caption).foregroundStyle(.secondary)
                        Link("Claudeの公式提供方式", destination: URL(string: "https://platform.claude.com/docs/en/models/overview")!)
                            .font(.caption)
                    }
                    VStack(alignment: .leading, spacing: 8) {
                        Label("会話は、このiPhoneの中に。", systemImage: "iphone")
                            .font(.subheadline.weight(.medium))
                        Text("モデルのダウンロード時だけ配布元へ接続します。会話を送信するサーバーやAPIキーの設定はありません。")
                            .font(.caption).foregroundStyle(.secondary)
                        Text("各モデルの回答品質・速度は異なります。ダウンロードにはWi-Fiと、モデルサイズに加えて1 GB以上の空き容量が必要です。")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                .padding(20)
            }
            .accessibilityIdentifier("model-list")
            .background(Theme.canvas)
            .navigationTitle("モデルと設定").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完了") { dismiss() } } }
        }
        .sheet(isPresented: $showConfiguration) {
            GenerationConfigView(model: chats.currentModel, settings: chats.currentSettings, onSave: chats.updateSettings)
        }
        .fileImporter(isPresented: $showImporter,
                      allowedContentTypes: [UTType(filenameExtension: "litertlm") ?? .data], allowsMultipleSelection: false) { result in
            defer { importingModel = nil }
            do {
                if let spec = importingModel, let url = try result.get().first { model.importModel(url, spec: spec) }
            } catch { model.error = error.localizedDescription }
        }
        .alert("モデルを準備できませんでした", isPresented: Binding(get: { model.error != nil }, set: { if !$0 { model.error = nil } })) {
            Button("閉じる") { model.error = nil }
        } message: { Text(model.error ?? "") }
    }

    private func modelCard(_ spec: ModelSpec) -> some View {
        let installed = model.isInstalled(spec)
        let current = chats.currentModel.id == spec.id
        let working = model.operationModelID == spec.id
        return VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                GemmaMark(size: 36, letter: spec.monogram)
                VStack(alignment: .leading, spacing: 3) {
                    Text(spec.name).font(.headline)
                    Text("\(spec.sizeLabel) · \(spec.supportsVision ? "テキスト・画像・動画" : "テキスト")").font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 4)
                if installed {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                        .accessibilityLabel("保存済み")
                }
            }
            Text(spec.summary).font(.subheadline).foregroundStyle(.secondary)
            if working {
                Text(model.statusText).font(.caption).foregroundStyle(.secondary)
                if model.isDownloading {
                    ProgressView(value: model.progress).tint(Theme.accent)
                    Button("ダウンロードを中止") { model.cancelDownload() }.font(.subheadline)
                } else { ProgressView() }
            } else if installed {
                Button(current ? "使用中" : "このモデルで会話を始める") {
                    model.select(spec)
                    chats.newChat(modelID: spec.id)
                    chats.releaseModelMemory()
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
                .disabled(current || chats.isGenerating)
                .accessibilityIdentifier("model-use-\(spec.id)")
            } else {
                HStack(spacing: 12) {
                    Button("ダウンロード") { model.download(spec) }
                        .buttonStyle(.borderedProminent)
                        .accessibilityLabel("\(spec.name)をダウンロード")
                        .accessibilityIdentifier("model-download-\(spec.id)")
                    Button("ファイルから") {
                        importingModel = spec
                        showImporter = true
                    }
                    .buttonStyle(.bordered)
                    .accessibilityLabel("\(spec.name)をファイルから取り込む")
                }
                .font(.subheadline).disabled(model.isBusy)
                DisclosureGroup("取り込むファイル名") {
                    Text(spec.fileName).font(.caption).textSelection(.enabled)
                        .padding(.top, 4)
                }.font(.caption).foregroundStyle(.secondary)
            }
            Link("配布元・ライセンス", destination: spec.sourceURL).font(.caption)
        }
        .padding(18).frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
    }
}
