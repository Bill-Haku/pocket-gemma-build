import SwiftUI
import PocketCore

enum GenerationPreferences {
    private static let key = "generation-settings-v1"
    static func load() -> [String: GenerationSettings] {
        guard let data = UserDefaults.standard.data(forKey: key) else { return [:] }
        return (try? JSONDecoder().decode([String: GenerationSettings].self, from: data)) ?? [:]
    }
    static func save(_ settings: [String: GenerationSettings]) {
        if let data = try? JSONEncoder().encode(settings) { UserDefaults.standard.set(data, forKey: key) }
    }
}

struct GenerationConfigView: View {
    let model: ModelSpec
    let onSave: (GenerationSettings) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var draft: GenerationSettings
    @State private var tab = 0
    init(model: ModelSpec, settings: GenerationSettings, onSave: @escaping (GenerationSettings) -> Void) {
        self.model = model; self.onSave = onSave
        _draft = State(initialValue: settings)
    }
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("構成", selection: $tab) {
                    Text("モデル構成").tag(0); Text("システムプロンプト").tag(1)
                }.pickerStyle(.segmented).padding()
                if tab == 0 {
                    Form {
                        Section {
                            integer("Max Tokens", value: $draft.maxTokens, range: 1024...model.maximumContextTokens, step: 256)
                            Text("入力と返信を合わせた上限です。大きくすると必要なメモリも増えます。").font(.caption).foregroundStyle(.secondary)
                            integer("返信トークン上限", value: $draft.maxOutputTokens, range: 128...max(512, min(4096, draft.maxTokens / 2)), step: 128)
                            integer("TopK", value: $draft.topK, range: 1...64)
                            decimal("TopP", value: $draft.topP, range: 0.01...1)
                            decimal("Temperature", value: $draft.temperature, range: 0...2)
                        }
                        Section {
                            Picker("Visual token budget", selection: $draft.visualTokenBudget) {
                                ForEach([70, 140, 280, 560, 1120], id: \.self) { Text("\($0)").tag($0) }
                            }.disabled(!model.supportsVision).accessibilityIdentifier("visual-token-budget")
                            Picker("Accelerator", selection: $draft.backend) {
                                ForEach(ExecutionBackend.allCases) { Text($0.rawValue).tag($0) }
                            }.pickerStyle(.segmented).accessibilityIdentifier("execution-backend")
                            Toggle("Enable thinking", isOn: $draft.enableThinking).disabled(!model.supportsThinking).accessibilityIdentifier("enable-thinking")
                            Toggle("Enable speculative decoding", isOn: $draft.enableSpeculativeDecoding).disabled(!model.supportsSpeculation).accessibilityIdentifier("enable-speculation")
                            Text("設定はこのモデルに保存され、次の送信から反映されます。モデルが対応していない項目は変更できません。").font(.caption).foregroundStyle(.secondary)
                        }
                        Button("モデル構成をデフォルトに戻す") {
                            let prompt = draft.systemPrompt; draft = GenerationSettings(); draft.systemPrompt = prompt
                        }
                    }.scrollDismissesKeyboard(.interactively).accessibilityIdentifier("generation-configuration")
                } else {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("回答の口調や、アシスタントの役割を指定できます。").font(.subheadline).foregroundStyle(.secondary)
                        TextEditor(text: $draft.systemPrompt).font(.body).padding(8)
                            .background(Theme.card, in: RoundedRectangle(cornerRadius: 16))
                            .accessibilityIdentifier("system-prompt-input")
                        Button("デフォルトに戻す") { draft.systemPrompt = GenerationSettings.defaultSystemPrompt }
                    }.padding()
                }
            }
            .navigationTitle("構成").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("キャンセル") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("OK") { onSave(draft.normalized(for: model)); dismiss() }.accessibilityIdentifier("configuration-save")
                }
            }
        }
    }
    private func integer(_ title: String, value: Binding<Int>, range: ClosedRange<Int>, step: Int = 1) -> some View {
        VStack(alignment: .leading) {
            HStack { Text(title); Spacer(); TextField(title, value: value, format: .number.grouping(.never)).keyboardType(.numberPad).multilineTextAlignment(.trailing).frame(width: 85).accessibilityIdentifier("setting-" + title) }
            Slider(value: Binding(get: { Double(min(range.upperBound, max(range.lowerBound, value.wrappedValue))) }, set: { value.wrappedValue = Int($0) }), in: Double(range.lowerBound)...Double(range.upperBound), step: Double(step))
        }
    }
    private func decimal(_ title: String, value: Binding<Double>, range: ClosedRange<Double>) -> some View {
        VStack(alignment: .leading) {
            HStack { Text(title); Spacer(); TextField(title, value: value, format: .number.precision(.fractionLength(2))).keyboardType(.decimalPad).multilineTextAlignment(.trailing).frame(width: 85).accessibilityIdentifier("setting-" + title) }
            Slider(value: Binding(get: { value.wrappedValue.isFinite ? min(range.upperBound, max(range.lowerBound, value.wrappedValue)) : range.lowerBound }, set: { value.wrappedValue = $0 }), in: range, step: 0.01)
        }
    }
}
