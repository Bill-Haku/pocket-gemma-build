import SwiftUI
import PocketCore

enum GenerationPreferences {
    private static let key = "generation-settings-v1"
    static func load() -> [String: GenerationSettings] {
        guard let data = UserDefaults.standard.data(forKey: key) else { return [:] }
        return (try? JSONDecoder().decode([String: GenerationSettings].self, from: data)) ?? [:]
    }
    static func save(_ settings: [String: GenerationSettings]) {
        if let data = try? JSONEncoder().encode(settings) { UserDefaults.standard.set(data, forKey: key) }
    }
}

struct GenerationConfigView: View {
    let model: ModelSpec
    let onSave: (GenerationSettings) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var draft: GenerationSettings
    @State private var tab = 0
    init(model: ModelSpec, settings: GenerationSettings, onSave: @escaping (GenerationSettings) -> Void) {
        self.model = model; self.onSave = onSave
        _draft = State(initialValue: settings)
    }
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("構成", selection: $tab) {
                    Text("モデル構成").tag(0); Text("システムプロンプト").tag(1)
                }.pickerStyle(.segmented).padding()
                if tab == 0 {
                    Form {
                        Section {
                            integer("Max Tokens", value: $draft.maxTokens, range: 1024...model.maximumContextTokens, step: 256,
                                    help: "入力・会話履歴・返信を合わせた上限。増やすと長い会話を覚えられますが、メモリ使用量と準備時間も増えます。")
                            integer("返信トークン上限", value: $draft.maxOutputTokens, range: 128...max(512, min(4096, draft.maxTokens / 2)), step: 128,
                                    help: "1回の返信の最大長。増やすと長く答えられますが、生成に時間がかかり、履歴に使える枠が減ります。文字数とは異なります。")
                            integer("TopK", value: $draft.topK, range: 1...64,
                                    help: "次の言葉を選ぶ候補の数。小さくすると安定しやすく、大きくすると表現の幅が広がります。")
                            decimal("TopP", value: $draft.topP, range: 0.01...1,
                                    help: "候補に含める確率の範囲。下げると無難な言葉に絞り、上げると多様な言葉を選びやすくなります。")
                            decimal("Temperature", value: $draft.temperature, range: 0...2,
                                    help: "言葉選びのランダムさ。低いと一貫した回答、高いと変化のある回答になります。上げすぎると誤りも増えやすくなります。")
                        }
                        Section {
                            VStack(alignment: .leading, spacing: 8) {
                                Picker("Visual token budget", selection: $draft.visualTokenBudget) {
                                    ForEach(model.visualTokenBudgets, id: \.self) { Text("\($0)").tag($0) }
                                }.disabled(!model.supportsVision).accessibilityIdentifier("visual-token-budget")
                                explanation("画像1場面あたりの情報量。増やすと細部を読み取りやすくなりますが、メモリ・処理時間・入力枠を多く使います。", id: "visual-token-budget")
                            }
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Accelerator")
                                Picker("Accelerator", selection: $draft.backend) {
                                    ForEach(ExecutionBackend.allCases) { Text($0.rawValue).tag($0) }
                                }.pickerStyle(.segmented).accessibilityIdentifier("execution-backend")
                                explanation("CPU・GPUの選択は言語生成と画像の読み取りの両方に適用します。どちらも端末内で動作します。GPUでエラーが出る場合はCPUに変更して試せます。", id: "execution-backend")
                            }
                            VStack(alignment: .leading, spacing: 8) {
                                Toggle("Enable thinking", isOn: $draft.enableThinking).disabled(!model.supportsThinking).accessibilityIdentifier("enable-thinking")
                                explanation("回答前に推論を行います。複雑な問題を検討できますが、返信の開始が遅くなり、返信トークン枠の一部を消費します。", id: "enable-thinking")
                            }
                            VStack(alignment: .leading, spacing: 8) {
                                Toggle("Enable speculative decoding", isOn: $draft.enableSpeculativeDecoding).disabled(!model.supportsSpeculation).accessibilityIdentifier("enable-speculation")
                                explanation("候補を先読みして生成を速める機能。速度向上はモデルと端末によって異なり、メモリ使用量や消費電力が増える場合があります。", id: "enable-speculation")
                            }
                            Text("設定はこのモデルに保存され、次の送信から反映されます。モデルが対応していない項目は変更できません。").font(.caption).foregroundStyle(.secondary)
                        }
                        Button("モデル構成をデフォルトに戻す") {
                            let prompt = draft.systemPrompt; draft = GenerationSettings(); draft.systemPrompt = prompt
                        }
                    }.scrollDismissesKeyboard(.interactively).accessibilityIdentifier("generation-configuration")
                } else {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("回答の口調や、アシスタントの役割を指定できます。").font(.subheadline).foregroundStyle(.secondary)
                        TextEditor(text: $draft.systemPrompt).font(.body).padding(8)
                            .background(Theme.card, in: RoundedRectangle(cornerRadius: 16))
                            .accessibilityIdentifier("system-prompt-input")
                        Button("デフォルトに戻す") { draft.systemPrompt = GenerationSettings.defaultSystemPrompt }
                    }.padding()
                }
            }
            .navigationTitle("構成").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("キャンセル") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("OK") { onSave(draft.normalized(for: model)); dismiss() }.accessibilityIdentifier("configuration-save")
                }
            }
        }
    }
    private func explanation(_ text: String, id: String) -> some View {
        Text(text).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            .accessibilityIdentifier("setting-help-" + id)
    }
    private func integer(_ title: String, value: Binding<Int>, range: ClosedRange<Int>, step: Int = 1, help: String) -> some View {
        VStack(alignment: .leading) {
            HStack { Text(title); Spacer(); TextField(title, value: value, format: .number.grouping(.never)).keyboardType(.numberPad).multilineTextAlignment(.trailing).frame(width: 85).accessibilityIdentifier("setting-" + title) }
            Slider(value: Binding(get: { Double(min(range.upperBound, max(range.lowerBound, value.wrappedValue))) }, set: { value.wrappedValue = Int($0) }), in: Double(range.lowerBound)...Double(range.upperBound), step: Double(step))
            explanation(help, id: title)
        }
    }
    private func decimal(_ title: String, value: Binding<Double>, range: ClosedRange<Double>, help: String) -> some View {
        VStack(alignment: .leading) {
            HStack { Text(title); Spacer(); TextField(title, value: value, format: .number.precision(.fractionLength(2))).keyboardType(.decimalPad).multilineTextAlignment(.trailing).frame(width: 85).accessibilityIdentifier("setting-" + title) }
            Slider(value: Binding(get: { value.wrappedValue.isFinite ? min(range.upperBound, max(range.lowerBound, value.wrappedValue)) : range.lowerBound }, set: { value.wrappedValue = $0 }), in: range, step: 0.01)
            explanation(help, id: title)
        }
    }
}
