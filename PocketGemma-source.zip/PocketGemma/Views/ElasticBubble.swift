import SwiftUI
import UIKit

/// Render row inertia on native layers. There is no per-frame publication to
/// the chat view, and the transformed frame never changes the scroll layout.
struct ElasticBubble<Content: View>: UIViewRepresentable {
    let reduceMotion: Bool
    let content: Content
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    func makeUIView(context: Context) -> ElasticBubbleContainer {
        let view = ElasticBubbleContainer()
        view.host.sizingOptions = .intrinsicContentSize
        view.host.safeAreaRegions = []
        view.host.view.backgroundColor = .clear
        view.host.view.clipsToBounds = false
        updateUIView(view, context: context)
        return view
    }
    func updateUIView(_ view: ElasticBubbleContainer, context: Context) {
        view.motionEnabled = !reduceMotion
        view.host.rootView = AnyView(content.environment(\.colorScheme, colorScheme)
            .environment(\.dynamicTypeSize, dynamicTypeSize)
            .environment(\.chatPreviewReduceMotion, reduceMotion))
        view.host.view.invalidateIntrinsicContentSize()
    }
    func sizeThatFits(_ proposal: ProposedViewSize, uiView: ElasticBubbleContainer, context: Context) -> CGSize? {
        let width = proposal.width ?? 320
        return uiView.host.sizeThatFits(in: CGSize(width: width, height: .greatestFiniteMagnitude))
    }
    static func dismantleUIView(_ view: ElasticBubbleContainer, coordinator: ()) { view.detach() }
}

final class ElasticBubbleContainer: UIView {
    let host = UIHostingController(rootView: AnyView(EmptyView()))
    var motionEnabled = true { didSet { if !motionEnabled { shift = 0; velocity = 0; layer.setAffineTransform(.identity) } } }
    var shift: CGFloat = 0
    var velocity: CGFloat = 0
    private weak var driver: BubbleInertiaDriver?
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        clipsToBounds = false
        addSubview(host.view)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }
    override func layoutSubviews() { super.layoutSubviews(); host.view.frame = bounds }
    override func didMoveToWindow() {
        super.didMoveToWindow()
        if window == nil { detach(); return }
        if host.parent == nil {
            var responder: UIResponder? = superview
            while let current = responder {
                if let controller = current as? UIViewController {
                    controller.addChild(host); host.didMove(toParent: controller); break
                }
                responder = current.next
            }
        }
        var ancestor = superview
        while let current = ancestor {
            if let scroll = current as? UIScrollView {
                let driver = BubbleInertiaDriver.driver(for: scroll)
                self.driver = driver; driver.add(self); break
            }
            ancestor = current.superview
        }
    }
    func detach() {
        driver?.remove(self); driver = nil
        host.willMove(toParent: nil); host.removeFromParent()
        shift = 0; velocity = 0; layer.setAffineTransform(.identity)
    }
}

@MainActor private final class BubbleInertiaDriver: NSObject {
    private static var drivers = NSMapTable<UIScrollView, BubbleInertiaDriver>(keyOptions: .weakMemory, valueOptions: .strongMemory)
    static func driver(for scroll: UIScrollView) -> BubbleInertiaDriver {
        if let driver = drivers.object(forKey: scroll) { return driver }
        let driver = BubbleInertiaDriver(scroll: scroll)
        drivers.setObject(driver, forKey: scroll)
        return driver
    }
    private weak var scroll: UIScrollView?
    private let rows = NSHashTable<ElasticBubbleContainer>.weakObjects()
    private var observation: NSKeyValueObservation?
    private var displayLink: CADisplayLink?
    private var lastOffset: CGFloat
    private var lastTime: CFTimeInterval = 0
    private init(scroll: UIScrollView) {
        self.scroll = scroll; lastOffset = scroll.contentOffset.y
        super.init()
        observation = scroll.observe(\.contentOffset, options: [.new]) { [weak self] scroll, _ in
            self?.moved(scroll)
        }
    }
    func add(_ row: ElasticBubbleContainer) { rows.add(row) }
    func remove(_ row: ElasticBubbleContainer) {
        rows.remove(row)
        if rows.allObjects.isEmpty {
            displayLink?.invalidate(); displayLink = nil
            observation?.invalidate(); observation = nil
            if let scroll { Self.drivers.removeObject(forKey: scroll) }
        }
    }
    private func moved(_ scroll: UIScrollView) {
        let delta = scroll.contentOffset.y - lastOffset
        lastOffset = scroll.contentOffset.y
        guard scroll.isTracking || scroll.isDragging || scroll.isDecelerating, abs(delta) < 160 else { return }
        let finger = scroll.panGestureRecognizer.location(in: scroll).y
        for row in rows.allObjects where row.motionEnabled && row.window != nil {
            let center = row.convert(CGPoint(x: row.bounds.midX, y: row.bounds.midY), to: scroll).y
            let resistance = min(0.32, 0.08 + abs(center - finger) / 2200)
            row.shift = max(-22, min(22, row.shift + delta * resistance))
        }
        if displayLink == nil {
            #if POCKET_PREVIEW
            if ProcessInfo.processInfo.arguments.contains("--elastic-diagnostics") { ElasticMotionProbe.shared.resting = false }
            #endif
            lastTime = 0
            let link = CADisplayLink(target: self, selector: #selector(step(_:)))
            link.preferredFrameRateRange = CAFrameRateRange(minimum: 60, maximum: 120, preferred: 120)
            link.add(to: .main, forMode: .common)
            displayLink = link
        }
    }
    @objc private func step(_ link: CADisplayLink) {
        let dt = CGFloat(min(1.0 / 30, max(1.0 / 240, lastTime == 0 ? link.duration : link.timestamp - lastTime)))
        lastTime = link.timestamp
        var moving = false
        for row in rows.allObjects {
            if row.motionEnabled {
                row.velocity += (-220 * row.shift - 22 * row.velocity) * dt
                row.shift += row.velocity * dt
                if abs(row.shift) < 0.025 && abs(row.velocity) < 0.1 { row.shift = 0; row.velocity = 0 }
                else { moving = true }
            } else { row.shift = 0; row.velocity = 0 }
            row.layer.setAffineTransform(CGAffineTransform(translationX: 0, y: row.shift))
            #if POCKET_PREVIEW
            if ProcessInfo.processInfo.arguments.contains("--elastic-diagnostics") {
                ElasticMotionProbe.shared.record(abs(row.layer.affineTransform().ty))
            }
            #endif
        }
        if !moving {
            link.invalidate(); displayLink = nil; lastTime = 0
            #if POCKET_PREVIEW
            if ProcessInfo.processInfo.arguments.contains("--elastic-diagnostics") { ElasticMotionProbe.shared.resting = true }
            #endif
        }
    }
}

#if POCKET_PREVIEW
@MainActor final class ElasticMotionProbe: ObservableObject {
    static let shared = ElasticMotionProbe()
    @Published private(set) var peak: CGFloat = 0
    @Published var resting = true
    func record(_ displacement: CGFloat) { if displacement > peak + 2 { peak = displacement } }
}
struct ElasticProbeView: View {
    @ObservedObject private var probe = ElasticMotionProbe.shared
    var body: some View {
        Text("\(probe.peak > 1 ? "バウンズ動作を確認" : "バウンズ待機") · 最大\(probe.peak, specifier: "%.1f")pt · \(probe.resting ? "静止" : "移動中")")
            .font(.system(size: 9)).padding(3).background(.background)
            .accessibilityIdentifier("elastic-report").allowsHitTesting(false)
    }
}
#endif
