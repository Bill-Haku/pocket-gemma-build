import SwiftUI
import UIKit

/// Own the marked-text commit and reset in one place. Clearing a SwiftUI
/// TextField binding while a Japanese IME is active can commit its old text
/// back into the binding as the keyboard resigns.
@MainActor final class ComposerInput: ObservableObject {
    weak var textView: UITextView?
    var onClear: (() -> Void)?
    func committedText(fallback: String) -> String {
        textView?.unmarkText()
        return textView?.text ?? fallback
    }
    func clearAndDismiss() {
        onClear?()
        textView?.resignFirstResponder()
    }
}

struct ChatComposerText: UIViewRepresentable {
    @Binding var text: String
    @Binding var focused: Bool
    let enabled: Bool
    let input: ComposerInput
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> ComposerTextView {
        let view = ComposerTextView()
        view.backgroundColor = .clear
        view.font = .preferredFont(forTextStyle: .callout)
        view.adjustsFontForContentSizeCategory = true
        view.textColor = .label
        view.tintColor = .systemBlue
        view.textContainerInset = UIEdgeInsets(top: 11, left: 0, bottom: 11, right: 0)
        view.textContainer.lineFragmentPadding = 0
        view.isScrollEnabled = false
        view.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        view.accessibilityIdentifier = "chat-input"
        view.accessibilityLabel = "メッセージ"
        view.delegate = context.coordinator
        input.textView = view
        input.onClear = { [weak view, weak coordinator = context.coordinator] in
            guard let view, let coordinator else { return }
            coordinator.applying = true
            view.unmarkText()
            view.text = ""
            view.refreshPlaceholder()
            coordinator.parent.text = ""
            coordinator.applying = false
            view.invalidateIntrinsicContentSize()
        }
        return view
    }
    func updateUIView(_ view: ComposerTextView, context: Context) {
        context.coordinator.parent = self
        // The IME owns marked text until it commits. Do not replace it during
        // unrelated reply updates or attachment imports.
        if view.markedTextRange == nil && view.text != text {
            context.coordinator.applying = true
            view.text = text
            context.coordinator.applying = false
            view.invalidateIntrinsicContentSize()
        }
        if view.isEditable != enabled { view.isEditable = enabled }
        view.refreshPlaceholder()
        if focused && enabled && !view.isFirstResponder { view.becomeFirstResponder() }
        if !focused && view.isFirstResponder { view.resignFirstResponder() }
    }
    func sizeThatFits(_ proposal: ProposedViewSize, uiView: ComposerTextView, context: Context) -> CGSize? {
        let width = proposal.width ?? 200
        let height = uiView.sizeThatFits(CGSize(width: width, height: .greatestFiniteMagnitude)).height
        let limit = (uiView.font?.lineHeight ?? 20) * 6 + 22
        if uiView.isScrollEnabled != (height > limit) { uiView.isScrollEnabled = height > limit }
        return CGSize(width: width, height: min(limit, max(44, height)))
    }
    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: ChatComposerText
        var applying = false
        init(_ parent: ChatComposerText) { self.parent = parent }
        func textViewDidChange(_ textView: UITextView) {
            guard !applying else { return }
            parent.text = textView.text
            (textView as? ComposerTextView)?.refreshPlaceholder()
            textView.invalidateIntrinsicContentSize()
        }
        func textViewDidBeginEditing(_ textView: UITextView) { if !parent.focused { parent.focused = true } }
        func textViewDidEndEditing(_ textView: UITextView) { if parent.focused { parent.focused = false } }
    }
}

final class ComposerTextView: UITextView {
    private let placeholder = UILabel()
    override init(frame: CGRect, textContainer: NSTextContainer?) {
        super.init(frame: frame, textContainer: textContainer)
        placeholder.text = "メッセージ"
        placeholder.textColor = .placeholderText
        placeholder.isUserInteractionEnabled = false
        placeholder.isAccessibilityElement = false
        addSubview(placeholder)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }
    func refreshPlaceholder() {
        placeholder.isHidden = !text.isEmpty
        placeholder.font = font
        setNeedsLayout()
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        placeholder.frame = CGRect(x: 0, y: textContainerInset.top, width: bounds.width, height: font?.lineHeight ?? 20)
    }
}
