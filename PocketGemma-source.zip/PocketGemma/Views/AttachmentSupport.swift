import SwiftUI
import UIKit
import PhotosUI
import UniformTypeIdentifiers
import ImageIO
import AVFoundation
import PDFKit
import QuickLook
import PocketCore

enum AttachmentStorage {
    static var directory: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("PocketGemma/Attachments", isDirectory: true)
    }
    static func url(_ name: String) -> URL? {
        guard ChatAttachment.isSafeFileName(name) else { return nil }
        return directory.appendingPathComponent(name)
    }
    static func remove(_ attachment: ChatAttachment) {
        for name in Set([attachment.storedName] + attachment.imageNames + [attachment.thumbnailName].compactMap { $0 }) {
            if let url = url(name) { try? FileManager.default.removeItem(at: url) }
        }
    }
    static func importFile(_ source: URL) async throws -> ChatAttachment {
        let accessed = source.startAccessingSecurityScopedResource()
        defer { if accessed { source.stopAccessingSecurityScopedResource() } }
        let values = try source.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey, .contentTypeKey])
        guard values.isRegularFile == true else { throw ImportError.unsupported }
        // File-provider URLs may have no extension, or report public.data.
        // ImageIO identifies the encoded bytes, so valid photos still reach
        // normalization instead of the plain-document importer.
        let imageType = CGImageSourceCreateWithURL(source as CFURL, nil)
            .flatMap { CGImageSourceGetType($0) }
            .flatMap { UTType($0 as String) }
        let type = imageType ?? values.contentType ?? UTType(filenameExtension: source.pathExtension) ?? .data
        let kind: ChatAttachment.Kind = type.conforms(to: .image) ? .image : (type.conforms(to: .movie) ? .video : .file)
        let size = values.fileSize ?? 0
        guard size > 0, size <= (kind == .video ? 100_000_000 : 20_000_000) else { throw ImportError.tooLarge }
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let id = UUID()
        let fileExtension = imageType?.preferredFilenameExtension
            ?? (source.pathExtension.isEmpty ? "data" : source.pathExtension.lowercased())
        let name = id.uuidString + "." + fileExtension
        guard let destination = url(name) else { throw ImportError.unsupported }
        var copyError: NSError?
        var copied: Result<Void, Error>?
        NSFileCoordinator(filePresenter: nil).coordinate(readingItemAt: source, options: [], error: &copyError) { readable in
            copied = Result { try FileManager.default.copyItem(at: readable, to: destination) }
        }
        if let copyError { throw copyError }
        guard let copied else { throw ImportError.unreadable }
        try copied.get()
        var attachment = ChatAttachment(id: id, kind: kind, name: source.lastPathComponent, storedName: name,
                                        byteCount: Int64(size))
        do {
            switch kind {
            case .image:
                let jpeg = id.uuidString + "-image.jpg"
                guard let sourceImage = CGImageSourceCreateWithURL(destination as CFURL, nil),
                      let image = CGImageSourceCreateThumbnailAtIndex(sourceImage, 0, [
                        kCGImageSourceCreateThumbnailFromImageAlways: true,
                        kCGImageSourceCreateThumbnailWithTransform: true,
                        kCGImageSourceThumbnailMaxPixelSize: 768
                      ] as CFDictionary) else { throw ImportError.unreadable }
                try writeJPEG(image, name: jpeg)
                attachment.imageNames = [jpeg]; attachment.thumbnailName = jpeg
            case .video:
                let asset = AVURLAsset(url: destination)
                let assetDuration = try await asset.load(.duration)
                let duration = assetDuration.seconds
                guard duration.isFinite, duration > 0 else { throw ImportError.unreadable }
                attachment.duration = duration
                let generator = AVAssetImageGenerator(asset: asset)
                generator.appliesPreferredTrackTransform = true
                generator.maximumSize = CGSize(width: 768, height: 768)
                // Three representative scenes keep visual context and memory bounded.
                for (index, seconds) in [0.0, duration / 2, max(0, duration - 0.2)].enumerated() {
                    let result = try await generator.image(at: CMTime(seconds: seconds, preferredTimescale: 600))
                    let jpeg = id.uuidString + "-frame-\(index).jpg"
                    try writeJPEG(result.image, name: jpeg)
                    attachment.imageNames.append(jpeg)
                }
                attachment.thumbnailName = attachment.imageNames.first
                attachment.note = "動画は開始・中間・終了付近の3場面を読み込みます。音声は解析しません。"
            case .file:
                let text: String
                if type.conforms(to: .pdf) {
                    let result = try DocumentReader.pdf(destination)
                    text = result.text; attachment.note = result.note
                } else if source.pathExtension.lowercased() == "docx" {
                    let result = try DocumentReader.word(destination)
                    text = result.text; attachment.note = result.note
                } else {
                    let allowed = ["txt", "md", "csv", "tsv", "json", "log", "yaml", "yml", "xml", "html", "swift", "py", "js", "css", "rtf"]
                    guard type.conforms(to: .text) || allowed.contains(source.pathExtension.lowercased()) else { throw ImportError.unsupported }
                    let handle = try FileHandle(forReadingFrom: destination)
                    defer { try? handle.close() }
                    let data = try handle.read(upToCount: 128_000) ?? Data()
                    if type.conforms(to: .rtf), let rich = try? NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.rtf], documentAttributes: nil) {
                        text = rich.string
                    } else {
                        guard let value = decodeText(data) else { throw ImportError.unreadable }
                        text = value
                    }
                }
                guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw ImportError.noText }
                attachment.extractedText = GenerationSettings.prefix(text, byteLimit: 4000)
                if text.utf8.count > 4000 { attachment.note = "長いファイルのため、本文の先頭部分を読み込みます。" }
            }
            return attachment
        } catch { remove(attachment); throw error }
    }
    private static func writeJPEG(_ image: CGImage, name: String) throws {
        guard let url = url(name), let data = UIImage(cgImage: image).jpegData(compressionQuality: 0.85) else { throw ImportError.unreadable }
        try data.write(to: url, options: .atomic)
    }
    private static func decodeText(_ data: Data) -> String? {
        // A bounded read can end inside the last encoded character. Remove
        // only that incomplete suffix, rather than misdetect the whole file.
        if data.starts(with: [0xff, 0xfe]) || data.starts(with: [0xfe, 0xff]) {
            for trim in [0, 2] where data.count > trim {
                if let text = String(data: data.dropLast(trim), encoding: .utf16) { return text }
            }
            return nil
        }
        for trim in 0...3 where data.count > trim {
            if let text = String(data: data.dropLast(trim), encoding: .utf8) { return text }
        }
        for trim in 0...1 where data.count > trim {
            if let text = String(data: data.dropLast(trim), encoding: .shiftJIS) { return text }
        }
        return nil
    }
    enum ImportError: LocalizedError {
        case unsupported, tooLarge, unreadable, noText
        var errorDescription: String? {
            switch self {
            case .unsupported: return "画像・動画・PDF・Word（.docx）・テキスト形式を選んでください。"
            case .tooLarge: return "画像・ファイルは20MB、動画は100MBまで取り込めます。"
            case .unreadable: return "このファイルを読み込めませんでした。別の形式で保存してお試しください。"
            case .noText: return "本文を読み取れませんでした。画像として添付するか、文字が鮮明なファイルでお試しください。"
            }
        }
    }
}

struct ChatPhotoPicker: UIViewControllerRepresentable {
    var selectionLimit = 3
    let onSelect: ([URL]) -> Void
    let onError: (String) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIViewController(context: Context) -> PHPickerViewController {
        var configuration = PHPickerConfiguration()
        configuration.selectionLimit = selectionLimit
        configuration.filter = .any(of: [.images, .videos])
        let controller = PHPickerViewController(configuration: configuration)
        controller.delegate = context.coordinator
        return controller
    }
    func updateUIViewController(_ controller: PHPickerViewController, context: Context) {}
    final class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let parent: ChatPhotoPicker
        init(_ parent: ChatPhotoPicker) { self.parent = parent }
        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)
            Task { @MainActor in
                var urls: [URL] = []
                for result in results {
                    let provider = result.itemProvider
                    guard let type = provider.registeredTypeIdentifiers.first(where: {
                        guard let type = UTType($0) else { return false }
                        return type.conforms(to: .movie) || type.conforms(to: .image)
                    }) else {
                        parent.onError(AttachmentStorage.ImportError.unsupported.localizedDescription)
                        continue
                    }
                    do {
                        let url: URL = try await withCheckedThrowingContinuation { continuation in
                            provider.loadFileRepresentation(forTypeIdentifier: type) { url, error in
                                do {
                                    guard let url else { throw error ?? AttachmentStorage.ImportError.unreadable }
                                    // Provider URLs expire when this callback returns; stage a copy now.
                                    let fileExtension = url.pathExtension.isEmpty
                                        ? (UTType(type)?.preferredFilenameExtension ?? "data")
                                        : url.pathExtension
                                    let staged = FileManager.default.temporaryDirectory
                                        .appendingPathComponent(UUID().uuidString)
                                        .appendingPathExtension(fileExtension)
                                    try FileManager.default.copyItem(at: url, to: staged)
                                    continuation.resume(returning: staged)
                                } catch { continuation.resume(throwing: error) }
                            }
                        }
                        urls.append(url)
                    } catch { parent.onError(error.localizedDescription) }
                }
                parent.onSelect(urls)
            }
        }
    }
}

struct AttachmentCard: View {
    let attachment: ChatAttachment
    var compact = false
    @State private var image: UIImage?
    @State private var showPreview = false
    var body: some View {
        Button { showPreview = true } label: {
            VStack(alignment: .leading, spacing: 5) {
                if let image {
                    Image(uiImage: image).resizable().scaledToFit()
                        .frame(maxWidth: compact ? 110 : 220, maxHeight: compact ? 64 : 180)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                        .overlay { if attachment.kind == .video { Image(systemName: "play.circle.fill").font(.title).foregroundStyle(.white).shadow(radius: 3) } }
                }
                Label(attachment.name, systemImage: attachment.kind == .image ? "photo" : (attachment.kind == .video ? "video" : "doc.text"))
                    .font(.caption).lineLimit(1)
                    .frame(maxWidth: compact ? 130 : 220, alignment: .leading)
                if let note = attachment.note, !compact { Text(note).font(.caption2).fixedSize(horizontal: false, vertical: true).frame(maxWidth: 220) }
            }
            .padding(6)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain).accessibilityLabel("添付ファイルを開く: \(attachment.name)")
        .sheet(isPresented: $showPreview) {
            NavigationStack {
                AttachmentPreview(attachment: attachment).ignoresSafeArea(edges: .bottom)
                    .navigationTitle(attachment.name).navigationBarTitleDisplayMode(.inline)
                    .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完了") { showPreview = false } } }
            }
        }
        .task(id: attachment.id) {
            guard let name = attachment.thumbnailName, let url = AttachmentStorage.url(name) else { return }
            let loaded = await Task.detached(priority: .utility) { UIImage(contentsOfFile: url.path) }.value
            if !Task.isCancelled { image = loaded }
        }
    }
}

struct AttachmentPreview: UIViewControllerRepresentable {
    let attachment: ChatAttachment
    func makeCoordinator() -> Coordinator { Coordinator(attachment) }
    func makeUIViewController(context: Context) -> QLPreviewController {
        let controller = QLPreviewController(); controller.dataSource = context.coordinator
        return controller
    }
    func updateUIViewController(_ controller: QLPreviewController, context: Context) {}
    final class Coordinator: NSObject, QLPreviewControllerDataSource {
        let attachment: ChatAttachment
        init(_ attachment: ChatAttachment) { self.attachment = attachment }
        func numberOfPreviewItems(in controller: QLPreviewController) -> Int { AttachmentStorage.url(attachment.storedName) == nil ? 0 : 1 }
        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
            AttachmentStorage.url(attachment.storedName)! as NSURL
        }
    }
}
