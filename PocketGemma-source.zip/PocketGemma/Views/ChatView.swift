import SwiftUI
import UIKit
import PocketCore

struct ChatView: View {
    @EnvironmentObject private var chats: ChatStore
    @EnvironmentObject private var model: ModelStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }
    @State private var draft = ""
    @State private var showModel = false
    @State private var showActions = false
    @State private var scrollPolicy = ChatScrollPolicy()
    @State private var lastStreamScroll = Date.distantPast
    @State private var composerBounds = CGRect.zero
    @State private var composerHeight = ChatMetrics.control
    @State private var flight: SentMessageFlight?
    @State private var flightDestination = CGRect.zero
    @State private var flightProgress: CGFloat = 0
    @State private var flightStarted = false
    @State private var flightCleanup: Task<Void, Never>?
    @State private var timestampReveal: CGFloat = 0
    @State private var latestRequest = 0
    @Namespace private var composerGlass
    @FocusState private var inputFocused: Bool

    private var canSend: Bool {
        model.isInstalled(chats.currentModel) && !draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    private var datedMessages: Set<UUID> {
        var result: Set<UUID> = []
        var previous: Date?
        for message in chats.messages {
            if previous == nil || message.createdAt.timeIntervalSince(previous!) > 300 { result.insert(message.id) }
            previous = message.createdAt
        }
        return result
    }

    private var tailedMessages: Set<UUID> {
        var result: Set<UUID> = []
        for (index, message) in chats.messages.enumerated() {
            let next = chats.messages.dropFirst(index + 1).first
            if next == nil || next?.role != message.role
                || (next?.createdAt.timeIntervalSince(message.createdAt) ?? 0) > 60 {
                result.insert(message.id)
            }
        }
        return result
    }

    var body: some View {
        conversation
            .blur(radius: showActions ? 6 : 0)
            .background(Theme.chatBackground)
            .chatBars(top: {
                header.blur(radius: showActions ? 4 : 0).accessibilityHidden(showActions)
                    .background { ChatChromeBackdrop(edge: .top) }
            }, bottom: {
                // Reserve the measured input height for reading space.
                // The actual controls live in the root overlay, so the jump
                // button above the bar also has an interactive hit area.
                Color.clear.frame(height: max(ChatMetrics.control, composerHeight) + 14)
                    .allowsHitTesting(false)
            })
            .overlay(alignment: .bottom) {
                composer.background { ChatChromeBackdrop(edge: .bottom) }
            }
            .coordinateSpace(name: "chat")
            .overlay { if showActions { expandedActions } }
            .overlay(alignment: .topLeading) {
                if let flight {
                    SendingBubble(flight: flight,
                                  destination: flightDestination.isEmpty ? flight.origin : flightDestination,
                                  progress: flightProgress)
                }
            }
            .onPreferenceChange(ComposerHeightKey.self) { height in
                if abs(composerHeight - height) > 0.5 { composerHeight = height }
            }
            .onPreferenceChange(ComposerBoundsKey.self) { bounds in
                // Glass transitions can transform a presentation frame. Keep
                // subpixel changes from feeding back into the entire layout.
                if abs(composerBounds.minX - bounds.minX) > 0.5
                    || abs(composerBounds.minY - bounds.minY) > 0.5
                    || abs(composerBounds.width - bounds.width) > 0.5
                    || abs(composerBounds.height - bounds.height) > 0.5 {
                    composerBounds = bounds
                }
            }
            .onPreferenceChange(SentBubbleBoundsKey.self, perform: receiveFlightBounds)
            .toolbar(.hidden, for: .navigationBar)
            .toolbar(.hidden, for: .bottomBar)
            .background { ChatBackSwipe().frame(width: 0, height: 0) }
            .tint(Theme.accent)
            .sheet(isPresented: $showModel) { ModelView() }
            .onChange(of: chats.selectedID) { _, _ in
                draft = ""
                clearFlight()
                scrollPolicy.requestLatest()
            }
            .onDisappear { clearFlight() }
            .alert("お知らせ", isPresented: Binding(get: { chats.error != nil }, set: { if !$0 { chats.error = nil } })) {
                Button("閉じる") { chats.error = nil }
            } message: { Text(chats.error ?? "") }
    }

    private var header: some View {
        ChatGlassGroup {
            ZStack(alignment: .topLeading) {
                ChatCircleButton(action: {
                    inputFocused = false
                    dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: ChatMetrics.icon, weight: .medium)).foregroundStyle(.primary)
                }
                .accessibilityLabel("会話一覧を開く")
                .padding(.leading, ChatMetrics.gutter).padding(.top, 8)

                Button {
                    inputFocused = false
                    showModel = true
                } label: {
                    VStack(spacing: 4) {
                        GemmaMark(size: 40, letter: chats.currentModel.monogram)
                        HStack(spacing: 3) {
                            Text(chats.currentModel.family).font(.system(size: 12, weight: .semibold))
                            Image(systemName: "chevron.right").font(.system(size: 8, weight: .semibold))
                                .foregroundStyle(.secondary)
                        }
                        .padding(.horizontal, 9).padding(.vertical, 4)
                        .chatGlass(in: Capsule())
                    }
                    .foregroundStyle(.primary).frame(maxWidth: .infinity)
                    .padding(.top, 6).padding(.bottom, 8).contentShape(Rectangle())
                }
                .accessibilityLabel("モデルと設定を開く").accessibilityIdentifier("chat-model-settings")
                .padding(.horizontal, 74)
            }
            .buttonStyle(.plain)
        }
        .chatChromeBackground()
    }

    private var conversation: some View {
        GeometryReader { geometry in
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 6) {
                        Text(chats.currentModel.name)
                            .font(.system(size: 12, weight: .medium)).foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity).padding(.top, 14).padding(.bottom, 8)
                        if chats.messages.isEmpty {
                            if !model.isInstalled(chats.currentModel) { preparation }
                            else {
                                Text("メッセージを送って会話を始めましょう")
                                    .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
                                    .padding(.horizontal, 26).padding(.top, 8)
                            }
                        }
                        ForEach(chats.messages) { message in
                            if datedMessages.contains(message.id) { timestamp(message.createdAt) }
                            MessageView(message: message, oppositeInset: max(56, geometry.size.width * 0.20),
                                        hasTail: tailedMessages.contains(message.id),
                                        capturesFlight: flight?.id == message.id,
                                        hiddenForFlight: flight?.id == message.id,
                                        timestampReveal: timestampReveal)
                                .id(message.id)
                                .transition(message.role == .assistant && !reduceMotion
                                    ? .scale(scale: 0.86, anchor: .bottomLeading).combined(with: .opacity) : .identity)
                        }
                        if chats.isGenerating {
                            Text(chats.status).font(.caption2).foregroundStyle(.secondary)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.leading, 20).padding(.top, 2)
                        }
                        Color.clear.frame(height: 1).id("bottom")
                            .background {
                                GeometryReader { bottom in
                                    Color.clear.preference(key: ConversationBottomKey.self,
                                        value: bottom.frame(in: .named("conversation")).minY)
                                }
                            }
                    }
                    .padding(.horizontal, ChatMetrics.gutter).padding(.bottom, 10)
                }
                .coordinateSpace(name: "conversation")
                .scrollDismissesKeyboard(.interactively)
                .chatScrollEdges()
                .modifier(ChatScrollObserver(onDistance: { scrollPolicy.observe(distanceFromBottom: $0) },
                    onUserScrolling: { scrollPolicy.setUserScrolling($0) }))
                .onPreferenceChange(ConversationBottomKey.self) { bottom in
                    if #unavailable(iOS 18.0) {
                        scrollPolicy.observe(distanceFromBottom: Double(max(0, bottom - geometry.size.height)))
                    }
                }
                .modifier(ChatTimestampReveal(onChanged: { timestampReveal = $0 }, onEnded: {
                    withAnimation(reduceMotion ? nil : ChatMotion.resize) { timestampReveal = 0 }
                }))
                .onChange(of: chats.messages.last?.text) { _, _ in
                    guard scrollPolicy.shouldFollowStream, Date().timeIntervalSince(lastStreamScroll) >= 0.12 else { return }
                    lastStreamScroll = Date()
                    scrollToBottom(proxy)
                }
                .onChange(of: chats.messages.count) { _, _ in
                    if scrollPolicy.followsLatest { scrollToBottom(proxy) }
                }
                .onChange(of: chats.isGenerating) { _, generating in
                    if !generating && scrollPolicy.shouldFollowStream { scrollToBottom(proxy) }
                }
                .onChange(of: chats.selectedID) { _, _ in proxy.scrollTo("bottom", anchor: .bottom) }
                .onChange(of: latestRequest) { _, _ in scrollToBottom(proxy) }
                .onChange(of: inputFocused) { _, focused in
                    if focused && scrollPolicy.followsLatest { scrollToBottom(proxy) }
                }
                .task { proxy.scrollTo("bottom", anchor: .bottom) }
                .accessibilityIdentifier("chat-conversation")
                .accessibilityHidden(showActions)
            }
        }
        // Content continues beneath the feathered backdrop and glass controls.
    }

    private func scrollToBottom(_ proxy: ScrollViewProxy) {
        withAnimation(reduceMotion ? nil : ChatMotion.scroll) { proxy.scrollTo("bottom", anchor: .bottom) }
    }
    private func timestamp(_ date: Date) -> some View {
        HStack(spacing: 4) {
            Text(date, format: .dateTime.month().day()).fontWeight(.semibold)
            Text(date, style: .time)
        }
        .font(.system(size: 11)).foregroundStyle(.secondary)
        .frame(maxWidth: .infinity).padding(.top, 10).padding(.bottom, 9)
    }
    private var preparation: some View {
        VStack(spacing: 9) {
            Text(model.isBusy ? model.statusText : "モデルを保存すると、このiPhoneで会話できます。")
                .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
            Button("モデルを準備する") { showModel = true }.font(.subheadline)
        }
        .padding(.horizontal, 24).padding(.vertical, 14)
    }

    private var composer: some View {
            HStack(alignment: .bottom, spacing: ChatMetrics.controlGap) {
                ChatCircleButton(action: {
                    inputFocused = false
                    withAnimation(reduceMotion ? nil : ChatMotion.menu) { showActions.toggle() }
                }) {
                    Image(systemName: "plus").font(.system(size: ChatMetrics.icon, weight: .regular))
                        .rotationEffect(.degrees(showActions ? 45 : 0))
                        .foregroundStyle(.primary)
                }
                .accessibilityLabel(showActions ? "メニューを閉じる" : "会話の操作を開く")
                .accessibilityIdentifier("chat-add-menu")
                // Only the input and its emerging jump control share this
                // container. The plus button remains a separate glass shape.
                ChatGlassGroup(spacing: ChatMetrics.jumpGap) {
                    ZStack(alignment: .bottomTrailing) {
                        composerField
                            .chatGlass(in: RoundedRectangle(cornerRadius: ChatMetrics.control / 2))
                            .chatGlassIdentity("input", in: composerGlass, reduceMotion: reduceMotion)
                        if !scrollPolicy.followsLatest && !showActions {
                            ChatCircleButton(action: {
                                scrollPolicy.requestLatest()
                                latestRequest += 1
                            }) {
                                Image(systemName: "arrow.down")
                                    .font(.system(size: ChatMetrics.icon, weight: .medium))
                            }
                            .accessibilityLabel("最新のメッセージへ移動")
                            .accessibilityIdentifier("chat-jump-latest")
                            .chatGlassIdentity("latest", in: composerGlass, reduceMotion: reduceMotion)
                            .offset(y: -(ChatMetrics.control + ChatMetrics.jumpGap))
                            .transition(reduceMotion ? .opacity : .offset(y: ChatMetrics.control + ChatMetrics.jumpGap)
                                .combined(with: .opacity))
                        }
                    }
                }
                .animation(reduceMotion ? nil : ChatMotion.glassSeparation, value: scrollPolicy.followsLatest)
            }
            .padding(.horizontal, ChatMetrics.gutter).padding(.top, 8).padding(.bottom, 6)
            .chatChromeBackground()
    }

    private var composerField: some View {
                HStack(alignment: .bottom, spacing: 0) {
                    TextField("メッセージ", text: $draft, axis: .vertical)
                        .font(ChatMetrics.messageFont).lineLimit(1...6)
                        .padding(.leading, 14).padding(.vertical, 11)
                        .focused($inputFocused).disabled(!model.isInstalled(chats.currentModel))
                        .accessibilityLabel("\(chats.currentModel.family)へのメッセージ")
                        .accessibilityIdentifier("chat-input")
                    Button {
                        if chats.isGenerating { chats.stop() }
                        else { send() }
                    } label: {
                        Image(systemName: chats.isGenerating ? "stop.fill" : "arrow.up")
                            .contentTransition(reduceMotion ? .identity : .symbolEffect(.replace))
                            .font(.system(size: chats.isGenerating ? 11 : 17, weight: .bold))
                            .foregroundStyle(.white).frame(width: 30, height: 30)
                            .background(chats.isGenerating || canSend ? Theme.accent : Color(uiColor: .systemGray3), in: Circle())
                            .frame(width: ChatMetrics.control, height: ChatMetrics.control).contentShape(Rectangle())
                    }
                    .accessibilityLabel(chats.isGenerating ? "回答を停止する" : "送信する")
                    .disabled(chats.isStopping || (!chats.isGenerating && !canSend))
                    .buttonStyle(.plain)
                }
                .frame(minHeight: ChatMetrics.control)
                .accessibilityElement(children: .contain)
                .accessibilityIdentifier("chat-composer")
                .accessibilityHidden(showActions)
                .animation(reduceMotion ? nil : ChatMotion.resize, value: draft)
                .animation(reduceMotion ? nil : ChatMotion.resize, value: chats.isGenerating)
                .background {
                    GeometryReader { input in
                        Color.clear
                            .preference(key: ComposerHeightKey.self, value: input.size.height)
                            .preference(key: ComposerBoundsKey.self, value: input.frame(in: .named("chat")))
                    }
                }
    }

    private var expandedActions: some View {
        ZStack(alignment: .bottomLeading) {
            Color.black.opacity(0.06).ignoresSafeArea(.container).allowsHitTesting(false)
            Color.clear.contentShape(Rectangle())
                .onTapGesture { closeActions() }.padding(.bottom, 64)
            ChatGlassGroup(spacing: 16) {
                VStack(alignment: .leading, spacing: 14) {
                    actionRow("新しい会話", icon: "square.and.pencil", tint: .blue, disabled: chats.isGenerating) {
                        chats.newChat()
                    }
                    actionRow("会話一覧", icon: "bubble.left.and.bubble.right", tint: .green) { dismiss() }
                    actionRow("モデルと設定", icon: "slider.horizontal.3", tint: .gray) { showModel = true }
                }
            }
            .padding(.leading, ChatMetrics.gutter).padding(.bottom, 74)
            .transition(reduceMotion ? .opacity : .move(edge: .bottom).combined(with: .opacity))
        }
        .transition(.opacity)
    }
    private func actionRow(_ title: String, icon: String, tint: Color, disabled: Bool = false,
                           action: @escaping () -> Void) -> some View {
        Button {
            closeActions()
            action()
        } label: {
            HStack(spacing: 14) {
                Image(systemName: icon).font(.system(size: ChatMetrics.icon, weight: .medium)).foregroundStyle(tint)
                    .frame(width: ChatMetrics.control, height: ChatMetrics.control).chatGlass(in: Circle())
                Text(title).font(.title3.weight(.semibold)).foregroundStyle(.primary)
            }
            .contentShape(Rectangle())
        }
        .accessibilityLabel(title)
        .buttonStyle(.plain).disabled(disabled).opacity(disabled ? 0.4 : 1)
    }
    private func closeActions() {
        withAnimation(reduceMotion ? nil : ChatMotion.menu) { showActions = false }
    }
    private func send() {
        let id = UUID()
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        var accepted = false
        withAnimation(reduceMotion ? nil : ChatMotion.send) {
            accepted = chats.send(draft, messageID: id)
            if accepted {
                draft = ""
                scrollPolicy.requestLatest()
                if !reduceMotion && !composerBounds.isEmpty {
                    flightCleanup?.cancel()
                    flight = SentMessageFlight(id: id, text: text, origin: composerBounds)
                    flightDestination = .zero
                    flightProgress = 0
                    flightStarted = false
                }
            }
        }
        guard accepted, flight?.id == id else { return }
        flightCleanup = Task {
            do { try await Task.sleep(for: .milliseconds(650)) } catch { return }
            if flight?.id == id { flight = nil }
        }
    }
    private func receiveFlightBounds(_ bounds: [UUID: CGRect]) {
        guard let flight, let destination = bounds[flight.id], !destination.isEmpty else { return }
        flightDestination = destination
        guard !flightStarted else { return }
        flightStarted = true
        withAnimation(ChatMotion.send) { flightProgress = 1 }
    }
    private func clearFlight() {
        flightCleanup?.cancel()
        flightCleanup = nil
        flight = nil
    }
}

private struct MessageView: View {
    let message: ChatMessage
    let oppositeInset: CGFloat
    var hasTail = true
    var capturesFlight = false
    var hiddenForFlight = false
    var timestampReveal: CGFloat = 0
    private var outgoing: Bool { message.role == .user }

    var body: some View {
        HStack(alignment: .bottom, spacing: 0) {
            if outgoing { Spacer(minLength: oppositeInset) }
            VStack(alignment: outgoing ? .trailing : .leading, spacing: 4) {
                Group {
                    if message.text.isEmpty && message.state == .generating {
                        TypingIndicator()
                    } else {
                        Group {
                            if !outgoing && !message.text.isEmpty {
                                ReplyText(text: message.text, isStreaming: message.state == .generating)
                            } else {
                                Text(message.text.isEmpty ? (message.state == .failed ? "回答を生成できませんでした" : "回答を停止しました") : message.text)
                            }
                        }
                            .font(ChatMetrics.messageFont).lineSpacing(1)
                            .textSelection(.enabled)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.vertical, ChatMetrics.bubbleVertical)
                            .padding(.leading, outgoing ? ChatMetrics.bubbleInset : ChatMetrics.bubbleTailInset)
                            .padding(.trailing, outgoing ? ChatMetrics.bubbleTailInset : ChatMetrics.bubbleInset)
                    }
                }
                .foregroundStyle(outgoing ? Color.white : Color.primary)
                .background(outgoing ? Theme.accent : Theme.incoming,
                            in: MessageBubble(outgoing: outgoing, hasTail: hasTail))
                .background {
                    if capturesFlight {
                        GeometryReader { bubble in
                            Color.clear.preference(key: SentBubbleBoundsKey.self,
                                value: [message.id: bubble.frame(in: .named("chat"))])
                        }
                    }
                }
                .opacity(hiddenForFlight ? 0 : 1)
                .accessibilityHidden(hiddenForFlight)
                .contextMenu {
                    if !message.text.isEmpty {
                        Button("コピー", systemImage: "doc.on.doc") { UIPasteboard.general.string = message.text }
                    }
                }
                if message.state == .stopped || message.state == .failed {
                    Text(message.state == .stopped ? "停止した回答" : "回答を生成できませんでした")
                        .font(.system(size: 11)).foregroundStyle(.secondary)
                        .padding(.horizontal, 9)
                }
            }
            .offset(x: -72 * timestampReveal)
            if !outgoing { Spacer(minLength: oppositeInset) }
        }
        .overlay(alignment: .trailing) {
            Text(message.createdAt, style: .time)
                .font(.system(size: 11)).foregroundStyle(.secondary)
                .frame(width: 64).opacity(Double(timestampReveal))
                .accessibilityHidden(timestampReveal == 0)
        }
        .accessibilityElement(children: .combine)
    }
}

struct MessageBubble: Shape {
    var outgoing: Bool
    var hasTail = true

    func path(in rect: CGRect) -> Path {
        // Cubic quarter-circles stay round even for a reply taller than the
        // viewport. The short curved tail is part of this same outline.
        var path = Path()
        let left = rect.minX, top = rect.minY, bottom = rect.maxY
        let right = rect.maxX - 6
        let radius = max(0, min(18, min((rect.width - 6) / 2, rect.height / 2)))
        let curve = radius * 0.5522847498
        path.move(to: CGPoint(x: left + radius, y: top))
        path.addLine(to: CGPoint(x: right - radius, y: top))
        path.addCurve(to: CGPoint(x: right, y: top + radius),
                      control1: CGPoint(x: right - radius + curve, y: top),
                      control2: CGPoint(x: right, y: top + radius - curve))
        path.addLine(to: CGPoint(x: right, y: bottom - radius))
        if hasTail {
            path.addCurve(to: CGPoint(x: rect.maxX, y: bottom),
                          control1: CGPoint(x: right, y: bottom - 7),
                          control2: CGPoint(x: right + 1, y: bottom - 3))
            path.addCurve(to: CGPoint(x: right - 8, y: bottom - 4),
                          control1: CGPoint(x: right + 1, y: bottom),
                          control2: CGPoint(x: right - 4, y: bottom - 1))
            path.addCurve(to: CGPoint(x: right - radius, y: bottom),
                          control1: CGPoint(x: right - 11, y: bottom - 1),
                          control2: CGPoint(x: right - 14, y: bottom))
        } else {
            path.addCurve(to: CGPoint(x: right - radius, y: bottom),
                          control1: CGPoint(x: right, y: bottom - radius + curve),
                          control2: CGPoint(x: right - radius + curve, y: bottom))
        }
        path.addLine(to: CGPoint(x: left + radius, y: bottom))
        path.addCurve(to: CGPoint(x: left, y: bottom - radius),
                      control1: CGPoint(x: left + radius - curve, y: bottom),
                      control2: CGPoint(x: left, y: bottom - radius + curve))
        path.addLine(to: CGPoint(x: left, y: top + radius))
        path.addCurve(to: CGPoint(x: left + radius, y: top),
                      control1: CGPoint(x: left, y: top + radius - curve),
                      control2: CGPoint(x: left + radius - curve, y: top))
        path.closeSubpath()
        if !outgoing {
            return path.applying(CGAffineTransform(a: -1, b: 0, c: 0, d: 1, tx: rect.minX + rect.maxX, ty: 0))
        }
        return path
    }
}

private struct TypingIndicator: View {
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: reduceMotion)) { timeline in
            let phase = timeline.date.timeIntervalSinceReferenceDate * 4.5
            HStack(spacing: 5) {
                ForEach(0..<3) { dot in
                    let wave = reduceMotion ? 1 : (sin(phase - Double(dot) * 0.8) + 1) / 2
                    Circle().fill(Color(uiColor: .systemGray))
                        .frame(width: 8, height: 8)
                        .opacity(0.4 + wave * 0.6)
                        .scaleEffect(0.9 + wave * 0.1)
                }
            }
            .padding(.leading, 20).padding(.trailing, 14).padding(.vertical, 13)
        }
        .accessibilityLabel("AIが回答を作成しています")
    }
}
