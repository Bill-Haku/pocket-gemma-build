import SwiftUI
import PocketCore

struct VisionProbeView: View {
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.dismiss) private var dismiss
    @State private var modelID = ModelSpec.e4b.id
    @State private var kind = VisionProbeKind.squareJPEG
    @State private var main = ExecutionBackend.gpu
    @State private var vision = ExecutionBackend.cpu
    @State private var running = false
    @State private var result = ""
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("会話履歴と保存済み設定を変更せず、同じ公式モデルで検証します。Context 4096、Vision 280、MTPとThinkingは無効です。現在のAIのメモリを解放してから実行します。")
                        .font(.caption).foregroundStyle(.secondary)
                    Picker("モデル", selection: $modelID) {
                        Text("Gemma 4 E2B").tag(ModelSpec.e2b.id)
                        Text("Gemma 4 E4B").tag(ModelSpec.e4b.id)
                    }.accessibilityIdentifier("vision-probe-model")
                    Picker("検証経路", selection: $kind) {
                        ForEach(VisionProbeKind.allCases) { item in Text(item.title).tag(item) }
                    }.accessibilityIdentifier("vision-probe-kind")
                    if !kind.isComponent {
                        Picker("言語", selection: $main) { ForEach(ExecutionBackend.allCases) { Text($0.rawValue).tag($0) } }
                        Picker("画像", selection: $vision) { ForEach(ExecutionBackend.allCases) { Text($0.rawValue).tag($0) } }
                        Text("同梱のJPEGを公式Swift APIへ直接渡します。写真選択、画像変換、アプリの添付処理を通しません。正方形は512×512、縦長は1200×1600です。")
                            .font(.caption).foregroundStyle(.secondary)
                    } else {
                        Text("同じモデルからエンコーダーまたはアダプターのバイト列をそのまま取り出し、合成テンソルで単独実行します。組み込みCPUではXNNPACKを使いません。これは画像の内容に回答するテストではありません。")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }.disabled(running)
                Section {
                    Button(running ? "検証を実行しています…" : "この構成で1回検証") { run() }
                        .disabled(running || chats.isGenerating).accessibilityIdentifier("run-vision-probe")
                    if running { ProgressView() }
                    if !result.isEmpty { Text(result).font(.subheadline).textSelection(.enabled) }
                    Text("XNNPACKの失敗を確認したら、同じコンポーネントの組み込みCPUと比較します。組み込みCPUの結果は、そのまま会話APIの成功を意味しません。")
                        .font(.caption).foregroundStyle(.secondary)
                    ShareLink(item: InferenceDiagnostic.historyURL) { Label("比較結果と診断を共有", systemImage: "square.and.arrow.up") }
                }
            }
            .navigationTitle("画像の最小再現テスト").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完了") { dismiss() }.disabled(running) } }
        }.interactiveDismissDisabled(running)
    }
    private func run() {
        #if POCKET_PREVIEW
        result = "UI検証用アプリではネイティブ推論を実行しません。"
        #else
        guard let spec = ModelSpec.find(modelID) else { return }
        running = true; result = ""
        Task {
            defer { running = false }
            do { result = try await chats.runVisionProbe(model: spec, kind: kind, main: main, vision: vision) }
            catch { result = "検証失敗：\(error.localizedDescription)\n比較結果と診断を共有して、失敗段階を確認してください。" }
        }
        #endif
    }
}
