import SwiftUI
import UIKit

enum Theme {
    static let accent = Color(uiColor: .systemBlue)
    static let incoming = Color(uiColor: UIColor { traits in
        traits.userInterfaceStyle == .dark
            ? UIColor(red: 0.16, green: 0.16, blue: 0.17, alpha: 1)
            : UIColor(red: 0.91, green: 0.91, blue: 0.92, alpha: 1)
    })
    static let inputBorder = Color(uiColor: .separator)
    static let chatBackground = Color(uiColor: .systemBackground)
    static let canvas = Color(uiColor: .systemGroupedBackground)
    static let card = Color(uiColor: .secondarySystemGroupedBackground)
}

enum ChatMetrics {
    static let control: CGFloat = 44
    static let icon: CGFloat = 20
    static let gutter: CGFloat = 12
    static let controlGap: CGFloat = 12
    static let jumpGap: CGFloat = 24
    static let bubbleVertical: CGFloat = 7
    static let bubbleInset: CGFloat = 12
    static let bubbleTailInset: CGFloat = 18
    static let messageFont = Font.callout
}

/// A real backdrop material, feathered into the conversation. It is separate
/// from Liquid Glass controls so neither text nor controls are blurred.
struct ChatChromeBackdrop: View {
    let edge: VerticalEdge

    var body: some View {
        NativeChromeBlur(edge: edge, feather: 32)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

/// Mask the native effect view itself. A SwiftUI mask can flatten a material
/// into a tinted layer instead of sampling and blurring the live conversation.
private struct NativeChromeBlur: UIViewRepresentable {
    let edge: VerticalEdge
    let feather: CGFloat
    func makeUIView(context: Context) -> ChromeBlurContainer {
        let view = ChromeBlurContainer()
        view.isUserInteractionEnabled = false
        return view
    }
    func updateUIView(_ view: ChromeBlurContainer, context: Context) {
        view.edge = edge
        view.feather = feather
        view.setNeedsLayout()
    }
}

/// Window insets stay correct after SwiftUI has consumed the bar's safe area.
/// Position the effect as a native subview so its extended area is preserved.
private final class ChromeBlurContainer: UIView {
    var edge: VerticalEdge = .top
    var feather: CGFloat = 32
    private let blur = ChromeBlurView(effect: UIBlurEffect(style: .systemThinMaterial))

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    private func setup() {
        isOpaque = false
        clipsToBounds = false
        blur.isUserInteractionEnabled = false
        addSubview(blur)
    }
    override func didMoveToWindow() {
        super.didMoveToWindow()
        setNeedsLayout()
    }
    override func safeAreaInsetsDidChange() {
        super.safeAreaInsetsDidChange()
        setNeedsLayout()
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        let insets = window?.safeAreaInsets ?? safeAreaInsets
        let extensionHeight = edge == .top ? insets.top : insets.bottom
        blur.edge = edge
        blur.feather = feather
        blur.frame = CGRect(x: 0, y: edge == .top ? -extensionHeight : -feather,
                            width: bounds.width, height: bounds.height + extensionHeight + feather)
        blur.setNeedsLayout()
    }
}

private final class ChromeBlurView: UIVisualEffectView {
    var edge: VerticalEdge = .top
    var feather: CGFloat = 32
    private let gradientMask = ChromeGradientMask()
    private var maskedBounds = CGRect.zero
    private var maskedEdge: VerticalEdge = .top
    private var maskedFeather: CGFloat = -1

    override func layoutSubviews() {
        super.layoutSubviews()
        guard bounds != maskedBounds || edge != maskedEdge || feather != maskedFeather else { return }
        maskedBounds = bounds
        maskedEdge = edge
        maskedFeather = feather
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        gradientMask.frame = bounds
        let gradient = gradientMask.layer as! CAGradientLayer
        gradient.colors = [UIColor.black.cgColor, UIColor.black.cgColor,
                           UIColor.black.withAlphaComponent(0.6).cgColor, UIColor.clear.cgColor]
        let fadeStart = max(0, 1 - feather / max(1, bounds.height))
        gradient.locations = [0, NSNumber(value: Double(fadeStart)),
                              NSNumber(value: Double((1 + fadeStart) / 2)), 1]
        gradient.startPoint = CGPoint(x: 0.5, y: edge == .top ? 0 : 1)
        gradient.endPoint = CGPoint(x: 0.5, y: edge == .top ? 1 : 0)
        // UIKit copies an effect view's mask. Reapply it when the size changes,
        // with the values recorded above to avoid recursive layout updates.
        mask = nil
        mask = gradientMask
        CATransaction.commit()
    }
}

private final class ChromeGradientMask: UIView {
    override class var layerClass: AnyClass { CAGradientLayer.self }
}

struct GemmaMark: View {
    var size: CGFloat = 40
    var letter = "G"
    var body: some View {
        Text(letter)
            .font(.system(size: size * 0.50, weight: .medium, design: .rounded))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(LinearGradient(colors: [Color(uiColor: .systemGray3), Color(uiColor: .systemGray)],
                                       startPoint: .top, endPoint: .bottom), in: Circle())
            .accessibilityHidden(true)
    }
}

/// Use Apple's glass material on iOS 26 and a native material on older iOS.
struct ChatGlassSurface<S: Shape>: ViewModifier {
    var shape: S
    var interactive: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.glassEffect(.regular.interactive(interactive), in: shape)
        } else {
            content.background(.regularMaterial, in: shape)
                .overlay { shape.stroke(Theme.inputBorder.opacity(0.4), lineWidth: 0.5) }
        }
    }
}

struct ChatGlassGroup<Content: View>: View {
    private let spacing: CGFloat
    private let content: Content

    init(spacing: CGFloat = 6, @ViewBuilder content: () -> Content) {
        self.spacing = spacing
        self.content = content()
    }

    @ViewBuilder var body: some View {
        if #available(iOS 26.0, *) {
            GlassEffectContainer(spacing: spacing) { content }
        } else {
            content
        }
    }
}

/// Let the native button style own touch feedback and the hit target.
struct ChatCircleButton<Label: View>: View {
    private let action: () -> Void
    private let label: Label
    init(action: @escaping () -> Void, @ViewBuilder label: () -> Label) {
        self.action = action
        self.label = label()
    }
    @ViewBuilder var body: some View {
        if #available(iOS 26.0, *) {
            // The regular style adds its own padding. A 30pt label layout
            // produces a 44pt glass circle; the symbol itself remains 20pt.
            Button(action: action) { label.frame(width: 30, height: 30) }
                .buttonStyle(.glass).buttonBorderShape(.circle).controlSize(.regular)
                .frame(width: ChatMetrics.control, height: ChatMetrics.control)
        } else {
            Button(action: action) {
                label.frame(width: ChatMetrics.control, height: ChatMetrics.control).contentShape(Circle())
                    .chatGlass(in: Circle())
            }
            .buttonStyle(.plain)
        }
    }
}

extension View {
    /// Bars reserve reading space. The chrome owns its feathered backdrop.
    @ViewBuilder func chatBars<Top: View, Bottom: View>(@ViewBuilder top: () -> Top,
                                                       @ViewBuilder bottom: () -> Bottom) -> some View {
        if #available(iOS 26.0, *) {
            self.safeAreaBar(edge: .top, spacing: 0, content: top)
                .safeAreaBar(edge: .bottom, spacing: 0, content: bottom)
        } else {
            self.safeAreaInset(edge: .top, spacing: 0, content: top)
                .safeAreaInset(edge: .bottom, spacing: 0, content: bottom)
        }
    }

    @ViewBuilder func chatScrollEdges() -> some View {
        if #available(iOS 26.0, *) {
            self.scrollClipDisabled().scrollEdgeEffectHidden(true, for: .vertical)
        } else { self }
    }

    @ViewBuilder func chatGlassIdentity(_ id: String, in namespace: Namespace.ID,
                                       reduceMotion: Bool = false) -> some View {
        if #available(iOS 26.0, *) {
            self.glassEffectID(id, in: namespace)
                .glassEffectTransition(reduceMotion ? .identity : .matchedGeometry)
        } else { self }
    }

    func chatGlass<S: Shape>(in shape: S, interactive: Bool = false) -> some View {
        modifier(ChatGlassSurface(shape: shape, interactive: interactive))
    }

    @ViewBuilder func chatChromeBackground() -> some View {
        if #available(iOS 26.0, *) { self }
        else { background(.ultraThinMaterial) }
    }
}

