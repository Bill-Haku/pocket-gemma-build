import SwiftUI
import UIKit
import PocketCore

/// Scroll geometry changes as the lazy stack measures rows. Retain precise
/// position without invalidating that stack for every measurement; publish
/// only the change that controls the jump button.
@MainActor final class ChatScrollState: ObservableObject {
    private var policy = ChatScrollPolicy()
    @Published private(set) var followsLatest = true
    var shouldFollowStream: Bool { policy.shouldFollowStream }

    func observe(distanceFromBottom: Double) {
        policy.observe(distanceFromBottom: distanceFromBottom)
        publishFollowChange()
    }
    func setUserScrolling(_ scrolling: Bool) {
        policy.setUserScrolling(scrolling)
        publishFollowChange()
    }
    func requestLatest() {
        policy.requestLatest()
        publishFollowChange()
    }
    private func publishFollowChange() {
        if followsLatest != policy.followsLatest {
            followsLatest = policy.followsLatest
        }
    }
}

// The system accessibility value is read-only. Only the separate preview
// target supplies this override; the installed app follows the system value.
private struct ChatPreviewReduceMotionKey: EnvironmentKey {
    static let defaultValue = false
}
extension EnvironmentValues {
    var chatPreviewReduceMotion: Bool {
        get { self[ChatPreviewReduceMotionKey.self] }
        set { self[ChatPreviewReduceMotionKey.self] = newValue }
    }
}

enum ChatMotion {
    // Public SwiftUI springs, not Apple's private Messages curves.
    static let send = Animation.spring(duration: 0.38, bounce: 0.08)
    static let menu = Animation.spring(duration: 0.34, bounce: 0.06)
    static let resize = Animation.smooth(duration: 0.22)
    static let scroll = Animation.smooth(duration: 0.2)
    static let glassSeparation = Animation.spring(duration: 0.46, bounce: 0.06)
}

struct ChatTimestampReveal: ViewModifier {
    let onChanged: (CGFloat) -> Void
    let onEnded: () -> Void
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            content.gesture(TimestampPan(onChanged: onChanged, onEnded: onEnded))
        } else {
            content
        }
    }
}

/// Reject rightward pans before recognition, so the system back gesture can
/// complete. Ignoring their translation after a SwiftUI DragGesture has begun
/// still leaves an active recognizer competing with the navigation controller.
@available(iOS 18.0, *)
private struct TimestampPan: UIGestureRecognizerRepresentable {
    let onChanged: (CGFloat) -> Void
    let onEnded: () -> Void
    func makeCoordinator(converter: CoordinateSpaceConverter) -> Coordinator { Coordinator() }
    func makeUIGestureRecognizer(context: Context) -> UIPanGestureRecognizer {
        let pan = UIPanGestureRecognizer()
        pan.maximumNumberOfTouches = 1
        pan.cancelsTouchesInView = false
        pan.delegate = context.coordinator
        return pan
    }
    func handleUIGestureRecognizerAction(_ pan: UIPanGestureRecognizer, context: Context) {
        switch pan.state {
        case .began, .changed:
            onChanged(min(1, max(0, -pan.translation(in: pan.view).x / 90)))
        case .ended, .cancelled, .failed:
            onEnded()
        default: break
        }
    }
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            guard let pan = gestureRecognizer as? UIPanGestureRecognizer else { return false }
            let velocity = pan.velocity(in: pan.view)
            return velocity.x < -abs(velocity.y)
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { true }
    }
}

struct ChatScrollObserver: ViewModifier {
    let onDistance: (Double) -> Void
    let onUserScrolling: (Bool) -> Void
    var onLayout: () -> Void = {}
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            content
                .onScrollGeometryChange(for: ScrollMeasurement.self) { geometry in
                    ScrollMeasurement(distance: Double(max(0, geometry.contentSize.height + geometry.contentInsets.bottom
                        - geometry.contentOffset.y - geometry.containerSize.height)),
                        contentHeight: geometry.contentSize.height, viewportHeight: geometry.containerSize.height)
                } action: { old, new in
                    onDistance(new.distance)
                    if abs(old.contentHeight - new.contentHeight) > 0.5 || abs(old.viewportHeight - new.viewportHeight) > 0.5 { onLayout() }
                }
                .onScrollPhaseChange { _, phase in
                    onUserScrolling(phase == .interacting || phase == .decelerating)
                }
        } else {
            content.simultaneousGesture(DragGesture().onChanged { _ in
                onUserScrolling(true)
            }.onEnded { _ in onUserScrolling(false) })
        }
    }
}

private struct ScrollMeasurement: Equatable {
    let distance: Double
    let contentHeight: CGFloat
    let viewportHeight: CGFloat
}

/// Animate only the newly sent row. No overlay geometry is fed back into the
/// scroll layout, and revisiting an older row does not replay its arrival.
struct OutgoingArrival: ViewModifier {
    let animate: Bool
    @State private var progress: CGFloat
    init(animate: Bool) { self.animate = animate; _progress = State(initialValue: animate ? 0 : 1) }
    func body(content: Content) -> some View {
        content.scaleEffect(0.86 + 0.14 * progress, anchor: .bottomTrailing)
            .offset(y: 22 * (1 - progress)).opacity(Double(progress))
            .onAppear {
                guard progress < 1 else { return }
                withAnimation(ChatMotion.send) { progress = 1 }
            }
    }
}

struct ComposerHeightKey: PreferenceKey {
    static let defaultValue: CGFloat = ChatMetrics.control
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}
struct ConversationBottomKey: PreferenceKey {
    static var defaultValue: CGFloat { 0 }
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}
