import SwiftUI
import PocketCore

struct ReplyText: View {
    let text: String
    let isStreaming: Bool
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion

    @ViewBuilder var body: some View {
        if #available(iOS 18.0, *), !systemReduceMotion && !previewReduceMotion {
            RevealingReplyText(text: text, isStreaming: isStreaming)
        } else {
            Text(text)
        }
    }
}

@available(iOS 18.0, *)
private struct RevealingReplyText: View {
    let text: String
    let isStreaming: Bool
    @State private var buffer: ReplyRevealBuffer

    init(text: String, isStreaming: Bool) {
        self.text = text
        self.isStreaming = isStreaming
        var initial = ReplyRevealBuffer(text: isStreaming ? "" : text)
        if isStreaming { initial.update(text, at: Date().timeIntervalSinceReferenceDate) }
        _buffer = State(initialValue: initial)
    }

    private var markedText: Text {
        buffer.segments.reduce(Text(buffer.settledText)) { result, segment in
            result + Text(segment.text).customAttribute(ReplyArrival(arrivedAt: segment.arrivedAt))
        }
    }

    var body: some View {
        Group {
            if !isStreaming && buffer.segments.isEmpty {
                Text(text).textSelection(.enabled)
            } else {
                TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: buffer.segments.isEmpty)) { timeline in
                    markedText.textRenderer(ReplyAppearanceRenderer(now: timeline.date.timeIntervalSinceReferenceDate))
                }
                // The selectable system text view bypasses custom rendering
                // on the tested runtime. Restore selection once the final
                // arriving characters have finished becoming clear.
                .textSelection(.disabled)
            }
        }
        .onChange(of: text) { _, newest in
            buffer.update(newest, at: Date().timeIntervalSinceReferenceDate)
        }
        .task(id: buffer.animationDeadline) {
            guard let deadline = buffer.animationDeadline else { return }
            do {
                try await Task.sleep(for: .seconds(max(0, deadline - Date().timeIntervalSinceReferenceDate)))
            } catch { return }
            buffer.settle(at: Date().timeIntervalSinceReferenceDate)
        }
    }
}

@available(iOS 18.0, *)
private struct ReplyArrival: TextAttribute {
    let arrivedAt: TimeInterval
}

@available(iOS 18.0, *)
private struct ReplyAppearanceRenderer: TextRenderer {
    let now: TimeInterval

    func draw(layout: Text.Layout, in context: inout GraphicsContext) {
        for line in layout {
            for run in line {
                guard let arrival = run[ReplyArrival.self] else {
                    context.draw(run)
                    continue
                }
                let progress = min(1, max(0, (now - arrival.arrivedAt) / ReplyRevealBuffer.duration))
                let eased = progress * progress * (3 - 2 * progress)
                var copy = context
                copy.opacity *= 0.25 + 0.75 * eased
                if progress < 1 { copy.addFilter(.blur(radius: 2.8 * (1 - eased))) }
                copy.draw(run)
            }
        }
    }
}
