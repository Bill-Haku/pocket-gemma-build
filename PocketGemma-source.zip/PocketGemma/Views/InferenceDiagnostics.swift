import SwiftUI
import os
import PocketCore

/// Local, bounded diagnostics. Never record prompts, replies, image bytes,
/// attachment names, Apple IDs, or the app's full sandbox path.
struct InferenceDiagnostic: Codable, Sendable {
    struct Event: Codable, Sendable {
        let stage: String; let elapsedSeconds: Double; let availableMemoryBytes: UInt64
    }
    struct Failure: Codable, Sendable {
        let stage: String; let nativeError: String
        let visionTokens: Int?; let visionBackend: String?
    }
    let startedAt: Date
    let appVersion: String
    let runtime: String
    let modelID: String
    let modelSHA256: String
    let system: String
    let device: String
    let physicalMemory: UInt64
    let mainBackend: String
    let visionBackend: String?
    let contextTokens: Int
    let visionTokens: Int?
    let imageCount: Int
    var events: [Event] = []
    var visionSignatures: [Int]?
    var result = "running"
    var failureKind: NativeFailureKind?
    var nativeError: String?
    var availableMemoryAtFailure: UInt64?
    var priorFailures: [Failure] = []
    var stage: String { events.last?.stage ?? "validation" }

    init(plan: InferenceEnginePlan, imageCount: Int, previous: Self? = nil) {
        startedAt = Date(); runtime = InferenceEnginePlan.runtimeVersion
        let bundle = Bundle.main
        appVersion = "\(bundle.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "unknown") (\(bundle.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "unknown"))"
        modelID = plan.modelID; modelSHA256 = plan.modelSHA256
        mainBackend = plan.backend.rawValue; visionBackend = plan.visionBackend?.rawValue
        contextTokens = plan.maxTokens; visionTokens = plan.visualTokenBudget
        self.imageCount = imageCount
        system = ProcessInfo.processInfo.operatingSystemVersionString
        device = DeviceOverview.identifier
        physicalMemory = ProcessInfo.processInfo.physicalMemory
        if let previous, previous.modelID == modelID, previous.result == "failed",
           Date().timeIntervalSince(previous.startedAt) < 120, let error = previous.nativeError {
            priorFailures = Array((previous.priorFailures + [Failure(stage: previous.stage, nativeError: error,
                visionTokens: previous.visionTokens, visionBackend: previous.visionBackend)]).suffix(2))
        }
    }

    mutating func advance(_ stage: String) {
        if events.count < 16 { events.append(Event(stage: stage, elapsedSeconds: Date().timeIntervalSince(startedAt),
            availableMemoryBytes: UInt64(os_proc_available_memory()))) }
        save()
    }
    static var fileURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("PocketGemma/last-inference.json")
    }
    func save() {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        // Diagnostic IO must not change the outcome of inference.
        try? FileManager.default.createDirectory(at: Self.fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        if let data = try? encoder.encode(self) {
            try? data.write(to: Self.fileURL, options: [.atomic, .completeFileProtectionUnlessOpen])
        }
    }
    static func load() -> Self? {
        guard let handle = try? FileHandle(forReadingFrom: fileURL) else { return nil }
        defer { try? handle.close() }
        guard let data = try? handle.read(upToCount: 32_768) else { return nil }
        let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
        return try? decoder.decode(Self.self, from: data)
    }
    static func sanitize(_ error: String) -> String {
        // Preserve official runtime source locations; redact user/device paths.
        var text = error.replacingOccurrences(of: NSHomeDirectory(), with: "<app>")
        if let pattern = try? NSRegularExpression(pattern: #"(?:/private)?/var/(?:mobile|folders)/[^\s\"\)]+"#) {
            text = pattern.stringByReplacingMatches(in: text, range: NSRange(text.startIndex..., in: text), withTemplate: "<local-file>")
        }
        return GenerationSettings.prefix(text, byteLimit: 6000)
    }
}

struct InferenceDiagnosticsCard: View {
    @State private var latest = InferenceDiagnostic.load()
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("推論の診断", systemImage: "stethoscope").font(.headline)
            Text("直近の実行段階、モデル、GPU・CPU設定とエラーを端末内に保存します。会話本文や添付画像は含みません。")
                .font(.caption).foregroundStyle(.secondary)
            if let latest {
                Text("\(latest.modelID) · \(latest.stage) · \(latest.result)")
                    .font(.caption).textSelection(.enabled)
                if let error = latest.nativeError { Text(error).font(.caption).foregroundStyle(.secondary).textSelection(.enabled) }
                ShareLink(item: InferenceDiagnostic.fileURL) { Label("診断ファイルを共有", systemImage: "square.and.arrow.up") }
                    .font(.subheadline)
            } else { Text("モデルを実行すると診断が表示されます。").font(.caption).foregroundStyle(.secondary) }
            Button("診断を再読み込み") { latest = InferenceDiagnostic.load() }.font(.caption)
        }.padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
    }
}
