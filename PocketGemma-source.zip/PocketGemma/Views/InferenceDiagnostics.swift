import SwiftUI
import os
import PocketCore

/// Local, bounded diagnostics. Never record prompts, replies, image bytes,
/// attachment names, Apple IDs, or the app's full sandbox path.
struct InferenceDiagnostic: Codable, Sendable {
    struct Event: Codable, Sendable {
        let stage: String; let elapsedSeconds: Double; let availableMemoryBytes: UInt64
    }
    struct Failure: Codable, Sendable {
        let stage: String; let nativeError: String
        let visionTokens: Int?; let visionBackend: String?
    }
    let startedAt: Date
    var runID: UUID?
    let appVersion: String
    let runtime: String
    let modelID: String
    let modelSHA256: String
    let system: String
    let device: String
    let physicalMemory: UInt64
    let mainBackend: String
    let visionBackend: String?
    let contextTokens: Int
    let visionTokens: Int?
    let imageCount: Int
    var events: [Event] = []
    var visionSignatures: [Int]?
    var result = "running"
    var failureKind: NativeFailureKind?
    var nativeError: String?
    var availableMemoryAtFailure: UInt64?
    var priorFailures: [Failure] = []
    var nativeLogLines: [String]?
    var nativeLogCapture: String?
    var nativeLogTruncated: Bool?
    var nativeLogDiscardedLines: Int?
    var evidence: NativeLogEvidence?
    var runtimeBuild: RuntimeBuildProvenance?
    var cacheIdentity: String?
    var engineWasReused: Bool?
    var conversationWasReused: Bool?
    var maxOutputTokens: Int?
    var topK: Int?
    var topP: Double?
    var temperature: Double?
    var thinking: Bool?
    var speculation: Bool?
    var cpuThreadPolicy: String?
    var activationPrecision: String?
    var visionAdapterBackend: String?
    var inputPath: String?
    var inputImageDimensions: [String]?
    var componentKernelMode: String?
    var testedComponent: String?
    var componentStatusCode: Int?
    var componentTensorLayout: String?
    var outputFinite: Bool?
    var sectionSHA256: String?
    var inputFixtureSHA256: String?
    var sampledPeakFootprint: UInt64?
    var sampledMinimumAvailableMemory: UInt64?
    var memorySampleCount: Int?
    var stage: String { events.last?.stage ?? "validation" }

    init(plan: InferenceEnginePlan, imageCount: Int, settings: GenerationSettings? = nil, previous: Self? = nil) {
        startedAt = Date(); runtime = InferenceEnginePlan.runtimeVersion
        runID = UUID()
        let bundle = Bundle.main
        appVersion = "\(bundle.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "unknown") (\(bundle.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "unknown"))"
        modelID = plan.modelID; modelSHA256 = plan.modelSHA256
        mainBackend = plan.backend.rawValue; visionBackend = plan.visionBackend?.rawValue
        contextTokens = plan.maxTokens; visionTokens = plan.visualTokenBudget
        self.imageCount = imageCount
        system = ProcessInfo.processInfo.operatingSystemVersionString
        device = DeviceOverview.identifier
        physicalMemory = ProcessInfo.processInfo.physicalMemory
        runtimeBuild = RuntimeBuildProvenance.load()
        cacheIdentity = plan.cacheComponent
        cpuThreadPolicy = "language: SDK default; vision: official 0.18 executor fixed 4 threads"
        activationPrecision = "model/runtime default (no override)"
        if [ModelSpec.e2b.id, ModelSpec.e4b.id].contains(modelID), plan.visionBackend != nil {
            visionAdapterBackend = "CPU (pinned model metadata)"
        }
        maxOutputTokens = settings?.maxOutputTokens; topK = settings?.topK
        topP = settings?.topP; temperature = settings?.temperature
        thinking = settings?.enableThinking; speculation = settings?.enableSpeculativeDecoding
        if let previous, previous.modelID == modelID, previous.result == "failed",
           Date().timeIntervalSince(previous.startedAt) < 120, let error = previous.nativeError {
            priorFailures = Array((previous.priorFailures + [Failure(stage: previous.stage, nativeError: error,
                visionTokens: previous.visionTokens, visionBackend: previous.visionBackend)]).suffix(2))
        }
    }

    mutating func recordNativeLog(_ log: NativeLogBuffer?, error: String = "") {
        nativeLogCapture = log == nil ? "stderr capture unavailable; Swift native error only"
            : "stderr operational allowlist; OSLog/filtered lines unavailable"
        nativeLogLines = log?.lines ?? []
        nativeLogTruncated = log?.truncated
        nativeLogDiscardedLines = log?.discardedLines
        evidence = NativeLogEvidence(error: error, logLines: nativeLogLines ?? [])
    }

    mutating func recordMemory(_ memory: (peak: UInt64, minimum: UInt64, samples: Int)) {
        sampledPeakFootprint = memory.peak
        sampledMinimumAvailableMemory = memory.minimum
        memorySampleCount = memory.samples
    }

    mutating func advance(_ stage: String) {
        if events.count < 16 { events.append(Event(stage: stage, elapsedSeconds: Date().timeIntervalSince(startedAt),
            availableMemoryBytes: UInt64(os_proc_available_memory()))) }
        save()
    }
    static var fileURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("PocketGemma/last-inference.json")
    }
    static var historyURL: URL { fileURL.deletingLastPathComponent().appendingPathComponent("inference-comparisons.json") }
    func save() {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        // Diagnostic IO must not change the outcome of inference.
        try? FileManager.default.createDirectory(at: Self.fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        if let data = try? encoder.encode(self) {
            try? data.write(to: Self.fileURL, options: [.atomic, .completeFileProtectionUnlessOpen])
        }
        var history = Self.history()
        history.removeAll { runID != nil ? $0.runID == runID : $0.startedAt == startedAt }
        history.append(self)
        history = Array(history.suffix(24))
        if let data = try? encoder.encode(history), data.count <= 768_000 {
            try? data.write(to: Self.historyURL, options: [.atomic, .completeFileProtectionUnlessOpen])
        }
    }
    static func load() -> Self? {
        guard let handle = try? FileHandle(forReadingFrom: fileURL) else { return nil }
        defer { try? handle.close() }
        guard let data = try? handle.read(upToCount: 64_000) else { return nil }
        let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
        return try? decoder.decode(Self.self, from: data)
    }
    static func history() -> [Self] {
        guard let handle = try? FileHandle(forReadingFrom: historyURL) else { return load().map { [$0] } ?? [] }
        defer { try? handle.close() }
        guard let data = try? handle.read(upToCount: 768_001), data.count <= 768_000 else { return [] }
        let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
        return Array(((try? decoder.decode([Self].self, from: data)) ?? []).suffix(24))
    }
    static func sanitize(_ error: String) -> String {
        // Preserve official runtime source locations; redact user/device paths.
        let text = NativeLogBuffer.redact(error.replacingOccurrences(of: NSHomeDirectory(), with: "<app>"))
        return GenerationSettings.prefix(text, byteLimit: 6000)
    }
}

struct InferenceDiagnosticsCard: View {
    @State private var showProbe = false
    @State private var latest = InferenceDiagnostic.load()
    @State private var history = InferenceDiagnostic.history()
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("推論の診断", systemImage: "stethoscope").font(.headline)
            Text("直近24回の構成・実行段階・メモリ・ネイティブエラーを端末内に保存します。会話本文や添付画像は含みません。")
                .font(.caption).foregroundStyle(.secondary)
            Button { showProbe = true } label: { Label("画像の最小再現テスト", systemImage: "testtube.2") }
                .font(.subheadline).accessibilityIdentifier("open-vision-probe")
            if let latest {
                Text("\(latest.modelID) · \(latest.stage) · \(latest.result)")
                    .font(.caption).textSelection(.enabled)
                if let component = latest.testedComponent {
                    Text("単体検証: \(component) · \(latest.componentKernelMode ?? "不明")（言語エンジンは実行していません）")
                        .font(.caption).textSelection(.enabled)
                } else {
                    Text("言語 \(latest.mainBackend) / 画像 \(latest.visionBackend ?? "なし") · Context \(latest.contextTokens) · Vision \(latest.visionTokens.map(String.init) ?? "なし")")
                        .font(.caption).textSelection(.enabled)
                }
                Text("失敗デリゲート: \(latest.evidence?.failedDelegate ?? "ログに明記なし")\n原因の演算子: \(latest.evidence?.operatorNames.joined(separator: ", ").nilIfEmpty ?? "ログに明記なし")")
                    .font(.caption).textSelection(.enabled)
                if let nodes = latest.evidence?.delegateNodes, !nodes.isEmpty {
                    Text("委譲ノード: \(nodes.map(String.init).joined(separator: ", "))（原因の演算子番号とは限りません）").font(.caption).foregroundStyle(.secondary)
                }
                if let phase = latest.evidence?.xnnpackPhase {
                    Text("XNNPACK内の失敗段階: \(phase)（メモリ不足を意味するとは限りません）").font(.caption)
                }
                if let patches = latest.evidence?.preparedImagePatches {
                    Text("ネイティブログの画像パッチ数: \(patches.map(String.init).joined(separator: ", "))").font(.caption)
                }
                if let input = latest.inputPath { Text("入力経路: \(input)").font(.caption) }
                if let peak = latest.sampledPeakFootprint {
                    Text("アプリ使用メモリの観測ピーク: \(Double(peak)/1_000_000_000, specifier: "%.2f") GB（200 ms間隔）").font(.caption)
                }
                if let tensors = latest.componentTensorLayout {
                    Text(tensors).font(.system(.caption, design: .monospaced)).textSelection(.enabled)
                }
                if let error = latest.nativeError { Text(error).font(.caption).foregroundStyle(.secondary).textSelection(.enabled) }
                DisclosureGroup("ネイティブログとライブラリ情報") {
                    Text(latest.nativeLogCapture ?? "旧版の診断です").font(.caption).foregroundStyle(.secondary)
                    if let lines = latest.nativeLogLines, !lines.isEmpty {
                        Text(lines.joined(separator: "\n")).font(.system(.caption, design: .monospaced)).textSelection(.enabled)
                    } else { Text("利用できる追加のstderrログがありません。").font(.caption) }
                    if let build = latest.runtimeBuild {
                        Text("LiteRT-LM \(build.runtimeVersion) · \(build.packageRevision)\n\(build.target) · \(build.sdk)\nネイティブのビルドフラグ: 公式バイナリ内に完全な情報なし")
                            .font(.caption).textSelection(.enabled)
                        Text("実際のフレームワークのSHA256は共有ファイルに含まれます。").font(.caption)
                        if let sdk = build.nativeFiles.first?.nativeSDK {
                            Text("ネイティブバイナリのSDK: \(sdk) / 最低OS: \(build.nativeFiles.first?.minimumOS ?? "不明")").font(.caption)
                        }
                    } else { Text("このビルドにはバイナリの照合情報がありません。").font(.caption) }
                }.font(.caption)
                ShareLink(item: InferenceDiagnostic.historyURL) { Label("比較結果と診断を共有", systemImage: "square.and.arrow.up") }
                    .font(.subheadline)
                    .accessibilityIdentifier("share-inference-comparisons")
            } else { Text("モデルを実行すると診断が表示されます。").font(.caption).foregroundStyle(.secondary) }
            if !history.isEmpty {
                DisclosureGroup("構成ごとの結果（\(history.count)回）") {
                    ForEach(Array(history.reversed().enumerated()), id: \.offset) { _, record in
                        VStack(alignment: .leading, spacing: 3) {
                            Text("\(record.modelID) · \(record.testedComponent ?? "\(record.mainBackend)/\(record.visionBackend ?? "なし")") · \(record.result)")
                            Text("\(record.stage) · Context \(record.contextTokens) / Vision \(record.visionTokens ?? 0)")
                            Text(record.startedAt, style: .time).foregroundStyle(.secondary)
                        }.font(.caption).padding(.vertical, 3)
                    }
                }.font(.caption).accessibilityIdentifier("inference-comparison-history")
            }
            Text("比較は同じ画像・モデル・トークン数を使い、新しい会話で実行してください。演算子やデリゲートが明記されないエラーからは断定できません。")
                .font(.caption).foregroundStyle(.secondary)
            Button("診断を再読み込み") { latest = InferenceDiagnostic.load(); history = InferenceDiagnostic.history() }.font(.caption)
        }.padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
            .sheet(isPresented: $showProbe, onDismiss: { latest = InferenceDiagnostic.load(); history = InferenceDiagnostic.history() }) {
                VisionProbeView()
            }
    }
}

struct RuntimeBuildProvenance: Codable, Sendable {
    struct NativeFile: Codable, Sendable {
        let name: String; let sha256: String; let bytes: Int
        let architecture: String?; let platform: Int?; let nativeSDK: String?; let minimumOS: String?; let uuid: String?
    }
    let runtimeVersion: String
    let packageRevision: String
    let artifactURL: String
    let artifactSHA256: String
    let target: String
    let sdk: String
    let configuration: String
    let nativeFiles: [NativeFile]
    let upstreamLiteRTSourceRef: String
    let binaryCompilerFlags: String
    static func load() -> Self? {
        guard let url = Bundle.main.url(forResource: "runtime-build", withExtension: "json"),
              let data = try? Data(contentsOf: url), data.count < 32_768 else { return nil }
        return try? JSONDecoder().decode(Self.self, from: data)
    }
}

private extension String {
    var nilIfEmpty: String? { isEmpty ? nil : self }
}
