# 1.0.11 (12) vision configuration and diagnostics candidate

This build addresses confirmed shared E2B/E4B engine-budget/reuse/cache defects,
restricts selection to the visual signatures present in their pinned exports,
and adds local inference diagnostics. It preserves the installed model paths,
bundle ID, chats, text API, and model catalog.

The user's iPhone delegate failure is not yet certified resolved. Full native
macOS tests pass both models, but macOS GPU uses WebGPU and is not the same
runtime path as iPhone Metal. iOS-native regression results and physical-device
limitations are documented in `docs/VISION-INVESTIGATION.md`.

This is a candidate until build and regression checks finish. It is not a
claim of physical-device validation or exact Gallery iOS implementation parity.
