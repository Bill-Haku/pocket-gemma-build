# Pocket Gemma 1.0.15候補: 画像の資源共有とCPU実行経路

これは開発中の修正候補です。ビルド成功・推論成功・実機での解消を意味しません。

## 今回、区別できたこと

- 実機の会話では画像prefillのXNNPACK reshape失敗が発生する。
- アプリの画像変換を通さない同梱JPEGでも会話経路が失敗する。
- 別の試行では、mmapのENOMEMの直後にVision Encoderがnot found扱いになる。
  これはファイル内にEncoderが存在しないという証拠ではない。
- 同じE4BのEncoderをバイト単位で抽出した実機の単体テストでは、
  XNNPACK・組み込みCPUとも実行成功、出力は有限値だった。
  この合成テンソルの成功は、JPEGの内容を認識したことを意味しない。
- したがって演算子未対応・モデル欠落・物理RAM不足を根本原因として断定しない。
  会話時のモデル資源、重みキャッシュ、作業領域などの条件差を残す。

## 確認したネイティブ側の重複読み込み

公式0.18.0はEngineAdvancedImplでモデル資源とVision signatureを参照し、
ResourceManager::TryLoadingVisionExecutorは別のローダーを作るCreateオーバーロードを呼ぶ。
ResourceManagerのコンストラクターにはエンジンのModelResourcesが渡されるが、保持していない。
その結果、会話作成時に同じVisionセクションを再マッピングする。

候補では、この既存ModelResourcesを保持し、既存のCreate(settings, environment, resources)
を使う。エンジンはExecutionManagerを先に破棄するため、借用した資源の寿命を保てる。
資源を持たない単独クライアントの経路は残す。
Pocket GemmaのSwift APIは言語・画像とも同じ単一のモデルファイルを使用する。

E2B/E4BのVision Encoderは224,137,936バイト。モデル内の開始位置はそれぞれ
1,496,612,864 / 1,122,271,232で、16 KiBに整列している。
セクション範囲は固定モデルのファイルサイズ内にある。
この範囲の確認だけで実機の仮想アドレス空間に十分な空きがあるとは判断できない。
重複マッピングの削減が実機のENOMEM・reshapeを解消するかは未検証。

## 画像CPUの明示的な選択

従来のXNNPACKを既定値として保持する。追加の「互換（組み込みCPU）」は、
画像のEncoderとCPU AdapterだけをLiteRTの組み込みCPUで実行する。
言語側GPU/CPUとトークン数は変更せず、自動再試行はしない。
実機の単体テストでは組み込みCPUが遅いため、速度の注意を設定に表示する。

ネイティブは0.18.0のLM層を固定ソースから再ビルドする。
LiteRT C API・Metal・XNNPACK本体はチェックサムを照合した公式0.18.0を供給元とする。
新しいLMフレームワークと公式のランタイム供給元を別名にし、両方の実バイナリを照合する。
これはLiteRT/XNNPACK本体を修正済みに更新したという意味ではない。
Nightlyへの変更、モデル内部の書き換え、メモリ制限の変更は行わない。

## 検証計画と未検証事項

E2B・E4Bで同梱の正方形/縦長JPEGの既知の色・形を照合し、XNNPACK/組み込みCPUを比較する。
通常の添付処理では赤い四角・緑の円を交互に送り、定数の回答では通らない検証にする。
テキスト、モデル切り替え、不正JPEG後の復帰、連続実行時の物理/仮想メモリも確認する。
既存のUI操作・アニメーションの回帰テストも維持する。

実機の部品テストはE4B Encoderのみ確認済み。
実機のAdapter単体・E2Bの今回の比較・この候補の画像会話は未検証。
シミュレーターの成功を実機の成功として扱わない。
結果が揃うまで既存のRelease IPAとAltStore配信は更新しない。

## 公式公開実装との比較

モデルは固定した公式.litertlmを維持する。画像は公式SwiftのimageFile入力を使い、
ネイティブの画像前処理、Encoder、Adapterを通して言語モデルに渡す。
OCRの文字だけに置き換えない。
Galleryの公開リポジトリからiOS版の実バイナリ・モデルSHA256・実行フラグは確認できないため、
非公開部分を同一または異なると推定しない。

参照:
- https://github.com/google-ai-edge/LiteRT-LM/blob/v0.18.0/runtime/framework/resource_management/resource_manager.cc
- https://github.com/google-ai-edge/LiteRT-LM/blob/v0.18.0/runtime/executor/vision_litert_compiled_model_executor.cc
- https://github.com/google-ai-edge/LiteRT-LM/blob/v0.18.0/runtime/util/litert_lm_loader.cc
- https://github.com/google-ai-edge/LiteRT-LM/issues/2979
- https://github.com/google-ai-edge/LiteRT-LM/issues/2370

0.18.0が最新安定版であり、今回の実機症状に対する公式修正はリリースノートから確認できなかった。
