# Pocket Gemma 1.0.10 (11)

送信時は日本語入力を確定してから本文を取り出し、入力欄の消去とキーボードの終了を一緒に行います。返信の小さな更新は45ms単位にまとめ、吹き出しの再配置を減らします。スクロール時の慣性はUIKitの描画レイヤーで計算し、SwiftUIのスクロール位置や行の高さを変えません。Reduce Motionでは停止します。＋とメニューは同じGlassEffectContainerの識別子を共有し、iOS 26以降のLiquid Glassで形を変えます。会話一覧のタイトル下には薄い、境界のないぼかしを使います。

画像の推論はテキストのCPU設定にかかわらず、画像側・言語側ともMetal GPUを使用します。画像は768px以内に縮小し、現在と会話履歴を合わせて4枚以内に制限します。画像のテンソル割り当てに失敗し、まだ返信がない場合だけ、visual token budgetを70に減らして一度再試行します。スキャンPDFにはApple Visionの端末内OCRを使います（最大6ページ）。テキストPDF、Word .docx、UTF-8・UTF-16・Shift JISのテキストを読み込みます。長いファイルは本文の先頭4,000 UTF-8 bytesまでです。Wordの図や埋め込み画像は解析しません。ZIP全体は展開せず、既知の本文XMLだけをサイズ制限付きで読みます。

端末自動選択は端末識別子、物理メモリ、現在のアプリに許可されたメモリの余裕、CPUコア数、空き容量を使います。保存済みのモデルは再ダウンロード分の空き容量を要求しません。負荷と速度は保守的な目安で、実測ベンチマークではありません。Gemma 4 12Bは約6.88GBの固定版を追加しました。大量の実行メモリが必要な実験対応です。自動選択の対象から外し、読み込み前に余裕が足りなければ案内を表示します。iPhoneでの動作保証はありません。各モデルのアイコンを分け、アプリアイコンは白地に四色の吹き出しを使います。

iCloud保存は任意のiCloud Driveバックアップです。「ファイル」で保存先フォルダを選ぶと、会話と添付を自動保存します。初期状態はオフです。端末ごとのスナップショットを別々に保存し、別の端末では「履歴を復元」で追加読み込みします。CloudKitによるリアルタイム双方向同期ではありません。無料のAltStore署名でも使えるユーザー選択フォルダの方式です。復元は既存のローカル会話を消しません。モデル本体は送らず、バックアップのファイル名とパスを検証します。

同じアプリID app.pocketgemma.personal と保存先を維持します。公開用ソースには本人の写真、会話、動画、モデル、認証情報、秘密鍵、非公開リポジトリの履歴を含めません。

ビルド前の候補です。CIの結果を確認してからIPAとAltStoreソースを更新します。UIテストは製品と同じViewsと取り込み・バックアップ処理を使い、AI返信のみサンプルです。実機の画像推論、Gemma 4 12B、実際のiCloud転送、iOS 27のMessagesとのアニメーション完全一致は未確認です。

実装根拠: [LiteRT-LM 0.18](https://github.com/google-ai-edge/LiteRT-LM/releases/tag/v0.18.0)、[Google GalleryのGPU vision初期化](https://github.com/google-ai-edge/gallery/blob/main/Android/src/app/src/main/java/com/google/ai/edge/gallery/ui/llmchat/LlmChatModelHelper.kt)、[SwiftのCPU vision失敗報告](https://github.com/google-ai-edge/LiteRT-LM/issues/2979)、[12Bモデル配布元](https://huggingface.co/litert-community/gemma-4-12B-it-litert-lm)、[Appleのフォルダアクセス](https://developer.apple.com/documentation/uikit/providing-access-to-directories)、[Liquid Glassのカスタムビュー](https://developer.apple.com/documentation/SwiftUI/Applying-Liquid-Glass-to-custom-views)、[ZIPFoundation](https://github.com/weichsel/ZIPFoundation)。
