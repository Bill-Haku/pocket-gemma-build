# Public build inputs

This repository contains only reviewed source and synthetic test resources. The
original private repository and history, personal photographs, conversations,
model weights, credentials and signing material are not included.

Version 1.0.9, build 10 keeps bundle identifier app.pocketgemma.personal for AltStore
updates. The workflow uses a standard macOS runner, a 35-minute timeout and
one-day artifact retention. It builds an unsigned device IPA.

Checks include 30 core tests, 12 iPhone UI interaction tests and an iPad startup test, IPA validation fixtures
and a bounded-memory model verification probe. Simulator tests share production
views, the attachment importer and settings persistence, with sample AI services.
They do not run actual model inference. Inspect screenshots and interaction video
as well as test results before releasing an IPA.

The build has not completed at the time this candidate source is packaged.
