# Reviewed build inputs

1.0.11 (12) is a vision configuration/diagnostics candidate.
Physical iPhone image inference is unverified. See docs/VISION-INVESTIGATION.md.
Only audited code, generated assets, and synthetic fixtures are included.
User media, conversations, private Git history, credentials, signing files,
model weights, research downloads, and native test model caches are excluded.
