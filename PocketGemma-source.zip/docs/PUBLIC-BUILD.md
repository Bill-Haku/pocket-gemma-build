# Reviewed inputs for 1.0.13 (14)
Independent direct-JPEG and CPU/XNNPACK versus builtin component diagnostics.
See docs/UPDATE-1.0.13.md. Physical-device image recognition is unverified.
Includes audited code, public Apache-2.0 headers and generated test JPEGs.
Excludes user media/log files/conversations, credentials, signing files,
Git history, research downloads, native binary downloads and model weights.
