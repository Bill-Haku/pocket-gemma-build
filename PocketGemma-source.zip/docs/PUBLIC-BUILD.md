# Reviewed inputs for 1.0.14 (15)
Retain section mapping/not-found warnings, with existing privacy and log bounds.
See docs/UPDATE-1.0.14.md. Physical-device vision remains unverified.
No runtime/model/backend changes or automatic CPU fallback; no nightly trial.
Excludes user media, logs, conversations, credentials, signing files, Git
history, research downloads, native binary downloads and model weights.
