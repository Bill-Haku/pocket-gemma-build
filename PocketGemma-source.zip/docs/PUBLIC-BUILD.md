# Reviewed public build inputs

Version 1.0.10 (11) uses bundle ID app.pocketgemma.personal for AltStore updates.
The source contains only reviewed code and synthetic resources. User attachments,
conversations, model weights, credentials, signing files and private Git history
are excluded. This is a build candidate, not a verified release yet.

Checks cover 34 core tests, 17 iPhone UI tests, one iPad startup test,
IPA validation and model-verification memory. Views and attachment/backup IO are
shared with production; preview replies are synthetic. Physical model inference,
iOS 27 animation parity and actual iCloud transfer remain unverified.
The standard public macOS runner is free, timeout 45 minutes, retention one day.
