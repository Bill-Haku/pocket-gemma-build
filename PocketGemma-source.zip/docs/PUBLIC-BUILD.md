# Reviewed candidate inputs for 1.0.15 (16)
LM-layer resource sharing and explicitly selectable CPU vision kernels.
Model hashes, memory safeguards, text streaming and conversation storage retained.
Native runtime rebuild and semantic inference tests must succeed before an IPA.
Physical-device correction remains unverified until the user tests the candidate.
Excludes user media, diagnostics, conversations, credentials and model weights.
