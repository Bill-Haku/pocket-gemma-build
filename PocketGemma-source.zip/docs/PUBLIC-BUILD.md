# Public build inputs

This repository starts with a fresh history for public CI. The original private
repository, its historical source archives, logs and artifacts are not imported.

The release candidate is version 1.0.6, build 7, bundle identifier
`app.pocketgemma.personal`. The reviewed release candidate is the starting point for this package.
The native blur uses the bar bounds and only invalidates changed geometry.
Scroll positions are recorded without publishing every measurement to the UI. Development documents containing private build links were
omitted from this package.

The manual workflow uses a standard macOS runner with a 35-minute timeout.
Artifacts are retained for one day. The IPA is unsigned and contains no model
weights. No Apple ID, signing certificate or API key is required by this build.

Validation includes the core package tests, IPA validation fixtures, a bounded
memory verification probe, and six UI interaction tests. The UI tests use the
same production views with sample services. They do not validate actual model
inference on an iPhone or establish exact equivalence with Apple Messages.

Before release, inspect the UI screenshot artifacts as well as test results.
The latest safe-area blur change has not yet completed a macOS build at the time
this public source package is being prepared.
