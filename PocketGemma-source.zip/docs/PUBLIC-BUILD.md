# Reviewed build inputs

1.0.12 (13) adds independent vision backends and bounded native diagnostics.
See docs/UPDATE-1.0.12.md. Physical-device validation is pending.
Only audited code, generated assets, and synthetic fixtures are included.
User media, conversations, private Git history, credentials, signing files,
model weights, research downloads, and native test model caches are excluded.
