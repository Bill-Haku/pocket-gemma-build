"""Check actual packaged output, including architecture and bundled frameworks."""
import plistlib
import hashlib
import json
import struct
import sys
import zipfile

def check(path):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        base = "Payload/PocketGemma.app/"
        info = plistlib.loads(archive.read(base + "Info.plist"))
        executable = archive.read(base + info["CFBundleExecutable"])
        assert info["CFBundlePackageType"] == "APPL", "Bundle must be an iPhone app"
        assert "iPhoneOS" in info.get("CFBundleSupportedPlatforms", []), "Simulator apps cannot be sideloaded"
        assert info["CFBundleIdentifier"] == "app.pocketgemma.personal"
        magic, cpu = struct.unpack("<II", executable[:8])
        assert magic == 0xFEEDFACF and cpu == 0x0100000C, "Expected an ARM64 device executable"
        assert not any(name.endswith(".litertlm") for name in names), "Model must be downloaded on device"
        # Swift Package Manager embeds dynamic binary dependencies; static ones
        # are linked into the executable. Check any embedded framework is real.
        frameworks = [name for name in names if name.endswith(".framework/Info.plist")]
        for framework_plist in frameworks:
            details = plistlib.loads(archive.read(framework_plist))
            binary = framework_plist.removesuffix("Info.plist") + details["CFBundleExecutable"]
            assert binary in names, f"Missing framework binary: {binary}"
        if base + 'runtime-build.json' in names:
            receipt = json.loads(archive.read(base + 'runtime-build.json'))
            assert receipt['target'] == 'iphoneos'
            assert receipt['runtimeVersion'] == '0.18.0'
            assert receipt['artifactSHA256'] == 'd765b99592d4ec3d0c9e2bd69469454af06c834861340672da1891c0c121c347'
            for native in receipt['nativeFiles']:
                data = archive.read(base + native['name'])
                assert native['bytes'] == len(data) and native['sha256'] == hashlib.sha256(data).hexdigest(), 'Runtime receipt does not match embedded native bytes'
        print(f"IPA structure OK: {info['CFBundleIdentifier']}, ARM64, {len(frameworks)} embedded frameworks")

if __name__ == "__main__":
    check(sys.argv[1])

