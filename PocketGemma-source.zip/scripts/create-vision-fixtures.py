"""Generate public geometric JPEG fixtures, independent of user media."""
from pathlib import Path
from PIL import Image, ImageDraw
import hashlib, json

root=Path(__file__).resolve().parent.parent
out=root/'PocketGemma/Resources'; out.mkdir(exist_ok=True)
records=[]
for name,size in [('square',(512,512)),('portrait',(1200,1600))]:
    image=Image.new('RGB',size,'white'); draw=ImageDraw.Draw(image)
    side=int(min(size)*0.62); x=(size[0]-side)//2; y=(size[1]-side)//2
    draw.rectangle((x,y,x+side,y+side),fill=(235,20,30))
    path=out/f'vision-probe-{name}.jpg'; image.save(path,quality=85,optimize=False)
    records.append({'file':path.name,'width':size[0],'height':size[1],
                    'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(out/'vision-probe-fixtures.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
