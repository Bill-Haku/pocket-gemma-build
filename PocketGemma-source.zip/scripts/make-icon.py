"""Render the existing vector icon pipeline with the requested Messages colors."""
import json
import math
from pathlib import Path
from PIL import Image, ImageDraw

root = Path(__file__).resolve().parents[1]
catalog = root / "PocketGemma/Assets.xcassets"
icons = catalog / "AppIcon.appiconset"
icons.mkdir(parents=True, exist_ok=True)
design = root / "design"
design.mkdir(exist_ok=True)
path = "M512 180 C722 180 892 322 892 496 C892 670 722 810 512 810 C422 810 340 790 272 756 C210 794 150 824 116 830 C154 786 178 724 194 674 C154 622 132 560 132 496 C132 322 302 180 512 180 Z"
sources = [(512, 180, (239, 68, 75)), (146, 465, (250, 193, 24)),
           (430, 822, (31, 172, 87)), (875, 490, (28, 126, 245)), (570, 475, (42, 139, 247))]
gradients = "".join(f'<radialGradient id="g{i}" gradientUnits="userSpaceOnUse" cx="{x}" cy="{y}" r="480"><stop stop-color="rgb{color}" stop-opacity=".95"/><stop offset="1" stop-color="rgb{color}" stop-opacity="0"/></radialGradient>' for i, (x, y, color) in enumerate(sources))
layers = "".join(f'<rect width="1024" height="1024" fill="url(#g{i})"/>' for i in range(len(sources)))
(design / "AppIcon.svg").write_text(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><defs>{gradients}<clipPath id="bubble"><path d="{path}"/></clipPath></defs><rect width="1024" height="1024" fill="white"/><g clip-path="url(#bubble)"><rect width="1024" height="1024" fill="#2588f3"/>{layers}</g></svg>\n', encoding="utf-8")

curves = [((512,180),(722,180),(892,322),(892,496)), ((892,496),(892,670),(722,810),(512,810)),
          ((512,810),(422,810),(340,790),(272,756)), ((272,756),(210,794),(150,824),(116,830)),
          ((116,830),(154,786),(178,724),(194,674)), ((194,674),(154,622),(132,560),(132,496)),
          ((132,496),(132,322),(302,180),(512,180))]
points = []
for p0, p1, p2, p3 in curves:
    for index in range(80):
        t = index / 79; u = 1 - t
        points.append(tuple(3 * (u**3*p0[d] + 3*u*u*t*p1[d] + 3*u*t*t*p2[d] + t**3*p3[d]) for d in (0,1)))
mask = Image.new("L", (3072,3072), 0)
ImageDraw.Draw(mask).polygon(points, fill=255)
mask = mask.resize((1024,1024), Image.Resampling.LANCZOS)
color = Image.new("RGB", (1024,1024), (255,255,255))
pixels = color.load()
for y in range(170, 840):
    for x in range(105, 902):
        weights = [math.exp(-((x-cx)**2+(y-cy)**2)/36_000) for cx, cy, _ in sources]
        total = sum(weights)
        pixels[x,y] = tuple(round(sum(weight * source[2][d] for weight, source in zip(weights, sources))/total) for d in range(3))
image = Image.new("RGB", (1024,1024), "white")
image.paste(color, mask=mask)
image.save(icons / "AppIcon.png")
(catalog / "Contents.json").write_text(json.dumps({"info": {"author": "xcode", "version": 1}}, indent=2))
(icons / "Contents.json").write_text(json.dumps({
    "images": [{"filename": "AppIcon.png", "idiom": "universal", "platform": "ios", "size": "1024x1024"}],
    "info": {"author": "xcode", "version": 1},
}, indent=2))
print(icons / "AppIcon.png")
