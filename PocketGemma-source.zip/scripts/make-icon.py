"""Generate the app's geometric icon (requires Pillow; not needed to build)."""
import json
from pathlib import Path
from PIL import Image, ImageDraw

root = Path(__file__).resolve().parents[1]
catalog = root / "PocketGemma/Assets.xcassets"
icons = catalog / "AppIcon.appiconset"
icons.mkdir(parents=True, exist_ok=True)
image = Image.new("RGB", (1024, 1024), (125, 212, 179))
draw = ImageDraw.Draw(image)

def sparkle(x, y, radius, color):
    inset = radius * 0.22
    draw.polygon([
        (x, y-radius), (x+inset, y-inset), (x+radius, y),
        (x+inset, y+inset), (x, y+radius), (x-inset, y+inset),
        (x-radius, y), (x-inset, y-inset),
    ], fill=color)

sparkle(470, 560, 252, (26, 43, 38))
sparkle(743, 286, 112, (26, 43, 38))
sparkle(262, 284, 47, (255, 255, 255))
image.save(icons / "AppIcon.png")
(catalog / "Contents.json").write_text(json.dumps({"info": {"author": "xcode", "version": 1}}, indent=2))
(icons / "Contents.json").write_text(json.dumps({
    "images": [{"filename": "AppIcon.png", "idiom": "universal", "platform": "ios", "size": "1024x1024"}],
    "info": {"author": "xcode", "version": 1},
}, indent=2))
print(icons / "AppIcon.png")
