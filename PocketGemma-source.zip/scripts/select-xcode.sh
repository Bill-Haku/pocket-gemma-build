#!/bin/bash
# Select an installed stable Xcode with the iOS 26 SwiftUI SDK. No download.
set -euo pipefail
selected_xcode="$(python3 - <<'PY'
import glob, re
candidates = []
for path in glob.glob('/Applications/Xcode_*.app'):
    match = re.fullmatch(r'/Applications/Xcode_(\d+(?:\.\d+)*).app', path)
    if match and int(match[1].split('.')[0]) >= 26:
        candidates.append((tuple(map(int, match[1].split('.'))), path))
if not candidates:
    raise SystemExit('This build needs an installed stable Xcode 26 or later for Liquid Glass.')
print(max(candidates)[1] + '/Contents/Developer')
PY
)"
export DEVELOPER_DIR="$selected_xcode"
if [ -n "${GITHUB_ENV:-}" ]; then
  printf 'DEVELOPER_DIR=%s\n' "$DEVELOPER_DIR" >> "$GITHUB_ENV"
fi
xcodebuild -version
