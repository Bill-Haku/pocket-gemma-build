"""Record the actual embedded binary, not only a handwritten SDK version.

Run after Xcode builds an unsigned app. SwiftPM verifies the binary target's
archive checksum. This receipt additionally hashes the linked framework files.
The official prebuilt does not expose a full compiler-flag/runtime-version API.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--app', type=Path, required=True)
parser.add_argument('--derived-data', type=Path, required=True)
parser.add_argument('--target', choices=['iphoneos', 'iphonesimulator'], required=True)
parser.add_argument('--configuration', required=True)
args = parser.parse_args()
runtime = '0.18.0'
artifact_sha = 'd765b99592d4ec3d0c9e2bd69469454af06c834861340672da1891c0c121c347'
checkouts = args.derived_data / 'SourcePackages/checkouts'
packages = [p for p in checkouts.glob('*/Package.swift') if 'name: "LiteRTLM"' in p.read_text()]
assert len(packages) == 1, 'Missing/ambiguous resolved LiteRT-LM checkout'
package = packages[0]
manifest = package.read_text()
url = f'https://github.com/google-ai-edge/LiteRT-LM/releases/download/v{runtime}/CLiteRTLM.xcframework.zip'
assert url in manifest and artifact_sha in manifest, 'Unexpected native artifact declaration'
resolved_path = Path('PocketGemma.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved')
resolved = json.loads(resolved_path.read_text())
pins = [p for p in resolved['pins'] if p['identity'].lower() == 'litert-lm']
assert len(pins) == 1 and pins[0]['state']['version'] == runtime, 'SDK pin changed'
framework = args.app / 'Frameworks/CLiteRTLM.framework'
assert (framework / 'CLiteRTLM').is_file(), 'No actual native framework in built app'
native_files = []
def native_macho(data):
    magic, cpu, subtype, _, count, _, _, _ = struct.unpack_from('<8I', data)
    assert magic == 0xFEEDFACF and cpu == 0x0100000C, 'Native framework is not a thin ARM64 Mach-O'
    info = {'architecture': 'arm64', 'cpuSubtype': subtype}
    offset = 32
    def version(value): return f'{value >> 16}.{(value >> 8) & 255}.{value & 255}'
    for _ in range(count):
        command, size = struct.unpack_from('<2I', data, offset)
        assert size >= 8 and offset + size <= len(data)
        if command == 0x32:
            platform, minimum, sdk, _ = struct.unpack_from('<4I', data, offset + 8)
            info.update(platform=platform, minimumOS=version(minimum), nativeSDK=version(sdk))
        if command == 0x1B: info['uuid'] = data[offset + 8:offset + 24].hex()
        offset += size
    return info
for path in sorted(framework.rglob('*')):
    if path.is_file() and (path.name == 'CLiteRTLM' or path.suffix == '.dylib'):
        data = path.read_bytes()
        details = {'name': path.relative_to(args.app).as_posix(),
                   'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
        details.update(native_macho(data))
        assert details['platform'] == (2 if args.target == 'iphoneos' else 7), 'Wrong native binary platform'
        native_files.append(details)
workspace = (package.parent / 'WORKSPACE').read_text()
litert = re.search(r'LITERT_REF = "([a-f0-9]+)"', workspace)
assert litert
receipt = {
    'runtimeVersion': runtime, 'packageRevision': pins[0]['state']['revision'],
    'artifactURL': url, 'artifactSHA256': artifact_sha,
    'target': args.target,
    'sdk': subprocess.check_output(['xcrun', '--sdk', args.target, '--show-sdk-version'], text=True).strip(),
    'configuration': args.configuration, 'nativeFiles': native_files,
    'upstreamLiteRTSourceRef': litert.group(1),
    'binaryCompilerFlags': 'Full flags not published in prebuilt metadata; no custom native rebuild. Source ref is the official tag WORKSPACE declaration, not a self-reported binary version.'
}
(args.app / 'runtime-build.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
