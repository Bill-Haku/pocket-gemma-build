"""Exercise package validation using fixtures, not a simulated iOS build."""
import contextlib
import importlib.util
import io
import plistlib
import struct
import zipfile
from pathlib import Path

spec = importlib.util.spec_from_file_location("ipa_check", Path(__file__).with_name("check-ipa.py"))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

def fixture(platform="iPhoneOS", cpu=0x0100000C, model=False, missing_framework=False):
    base = "Payload/PocketGemma.app/"
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as archive:
        archive.writestr(base + "Info.plist", plistlib.dumps({
            "CFBundleExecutable": "PocketGemma", "CFBundlePackageType": "APPL",
            "CFBundleIdentifier": "app.pocketgemma.personal", "CFBundleSupportedPlatforms": [platform],
        }))
        archive.writestr(base + "PocketGemma", struct.pack("<II", 0xFEEDFACF, cpu))
        if model:
            archive.writestr(base + "model.litertlm", b"fixture")
        if missing_framework:
            archive.writestr(base + "Frameworks/Runtime.framework/Info.plist",
                             plistlib.dumps({"CFBundleExecutable": "Runtime"}))
    buffer.seek(0)
    return buffer

with contextlib.redirect_stdout(io.StringIO()):
    module.check(fixture())
cases = [
    {"platform": "iPhoneSimulator"}, {"cpu": 0x01000007},
    {"model": True}, {"missing_framework": True},
]
for case in cases:
    try:
        module.check(fixture(**case))
    except AssertionError:
        continue
    raise AssertionError(f"Validator accepted an invalid package: {case}")
print("Package validator: valid fixture accepted; 4 invalid fixtures rejected.")
