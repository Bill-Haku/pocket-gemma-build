import SwiftUI
import PocketCore

/// Runs production backup IO against a synthetic local File Provider folder.
/// No iCloud account, model, remote upload or personal archive is involved.
struct PreviewCloudCheck: View {
    @State private var result = "バックアップ検証中"
    var body: some View {
        Text(result).font(.caption).padding(4).background(.background)
            .accessibilityIdentifier("backup-report").allowsHitTesting(false)
            .task { await run() }
    }
    @MainActor private func run() async {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        let cloud = CloudHistoryStore.shared
        defer { cloud.disable(); try? FileManager.default.removeItem(at: folder) }
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            guard let url = PreviewAttachments.url("sample-text") else { throw CocoaError(.fileReadNoSuchFile) }
            let attachment = try await Task.detached { try await AttachmentStorage.importFile(url) }.value
            defer { AttachmentStorage.remove(attachment) }
            var initial = ChatThread(modelID: ModelSpec.e4b.id)
            initial.messages = [ChatMessage(role: .user, text: "backup fixture", attachments: [attachment])]
            cloud.configure(folder)
            await cloud.saveNow([initial])
            guard cloud.lastSaved != nil, cloud.error == nil else { throw CocoaError(.fileWriteUnknown) }
            initial.messages.append(ChatMessage(role: .assistant, text: "latest snapshot"))
            initial.updatedAt = Date()
            cloud.schedule([initial])
            try await Task.sleep(for: .milliseconds(3600))
            let restored = try await cloud.restore()
            guard restored.first?.messages.last?.text == "latest snapshot",
                  restored.first?.messages.first?.media.first?.extractedText?.contains("日本語") == true,
                  FileManager.default.fileExists(atPath: AttachmentStorage.url(attachment.storedName)!.path) else { throw CocoaError(.fileReadCorruptFile) }
            // Verify media recovery itself, not merely the archive's filenames.
            AttachmentStorage.remove(attachment)
            _ = try await cloud.restore()
            guard FileManager.default.fileExists(atPath: AttachmentStorage.url(attachment.storedName)!.path) else { throw CocoaError(.fileReadNoSuchFile) }
            result = "バックアップ検証成功: 自動保存・最新会話・添付の復元"
        } catch { result = "バックアップ検証失敗: \(error.localizedDescription)" }
    }
}
