// swift-tools-version: 5.9
import PackageDescription

let package = Package(name: "VisionRuntimeBridge", platforms: [.iOS(.v17), .macOS(.v14)],
    products: [.library(name: "VisionRuntimeBridge", targets: ["VisionRuntimeBridge"])],
    targets: [.target(name: "VisionRuntimeBridge")], cxxLanguageStandard: .cxx17)
