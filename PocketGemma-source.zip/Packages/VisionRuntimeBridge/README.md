# VisionRuntimeBridge

Diagnostic component invocation against the **already embedded official
CLiteRTLM 0.18.0**. It uses the public LiteRT C API and does not replace or
interpose runtime functions. The app links the same official XCFramework.

The public headers under `Sources/VisionRuntimeBridge/include/litert` and
`include/tflite` are from Google AI Edge LiteRT revision
`26895c9fbcc25c43faa8c1a98cd1fd28951602c3`, the source dependency declared by
the official LM tag. Original Apache-2.0 notices are preserved.

`litert/build_common/build_config.h` is the verbatim official
`litert/build_common/config/build_config_cpu_only.h` from that revision.
It configures these **header declarations for the component bridge**, not
the prebuilt native library. The embedded library still contains its Metal
backend and the normal chat keeps its independently saved GPU/CPU settings.

Kernel mode 0 uses CPU delegates; mode 2 selects LiteRT's built-in optimized
CPU kernels, bypassing XNNPACK for this diagnostic compiled model only. The
LM Swift Conversation API does not expose that option. Do not describe this
component path as a working replacement for multimodal chat.

The probe selects only the requested signature, uses full-capacity synthetic
zero-valued image/features tensors and grid positions, reports actual input
and output layouts, native status and finite output checks. It captures the
compiled model's buffered error reporter. No image values or embeddings are
included in shared diagnostics. The invocation has a 180-second cancellation
deadline; native model compilation does not expose the same deadline callback.
