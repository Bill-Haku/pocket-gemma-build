#include "PocketVisionBridge.h"
#include "litert/c/litert_environment.h"
#include "litert/c/litert_model.h"
#include "litert/c/litert_compiled_model.h"
#include "litert/c/litert_options.h"
#include "litert/c/litert_opaque_options.h"
#include "litert/c/litert_tensor_buffer.h"
#include "litert/c/litert_tensor_buffer_requirements.h"
#include "litert/c/options/litert_cpu_options.h"
#include "litert/c/options/litert_runtime_options.h"
#include "tflite/delegates/xnnpack/xnnpack_delegate.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <mach/mach.h>

uint64_t PGProcessMemoryFootprint(void) {
    task_vm_info_data_t info={}; mach_msg_type_number_t count=TASK_VM_INFO_COUNT;
    return task_info(mach_task_self(),TASK_VM_INFO,(task_info_t)&info,&count)==KERN_SUCCESS ? info.phys_footprint : 0;
}

const char *PGVisionProbeError(const PGVisionProbeResult *result) { return result ? result->error : ""; }
const char *PGVisionProbeTensors(const PGVisionProbeResult *result) { return result ? result->tensors : ""; }

const char *PGVisionProbeStage(int32_t stage) {
    static const char *names[] = {"validation", "model_load", "component_configuration",
        "component_compile", "component_buffers", "component_invoke", "component_output", "complete"};
    return stage >= 0 && stage < 8 ? names[stage] : "unknown";
}

static size_t elements(LiteRtRankedTensorType type) {
    size_t count = 1;
    if (!type.layout.rank || type.layout.rank > 8) return 0;
    for (size_t i = 0; i < type.layout.rank; ++i) {
        int dim = type.layout.dimensions[i];
        if (dim <= 0 || dim > 10000000 || count > 10000000 / (size_t)dim) return 0;
        count *= (size_t)dim;
    }
    return count;
}

static void describe(PGVisionProbeResult *r, const char *name, LiteRtRankedTensorType type) {
    size_t p = strlen(r->tensors);
    if (p+160>=sizeof(r->tensors)) return;
    p += snprintf(r->tensors+p, sizeof(r->tensors)-p, "%.64s type=%d [", name ? name : "unknown", type.element_type);
    for (size_t i=0; i<type.layout.rank && p+24<sizeof(r->tensors); ++i)
        p += snprintf(r->tensors+p, sizeof(r->tensors)-p, "%s%d", i?",":"",type.layout.dimensions[i]);
    if (p+4<sizeof(r->tensors)) snprintf(r->tensors+p,sizeof(r->tensors)-p,"]; ");
}

static bool expired(void *deadline) { return time(NULL) >= *(time_t *)deadline; }

void PGRunVisionComponent(const char *path, const char *key, int32_t mode, PGVisionProbeResult *r) {
    if (!r) return;
    memset(r,0,sizeof(*r)); r->kernel_mode=mode;
    LiteRtEnvironment env=NULL; LiteRtModel model=NULL; LiteRtOptions options=NULL;
    LiteRtCompiledModel compiled=NULL; LrtCpuOptions *cpu=NULL; LrtRuntimeOptions *runtime=NULL;
    LiteRtOpaqueOptions opaque=NULL;
    LiteRtTensorBuffer inputs[4]={NULL}, outputs[4]={NULL};
    LiteRtRankedTensorType in_types[4], out_types[4];
    LiteRtParamIndex ni=0,no=0,n=0,signature_index=0; LiteRtSignature signature=NULL;
    const char *identifier=NULL; void *payload=NULL; void (*deleter)(void*)=NULL;
    time_t deadline=time(NULL)+180;
    bool found=false;
    TfLiteXNNPackDelegateOptions xnn={};
#define CHECK(expr) do { r->status=(int32_t)(expr); if(r->status!=kLiteRtStatusOk) goto cleanup; } while(0)
    if (!path || !key || (mode!=0 && mode!=2)) { r->status=-1; goto cleanup; }
    r->stage=1;
    CHECK(LiteRtCreateEnvironment(0,NULL,&env));
    CHECK(LiteRtCreateModelFromFile(env,path,&model));
    CHECK(LiteRtGetNumModelSignatures(model,&n));
    for (LiteRtParamIndex i=0;i<n;++i) {
        const char *name=NULL; CHECK(LiteRtGetModelSignature(model,i,&signature));
        CHECK(LiteRtGetSignatureKey(signature,&name));
        if (name && strcmp(name,key)==0) { signature_index=i; found=true; break; }
    }
    if (!found) { r->status=-2; goto cleanup; }
    CHECK(LiteRtGetNumSignatureInputs(signature,&ni));
    CHECK(LiteRtGetNumSignatureOutputs(signature,&no));
    if (ni>4 || no>4 || ni==0 || no==0) { r->status=-3; goto cleanup; }
    r->input_count=(int32_t)ni; r->output_count=(int32_t)no;
    r->stage=2;
    CHECK(LiteRtCreateOptions(&options));
    CHECK(LiteRtSetOptionsHardwareAccelerators(options,kLiteRtHwAcceleratorCpu));
    CHECK(LrtCreateCpuOptions(&cpu));
    CHECK(LrtSetCpuOptionsKernelMode(cpu,(LiteRtCpuKernelMode)mode));
    CHECK(LrtSetCpuOptionsNumThread(cpu,4));
    xnn=TfLiteXNNPackDelegateOptionsDefault();
    CHECK(LrtSetCpuOptionsXNNPackFlags(cpu,xnn.flags |
          TFLITE_XNNPACK_DELEGATE_FLAG_DYNAMIC_FULLY_CONNECTED |
          TFLITE_XNNPACK_DELEGATE_FLAG_ENABLE_LATEST_OPERATORS));
    CHECK(LrtGetOpaqueCpuOptionsData(cpu,&identifier,&payload,&deleter));
    CHECK(LiteRtCreateOpaqueOptions(identifier,payload,deleter,&opaque)); payload=NULL;
    CHECK(LiteRtAddOpaqueOptions(options,opaque)); opaque=NULL;
    CHECK(LrtCreateRuntimeOptions(&runtime));
    CHECK(LrtSetRuntimeOptionsSelectedSignatures(runtime,std::vector<std::string>{key}));
    CHECK(LrtSetRuntimeOptionsErrorReporterMode(runtime,kLiteRtErrorReporterModeBuffer));
    CHECK(LrtGetOpaqueRuntimeOptionsData(runtime,&identifier,&payload,&deleter));
    CHECK(LiteRtCreateOpaqueOptions(identifier,payload,deleter,&opaque)); payload=NULL;
    CHECK(LiteRtAddOpaqueOptions(options,opaque)); opaque=NULL;
    r->stage=3;
    CHECK(LiteRtCreateCompiledModel(env,model,options,&compiled));
    CHECK(LiteRtSetCompiledModelCancellationFunction(compiled,&deadline,expired));
    r->stage=4;
    for (LiteRtParamIndex i=0;i<ni;++i) {
        LiteRtTensor tensor; LiteRtTensorBufferRequirements req; const char *name=NULL;
        CHECK(LiteRtGetSignatureInputTensorByIndex(signature,i,&tensor));
        CHECK(LiteRtGetRankedTensorType(tensor,&in_types[i]));
        CHECK(LiteRtGetSignatureInputName(signature,i,&name)); describe(r,name,in_types[i]);
        CHECK(LiteRtGetCompiledModelInputBufferRequirements(compiled,signature_index,i,&req));
        CHECK(LiteRtCreateManagedTensorBufferFromRequirements(env,&in_types[i],req,&inputs[i]));
        size_t count=elements(in_types[i]); if (!count) { r->status=-4; goto cleanup; }
        size_t packed=0; CHECK(LiteRtGetTensorBufferPackedSize(inputs[i],&packed));
        size_t element_size=in_types[i].element_type==kLiteRtElementTypeBool ? 1 : 4;
        if (count*element_size>packed) { r->status=-7; goto cleanup; }
        CHECK(LiteRtClearTensorBuffer(inputs[i]));
        void *memory=NULL; CHECK(LiteRtLockTensorBuffer(inputs[i],&memory,kLiteRtTensorBufferLockModeWrite));
        if (in_types[i].element_type==kLiteRtElementTypeInt32 && name && strcmp(name,"positions_xy")==0) {
            // Synthetic full-capacity 42-column patch grid. This is a tensor
            // experiment, not JPEG preprocessing or an image recognition pass.
            int32_t *p=static_cast<int32_t*>(memory);
            for (size_t j=0;j<count/2;++j) { p[2*j]=(int32_t)(j%42); p[2*j+1]=(int32_t)(j/42); }
        } else if (in_types[i].element_type==kLiteRtElementTypeBool) {
            memset(memory,1,count);
        } else if (in_types[i].element_type==kLiteRtElementTypeFloat32) {
            float *p=static_cast<float*>(memory); for(size_t j=0;j<count;++j) p[j]=0.0f;
        } else { LiteRtUnlockTensorBuffer(inputs[i]); r->status=-5; goto cleanup; }
        CHECK(LiteRtUnlockTensorBuffer(inputs[i]));
    }
    for (LiteRtParamIndex i=0;i<no;++i) {
        LiteRtTensor tensor; LiteRtTensorBufferRequirements req; const char *name=NULL;
        CHECK(LiteRtGetSignatureOutputTensorByIndex(signature,i,&tensor));
        CHECK(LiteRtGetRankedTensorType(tensor,&out_types[i]));
        CHECK(LiteRtGetSignatureOutputName(signature,i,&name)); describe(r,name,out_types[i]);
        CHECK(LiteRtGetCompiledModelOutputBufferRequirements(compiled,signature_index,i,&req));
        CHECK(LiteRtCreateManagedTensorBufferFromRequirements(env,&out_types[i],req,&outputs[i]));
    }
    r->stage=5;
    CHECK(LiteRtRunCompiledModel(compiled,signature_index,ni,inputs,no,outputs));
    r->stage=6;
    for (LiteRtParamIndex i=0;i<no;++i) {
        size_t count=elements(out_types[i]); if (!count) { r->status=-6; goto cleanup; }
        r->output_elements+=count;
        if (out_types[i].element_type==kLiteRtElementTypeFloat32) {
            size_t packed=0; CHECK(LiteRtGetTensorBufferPackedSize(outputs[i],&packed));
            if (count*sizeof(float)>packed) { r->status=-7; goto cleanup; }
            void *memory=NULL; CHECK(LiteRtLockTensorBuffer(outputs[i],&memory,kLiteRtTensorBufferLockModeRead));
            float *p=static_cast<float*>(memory); for(size_t j=0;j<count;++j) if(!isfinite(p[j])) r->nonfinite_elements++;
            CHECK(LiteRtUnlockTensorBuffer(outputs[i]));
        }
    }
    r->stage=7;
cleanup:
    if (r->status!=0 && compiled) {
        char *errors=NULL;
        if (LiteRtCompiledModelGetErrorMessages(compiled,&errors)==kLiteRtStatusOk && errors) {
            snprintf(r->error,sizeof(r->error),"%s",errors); free(errors);
        }
    }
    for (size_t i=0;i<4;++i) { if(inputs[i]) LiteRtDestroyTensorBuffer(inputs[i]); if(outputs[i]) LiteRtDestroyTensorBuffer(outputs[i]); }
    if(compiled) LiteRtDestroyCompiledModel(compiled);
    if(opaque) LiteRtDestroyOpaqueOptions(opaque);
    if(payload && deleter) deleter(payload);
    if(runtime) LrtDestroyRuntimeOptions(runtime);
    if(cpu) LrtDestroyCpuOptions(cpu);
    if(options) LiteRtDestroyOptions(options);
    if(model) LiteRtDestroyModel(model);
    if(env) LiteRtDestroyEnvironment(env);
#undef CHECK
}
