// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "PocketCore",
    platforms: [.iOS(.v17), .macOS(.v13)],
    products: [.library(name: "PocketCore", targets: ["PocketCore"])],
    targets: [
        .target(name: "PocketCore"),
        .executableTarget(name: "ValidationMemoryProbe", dependencies: ["PocketCore"]),
        .testTarget(name: "PocketCoreTests", dependencies: ["PocketCore"])
    ]
)

