import XCTest
@testable import PocketCore

final class PocketCoreTests: XCTestCase {
    func testOldArchiveWithoutModelIDKeepsMessagesAndDefaultsToGemma() throws {
        var original = ChatThread()
        original.messages = [ChatMessage(role: .user, text: "保存済みの会話")]
        var json = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(original)) as? [String: Any])
        json.removeValue(forKey: "modelID")
        let restored = try JSONDecoder().decode(ChatThread.self, from: JSONSerialization.data(withJSONObject: json))
        XCTAssertNil(restored.modelID)
        XCTAssertEqual(restored.messages, original.messages)
        XCTAssertEqual(restored.id, original.id)
        let qwen = ChatThread(modelID: ModelSpec.qwen3.id)
        XCTAssertEqual(try JSONDecoder().decode(ChatThread.self, from: JSONEncoder().encode(qwen)).modelID, qwen.modelID)
    }

    func testInstallingSecondModelKeepsLegacyFileAndReceipt() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let library = ModelLibrary(directory: directory)
        let hash = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        let old = ModelSpec(fileName: ModelSpec.e4b.fileName, byteCount: 3, sha256: hash,
            downloadURL: ModelSpec.e4b.downloadURL, id: ModelSpec.e4b.id)
        let new = ModelSpec(fileName: ModelSpec.qwen3.fileName, byteCount: 3, sha256: hash,
            downloadURL: ModelSpec.qwen3.downloadURL, id: ModelSpec.qwen3.id)
        try Data("abc".utf8).write(to: library.modelURL(old))
        try hash.write(to: directory.appendingPathComponent("verified.txt"), atomically: true, encoding: .utf8)
        XCTAssertTrue(library.isInstalled(old))
        XCTAssertEqual(library.pendingURL(old).lastPathComponent, "download.pending")
        try Data("abc".utf8).write(to: library.pendingURL(new))
        try ModelValidator.validate(library.pendingURL(new), spec: new)
        try library.installValidated(new)
        XCTAssertTrue(library.isInstalled(new))
        XCTAssertTrue(library.isInstalled(old))
        XCTAssertEqual(try Data(contentsOf: library.modelURL(old)), Data("abc".utf8))
        try Data("a".utf8).write(to: library.modelURL(new))
        XCTAssertFalse(library.isInstalled(new))
        XCTAssertTrue(library.isInstalled(old))
    }

    func testCatalogModelsHaveIsolatedFilesReceiptsAndPendingDownloads() {
        let library = ModelLibrary(directory: URL(fileURLWithPath: "/models"))
        XCTAssertEqual(Set(ModelSpec.catalog.map(\.id)).count, ModelSpec.catalog.count)
        let paths = ModelSpec.catalog.flatMap { [library.modelURL($0), library.pendingURL($0), library.receiptURL($0)] }
        XCTAssertEqual(Set(paths).count, paths.count)
        XCTAssertNil(ModelSpec.find("claude"))
    }

    func testReplyChunksKeepIndependentClocksAndReadablePrefix() {
        var reveal = ReplyRevealBuffer(text: "こんにちは。")
        reveal.update("こんにちは。新しい", at: 1)
        reveal.update("こんにちは。新しい返信", at: 1.1)
        XCTAssertEqual(reveal.segments.map(\.arrivedAt), [1, 1.1])
        reveal.settle(at: 1.35)
        XCTAssertEqual(reveal.settledText, "こんにちは。新しい")
        XCTAssertEqual(reveal.segments.map(\.text), ["返信"])
        reveal.settle(at: 2)
        XCTAssertEqual(reveal.settledText, "こんにちは。新しい返信")
        XCTAssertNil(reveal.animationDeadline)
    }

    func testReplyRevealPreservesJapaneseEmojiAndCopyText() {
        var reveal = ReplyRevealBuffer()
        let parts = ["日本語", "の返信です。", "👨‍👩‍👧‍👦", "👍🏽", "\n次の行"]
        var complete = ""
        for (index, part) in parts.enumerated() {
            complete += part
            reveal.update(complete, at: Double(index) * 0.03)
            XCTAssertEqual(reveal.text, complete)
        }
        reveal.settle(at: 2)
        XCTAssertEqual(reveal.settledText, complete)
    }

    func testJoinedUnicodeGraphemeAndCorrectionsStayIntact() {
        var reveal = ReplyRevealBuffer(text: "か")
        reveal.update("か\u{3099}", at: 1)
        XCTAssertEqual(reveal.text, "か\u{3099}")
        reveal.update("👨", at: 1.1)
        reveal.update("👨‍👩‍👧‍👦", at: 1.2)
        XCTAssertEqual(reveal.text, "👨‍👩‍👧‍👦")
        XCTAssertTrue(reveal.segments.isEmpty)
        reveal.update("修正した返信", at: 2)
        XCTAssertEqual(reveal.settledText, "修正した返信")
    }

    func testFastReplyKeepsAnimationBookkeepingBounded() {
        var reveal = ReplyRevealBuffer()
        var complete = ""
        for index in 0..<100 {
            complete += "あ"
            reveal.update(complete, at: Double(index) * 0.001)
            XCTAssertLessThanOrEqual(reveal.segments.count, ReplyRevealBuffer.maximumAnimatedSegments)
            XCTAssertEqual(reveal.text, complete)
        }
        reveal.settle(at: 1)
        XCTAssertEqual(reveal.settledText, complete)
        XCTAssertTrue(reveal.segments.isEmpty)
    }

    func testRestoredReplyDoesNotReplayItsAnimation() {
        let reveal = ReplyRevealBuffer(text: "保存済みの返信です。")
        XCTAssertTrue(reveal.segments.isEmpty)
        XCTAssertEqual(reveal.settledText, "保存済みの返信です。")
    }

    func testStreamingContentDoesNotPullReaderAwayFromOldMessages() {
        var scrolling = ChatScrollPolicy()
        scrolling.observe(distanceFromBottom: 300)
        XCTAssertTrue(scrolling.shouldFollowStream, "Content growth must not disable automatic following")
        scrolling.setUserScrolling(true)
        scrolling.observe(distanceFromBottom: 500)
        scrolling.setUserScrolling(false)
        XCTAssertFalse(scrolling.shouldFollowStream)
        scrolling.observe(distanceFromBottom: 600)
        XCTAssertFalse(scrolling.shouldFollowStream)
        scrolling.requestLatest()
        XCTAssertTrue(scrolling.shouldFollowStream)
    }

    func testFollowingResumesWhenReaderScrollsBackToTheLatestReply() {
        var scrolling = ChatScrollPolicy()
        scrolling.setUserScrolling(true)
        scrolling.observe(distanceFromBottom: 400)
        scrolling.observe(distanceFromBottom: 20)
        XCTAssertFalse(scrolling.shouldFollowStream, "Do not fight an active finger gesture")
        scrolling.setUserScrolling(false)
        XCTAssertTrue(scrolling.shouldFollowStream)
    }

    func testAnimationMessageIdentitySurvivesArchiveRoundTrip() throws {
        let id = UUID()
        let message = ChatMessage(id: id, role: .user, text: "sent")
        let restored = try JSONDecoder().decode(ChatMessage.self, from: JSONEncoder().encode(message))
        XCTAssertEqual(restored.id, id)
    }

    func testSecondTurnReusesTheCompletedNativeConversation() {
        let thread = UUID()
        let firstTurn = [ChatMessage(role: .user, text: "こんにちは"),
                         ChatMessage(role: .assistant, text: "こんにちは！")]
        var context = ConversationContext()
        XCTAssertFalse(context.canReuse(threadID: thread, history: []))
        context.completeTurn(threadID: thread, history: [], prompt: "こんにちは", reply: "こんにちは！")
        XCTAssertTrue(context.canReuse(threadID: thread, history: firstTurn))
        XCTAssertFalse(context.canReuse(threadID: UUID(), history: firstTurn))
        // Context trimming must create a fresh native conversation.
        XCTAssertFalse(context.canReuse(threadID: thread, history: []))
        context.invalidate()
        XCTAssertFalse(context.canReuse(threadID: thread, history: firstTurn))
    }

    func testExpiredReplyCannotAppendOrFinishANewerRequest() {
        var ticket = ReplyTicket()
        let old = ticket.begin()
        XCTAssertTrue(ticket.finish(old))
        let new = ticket.begin()
        XCTAssertFalse(ticket.accepts(old))
        XCTAssertFalse(ticket.finish(old))
        XCTAssertTrue(ticket.accepts(new))
        XCTAssertTrue(ticket.finish(new))
        XCTAssertFalse(ticket.finish(new))
    }

    func testFailedAndStoppedRepliesAreExcludedFromContext() {
        let messages = [
            ChatMessage(role: .user, text: "first"),
            ChatMessage(role: .assistant, text: "answer"),
            ChatMessage(role: .user, text: "second"),
            ChatMessage(role: .assistant, text: "partial", state: .stopped),
            ChatMessage(role: .user, text: "third"),
            ChatMessage(role: .assistant, text: "error", state: .failed)
        ]
        XCTAssertEqual(HistoryBuilder.recentPairs(messages).map(\.text), ["first", "answer"])
    }

    func testHistoryKeepsNewestCompletePairsWithoutSplitting() {
        let messages = [
            ChatMessage(role: .user, text: "older"), ChatMessage(role: .assistant, text: "answer"),
            ChatMessage(role: .user, text: "new"), ChatMessage(role: .assistant, text: "yes")
        ]
        XCTAssertEqual(HistoryBuilder.recentPairs(messages, byteBudget: 6).map(\.text), ["new", "yes"])
        XCTAssertTrue(HistoryBuilder.recentPairs(messages, byteBudget: 5).isEmpty)
    }

    func testUTF8BudgetCountsJapaneseBytes() {
        let messages = [ChatMessage(role: .user, text: "あ"), ChatMessage(role: .assistant, text: "い")]
        XCTAssertTrue(HistoryBuilder.recentPairs(messages, byteBudget: 5).isEmpty)
        XCTAssertEqual(HistoryBuilder.recentPairs(messages, byteBudget: 6).count, 2)
    }

    func testArchiveRoundTripRecoversInterruptedReply() throws {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: dir) }
        let archive = ChatArchive(fileURL: dir.appendingPathComponent("chats.json"))
        var thread = ChatThread()
        thread.messages = [ChatMessage(role: .user, text: "hello"), ChatMessage(role: .assistant, text: "part", state: .generating)]
        try archive.save([thread])
        let restored = try archive.load()
        XCTAssertEqual(restored.first?.id, thread.id)
        XCTAssertEqual(restored.first?.messages.last?.state, .stopped)
        XCTAssertEqual(restored.first?.messages.last?.text, "part")
    }

    func testCorruptedArchiveThrowsRatherThanSilentlyDiscardingHistory() throws {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: url) }
        try Data("invalid".utf8).write(to: url)
        XCTAssertThrowsError(try ChatArchive(fileURL: url).load())
    }

    func testChecksumRejectsSameSizeCorruptionAndTruncatedDownloads() throws {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: url) }
        let spec = ModelSpec(fileName: "sample", byteCount: 3,
            sha256: "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
            downloadURL: URL(string: "https://example.com/sample")!)
        try Data("abc".utf8).write(to: url)
        XCTAssertNoThrow(try ModelValidator.validate(url, spec: spec))
        try Data("abd".utf8).write(to: url)
        XCTAssertThrowsError(try ModelValidator.validate(url, spec: spec))
        try Data("ab".utf8).write(to: url)
        XCTAssertThrowsError(try ModelValidator.validate(url, spec: spec))
    }
}
