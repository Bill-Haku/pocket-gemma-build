import Foundation

/// Separate files and receipts for each catalog model. Keep the original E4B
/// paths so an AltStore update can reuse the already verified download.
public struct ModelLibrary: Sendable {
    public let directory: URL
    public init(directory: URL) { self.directory = directory }
    public func modelURL(_ spec: ModelSpec) -> URL { directory.appendingPathComponent(spec.fileName) }
    public func pendingURL(_ spec: ModelSpec) -> URL {
        directory.appendingPathComponent(spec.id == ModelSpec.e4b.id ? "download.pending" : "\(spec.id).pending")
    }
    public func receiptURL(_ spec: ModelSpec) -> URL {
        directory.appendingPathComponent(spec.id == ModelSpec.e4b.id ? "verified.txt" : "\(spec.id).verified")
    }
    public func isInstalled(_ spec: ModelSpec) -> Bool {
        guard let receipt = try? String(contentsOf: receiptURL(spec), encoding: .utf8),
              receipt == spec.sha256,
              let attrs = try? FileManager.default.attributesOfItem(atPath: modelURL(spec).path),
              (attrs[.size] as? NSNumber)?.int64Value == spec.byteCount else { return false }
        return true
    }
    /// Call only after bounded SHA-256 validation of this model's pending file.
    public func installValidated(_ spec: ModelSpec) throws {
        let destination = modelURL(spec)
        if FileManager.default.fileExists(atPath: destination.path) {
            _ = try FileManager.default.replaceItemAt(destination, withItemAt: pendingURL(spec))
        } else {
            try FileManager.default.moveItem(at: pendingURL(spec), to: destination)
        }
        try spec.sha256.write(to: receiptURL(spec), atomically: true, encoding: .utf8)
    }
}
