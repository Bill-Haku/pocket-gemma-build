import Foundation

public final class ChatArchive {
    public let fileURL: URL

    public init(fileURL: URL) {
        self.fileURL = fileURL
    }

    public func load() throws -> [ChatThread] {
        guard FileManager.default.fileExists(atPath: fileURL.path) else { return [] }
        var threads = try JSONDecoder().decode([ChatThread].self, from: Data(contentsOf: fileURL))
        for index in threads.indices { threads[index].recoverInterruptedReplies() }
        return threads
    }

    public func save(_ threads: [ChatThread]) throws {
        try FileManager.default.createDirectory(at: fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        let encoder = JSONEncoder()
        let data = try encoder.encode(threads)
        #if os(iOS)
        try data.write(to: fileURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        #else
        try data.write(to: fileURL, options: .atomic)
        #endif
    }
}

