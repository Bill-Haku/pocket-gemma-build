import Foundation

/// Evidence from native messages, never a delegate/operator guessed from the
/// requested backend. Delegate node 1480 is not an underlying model operator.
public struct NativeLogEvidence: Codable, Equatable, Sendable {
    public let observedDelegates: [String]
    public let failedDelegate: String?
    public let operatorNames: [String]
    public let delegateNodes: [Int]
    public let sourceLocations: [String]
    public let failingComponent: String?

    public init(error: String, logLines: [String]) {
        let lines = [error] + logLines
        let joined = lines.joined(separator: "\n")
        observedDelegates = ["XNNPACK", "Metal"].filter { name in
            joined.range(of: name, options: .caseInsensitive) != nil
        }
        if lines.contains(where: { $0.range(of: "XNNPACK", options: .caseInsensitive) != nil &&
            ($0.localizedCaseInsensitiveContains("failed") || $0.localizedCaseInsensitiveContains("error")) }) {
            failedDelegate = "XNNPACK"
        } else if lines.contains(where: { $0.localizedCaseInsensitiveContains("metal") &&
            ($0.localizedCaseInsensitiveContains("failed") || $0.localizedCaseInsensitiveContains("error")) }) {
            failedDelegate = "Metal"
        } else { failedDelegate = nil }
        operatorNames = Self.matches(#"(?i)(?:builtin opcode|unsupported (?:operator|op)|unresolved custom op)\s*[:=]?\s*['\"]?([A-Z][A-Z0-9_]{2,})"#, in: joined)
            .map { $0.uppercased() }.uniqued()
        delegateNodes = Self.matches(#"(?i)Node (?:number|index)\s+(\d+)\s*\(TfLiteXNNPackDelegate\)"#, in: joined)
            .compactMap(Int.init).uniqued()
        sourceLocations = Self.matches(#"([A-Za-z0-9_]+\.(?:cc|mm|h):\d+)"#, in: joined).uniqued()
        if joined.contains("vision_litert_compiled_model_executor.cc:") {
            failingComponent = "vision_executor"
        } else if joined.contains("llm_litert_compiled_model_executor") {
            failingComponent = "language_executor"
        } else { failingComponent = nil }
    }

    private static func matches(_ pattern: String, in text: String) -> [String] {
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return [] }
        return regex.matches(in: text, range: NSRange(text.startIndex..., in: text)).compactMap {
            guard let range = Range($0.range(at: 1), in: text) else { return nil }
            return String(text[range])
        }
    }
}

/// Only operational native errors are retained. Text/JSON/prompts/responses,
/// file names and unrelated stderr output are not a diagnostic log source.
public struct NativeLogBuffer: Sendable {
    public private(set) var lines: [String] = []
    public private(set) var discardedLines = 0
    public private(set) var truncated = false
    private var pending = Data()
    public init() {}

    public mutating func append(_ data: Data) {
        pending.append(data)
        while let newline = pending.firstIndex(of: 10) {
            consume(String(decoding: pending[..<newline], as: UTF8.self))
            pending.removeSubrange(...newline)
        }
        if pending.count > 4096 { pending = Data(pending.suffix(4096)); truncated = true }
    }
    public mutating func finish() {
        if !pending.isEmpty { consume(String(decoding: pending, as: UTF8.self)); pending.removeAll() }
    }
    private mutating func consume(_ raw: String) {
        let lower = raw.lowercased()
        // A narrow allowlist avoids accidentally persisting the SDK's verbose
        // conversation/JSON dumps. Do not expand this to all ERROR/INFO lines.
        let operational = ["xnnpack delegate", "tflitexnnpackdelegate", "modify graph with delegate",
            "failed to allocate tensors", "failed to invoke the compiled model", "failed to prepare",
            "builtin opcode", "unresolved custom op", "unsupported operator", "unsupported op:",
            "texture binding has argument index", "metal accelerator", "created a metal device",
            "metal residency set", "metal shader", "delegate_metal.mm:",
            "vision_litert_compiled_model_executor.cc:", "llm_litert_compiled_model_executor",
            "litert_compiled_model.h:", "failed to decode image"]
        guard operational.contains(where: lower.contains), !raw.contains("\"role\""),
              !raw.contains("\"content\""), !lower.contains("prompt:"), !lower.contains("response:") else {
            discardedLines += 1; return
        }
        let line = GenerationSettings.prefix(Self.redact(raw), byteLimit: 800)
        if line.utf8.count < Self.redact(raw).utf8.count { truncated = true }
        lines.append(line)
        while lines.count > 64 || lines.reduce(0, { $0 + $1.utf8.count }) > 8192 {
            lines.removeFirst(); truncated = true
        }
    }
    public static func redact(_ raw: String) -> String {
        var text = raw
        for pattern in [#"(?:/private)?/var/(?:mobile|folders)/[^\s\"\)]+"#,
                        #"/Users/[^\s\"\)]+"#, #"[A-Z]:\\[^\r\n\"\)]+"#,
                        #"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"#,
                        #"https?://[^\s\"\)]+"#] {
            if let regex = try? NSRegularExpression(pattern: pattern) {
                text = regex.stringByReplacingMatches(in: text, range: NSRange(text.startIndex..., in: text), withTemplate: "<redacted>")
            }
        }
        return text.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

private extension Array where Element: Hashable {
    func uniqued() -> [Element] {
        var seen = Set<Element>()
        return filter { seen.insert($0).inserted }
    }
}
