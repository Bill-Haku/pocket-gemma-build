import Foundation

public enum ChatRole: String, Codable, Sendable {
    case user, assistant
}

public enum ReplyState: String, Codable, Sendable {
    case complete, generating, stopped, failed
}

public struct ChatMessage: Codable, Identifiable, Equatable, Sendable {
    public let id: UUID
    public let role: ChatRole
    public var text: String
    public var state: ReplyState
    public let createdAt: Date
    // Optional so pre-attachment archives remain readable without migration.
    public var attachments: [ChatAttachment]?
    public var media: [ChatAttachment] { attachments ?? [] }

    public init(id: UUID = UUID(), role: ChatRole, text: String, state: ReplyState = .complete,
                attachments: [ChatAttachment] = []) {
        self.id = id
        self.role = role
        self.text = text
        self.state = state
        self.createdAt = Date()
        self.attachments = attachments.isEmpty ? nil : attachments
    }
}

public struct ChatThread: Codable, Identifiable, Equatable, Sendable {
    public let id: UUID
    public var messages: [ChatMessage]
    public var updatedAt: Date
    // Missing in old archives: those conversations used Gemma E4B.
    public var modelID: String?

    public init(modelID: String? = nil) {
        id = UUID()
        messages = []
        updatedAt = Date()
        self.modelID = modelID
    }

    public var title: String {
        guard let first = messages.first(where: { $0.role == .user }) else { return "新しい会話" }
        return String(first.text.replacingOccurrences(of: "\n", with: " ").prefix(28))
    }

    public mutating func recoverInterruptedReplies() {
        for index in messages.indices where messages[index].state == .generating {
            messages[index].state = .stopped
        }
    }
}

public enum HistoryBuilder {
    /// Preserve complete user/assistant pairs, newest first, within a conservative
    /// UTF-8 budget. Never feed an interrupted or failed reply back to the model.
    /// This is a size heuristic, not an exact tokenizer. The runtime enforces the
    /// final context limit and the UI surfaces its errors.
    public static func recentPairs(_ messages: [ChatMessage], byteBudget: Int = 5000) -> [ChatMessage] {
        var pairs: [[ChatMessage]] = []
        var pending: ChatMessage?
        for message in messages {
            if message.role == .user {
                pending = message
            } else {
                if let user = pending, message.state == .complete, !message.text.isEmpty {
                    pairs.append([user, message])
                }
                pending = nil
            }
        }
        var result: [ChatMessage] = []
        var used = 0
        for pair in pairs.reversed() {
            let count = pair.reduce(0) { $0 + $1.text.utf8.count + $1.media.reduce(0) { $0 + $1.contextByteCost } }
            guard used + count <= byteBudget else { break }
            result.insert(contentsOf: pair, at: 0)
            used += count
        }
        return result
    }
}

