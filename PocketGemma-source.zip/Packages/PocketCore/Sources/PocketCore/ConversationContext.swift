import Foundation

/// A native conversation already contains completed turns. Reuse it only when
/// it belongs to this chat and exactly matches the history being supplied.
public struct ConversationContext: Sendable {
    private struct Entry: Equatable, Sendable {
        let role: ChatRole
        let text: String
        let attachments: [ChatAttachment]
    }
    private var threadID: UUID?
    private var entries: [Entry] = []

    public init() {}

    public func canReuse(threadID: UUID, history: [ChatMessage]) -> Bool {
        self.threadID == threadID && entries == history.map { Entry(role: $0.role, text: $0.text, attachments: $0.media) }
    }

    public mutating func completeTurn(threadID: UUID, history: [ChatMessage], prompt: String, reply: String,
                                     attachments: [ChatAttachment] = []) {
        self.threadID = threadID
        entries = history.map { Entry(role: $0.role, text: $0.text, attachments: $0.media) }
        entries.append(Entry(role: .user, text: prompt, attachments: attachments))
        entries.append(Entry(role: .assistant, text: reply, attachments: []))
    }

    public mutating func invalidate() {
        threadID = nil
        entries = []
    }
}

/// UI callbacks from an expired native request must not affect a newer reply.
public struct ReplyTicket: Sendable {
    public private(set) var activeID: UUID?
    public init() {}
    public mutating func begin() -> UUID {
        let id = UUID()
        activeID = id
        return id
    }
    public func accepts(_ id: UUID) -> Bool { activeID == id }
    @discardableResult public mutating func finish(_ id: UUID) -> Bool {
        guard accepts(id) else { return false }
        activeID = nil
        return true
    }
}
