/// Content growth alone must not be mistaken for the reader scrolling away.
public struct ChatScrollPolicy: Sendable {
    public private(set) var followsLatest = true
    public private(set) var userIsScrolling = false
    private var distance = 0.0
    public init() {}
    public var shouldFollowStream: Bool { followsLatest && !userIsScrolling }

    public mutating func observe(distanceFromBottom: Double) {
        distance = max(0, distanceFromBottom)
        if userIsScrolling { followsLatest = distance <= 80 }
    }
    public mutating func setUserScrolling(_ scrolling: Bool) {
        if userIsScrolling && !scrolling { followsLatest = distance <= 80 }
        userIsScrolling = scrolling
    }
    public mutating func requestLatest() {
        followsLatest = true
        userIsScrolling = false
    }
}
