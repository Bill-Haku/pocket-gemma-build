import Foundation

public enum ExecutionBackend: String, CaseIterable, Identifiable, Codable, Sendable {
    case gpu = "GPU", cpu = "CPU"
    public var id: String { rawValue }
}

public enum VisionCPUImplementation: String, CaseIterable, Identifiable, Codable, Sendable {
    case xnnpack, builtin
    public var id: String { rawValue }
    public var title: String { self == .xnnpack ? "標準（XNNPACK）" : "互換（組み込みCPU）" }
}

public struct GenerationSettings: Codable, Equatable, Sendable {
    public static let defaultSystemPrompt = "あなたは親切で率直なアシスタントです。ユーザーと同じ言語で、わかりやすく回答してください。"
    public var maxTokens = 4096
    public var maxOutputTokens = 512
    public var topK = 40
    public var topP = 0.95
    public var temperature = 0.7
    public var visualTokenBudget = 280
    public var backend: ExecutionBackend = .gpu
    // Keep the language decoder on its saved backend; select the image
    // encoder independently. This is a compatibility candidate, not a claim
    // that CPU vision succeeds on every physical device.
    public var visionBackend: ExecutionBackend = .cpu
    // Explicit per-model choice. Never silently retry or migrate to builtin.
    public var visionCPUImplementation: VisionCPUImplementation = .xnnpack
    public var enableThinking = false
    public var enableSpeculativeDecoding = false
    public var systemPrompt = GenerationSettings.defaultSystemPrompt
    public init() {}

    private enum CodingKeys: String, CodingKey {
        case maxTokens, maxOutputTokens, topK, topP, temperature, visualTokenBudget
        case backend, visionBackend, visionCPUImplementation, enableThinking, enableSpeculativeDecoding, systemPrompt
    }
    public init(from decoder: Decoder) throws {
        self.init()
        let values = try decoder.container(keyedBy: CodingKeys.self)
        maxTokens = try values.decodeIfPresent(Int.self, forKey: .maxTokens) ?? maxTokens
        maxOutputTokens = try values.decodeIfPresent(Int.self, forKey: .maxOutputTokens) ?? maxOutputTokens
        topK = try values.decodeIfPresent(Int.self, forKey: .topK) ?? topK
        topP = try values.decodeIfPresent(Double.self, forKey: .topP) ?? topP
        temperature = try values.decodeIfPresent(Double.self, forKey: .temperature) ?? temperature
        visualTokenBudget = try values.decodeIfPresent(Int.self, forKey: .visualTokenBudget) ?? visualTokenBudget
        backend = try values.decodeIfPresent(ExecutionBackend.self, forKey: .backend) ?? backend
        visionBackend = try values.decodeIfPresent(ExecutionBackend.self, forKey: .visionBackend) ?? .cpu
        visionCPUImplementation = try values.decodeIfPresent(VisionCPUImplementation.self, forKey: .visionCPUImplementation) ?? .xnnpack
        enableThinking = try values.decodeIfPresent(Bool.self, forKey: .enableThinking) ?? enableThinking
        enableSpeculativeDecoding = try values.decodeIfPresent(Bool.self, forKey: .enableSpeculativeDecoding) ?? enableSpeculativeDecoding
        systemPrompt = try values.decodeIfPresent(String.self, forKey: .systemPrompt) ?? systemPrompt
    }
    public var reservedTokens: Int { max(128, min(512, maxTokens / 8)) }
    public var inputByteBudget: Int {
        max(0, min(16000, (maxTokens - maxOutputTokens - reservedTokens) * 2) - systemPrompt.utf8.count)
    }

    public func normalized(for model: ModelSpec) -> Self {
        var copy = self
        copy.maxTokens = min(model.maximumContextTokens, max(1024, maxTokens))
        copy.maxOutputTokens = min(copy.maxTokens / 2, max(128, maxOutputTokens))
        copy.topK = min(64, max(1, topK))
        copy.topP = topP.isFinite ? min(1, max(0.01, topP)) : 0.95
        copy.temperature = temperature.isFinite ? min(2, max(0, temperature)) : 0.7
        copy.visualTokenBudget = model.visualTokenBudgets.contains(visualTokenBudget) ? visualTokenBudget : 280
        copy.systemPrompt = Self.prefix(systemPrompt, byteLimit: 4000)
        copy.enableThinking = model.supportsThinking && enableThinking
        copy.enableSpeculativeDecoding = model.supportsSpeculation && enableSpeculativeDecoding
        return copy
    }

    public static func prefix(_ text: String, byteLimit: Int) -> String {
        var result = "", count = 0
        for character in text {
            let next = String(character)
            guard count + next.utf8.count <= max(0, byteLimit) else { break }
            result += next
            count += next.utf8.count
        }
        return result
    }
}
