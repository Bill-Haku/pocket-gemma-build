import Foundation

public enum ExecutionBackend: String, CaseIterable, Identifiable, Codable, Sendable {
    case gpu = "GPU", cpu = "CPU"
    public var id: String { rawValue }
}

public struct GenerationSettings: Codable, Equatable, Sendable {
    public static let defaultSystemPrompt = "あなたは親切で率直なアシスタントです。ユーザーと同じ言語で、わかりやすく回答してください。"
    public var maxTokens = 4096
    public var maxOutputTokens = 512
    public var topK = 40
    public var topP = 0.95
    public var temperature = 0.7
    public var visualTokenBudget = 280
    public var backend: ExecutionBackend = .gpu
    public var enableThinking = false
    public var enableSpeculativeDecoding = false
    public var systemPrompt = GenerationSettings.defaultSystemPrompt
    public init() {}

    public func normalized(for model: ModelSpec) -> Self {
        var copy = self
        copy.maxTokens = min(model.maximumContextTokens, max(1024, maxTokens))
        copy.maxOutputTokens = min(copy.maxTokens / 2, max(128, maxOutputTokens))
        copy.topK = min(64, max(1, topK))
        copy.topP = topP.isFinite ? min(1, max(0.01, topP)) : 0.95
        copy.temperature = temperature.isFinite ? min(2, max(0, temperature)) : 0.7
        copy.visualTokenBudget = [70, 140, 280, 560, 1120].contains(visualTokenBudget) ? visualTokenBudget : 280
        copy.systemPrompt = Self.prefix(systemPrompt, byteLimit: 4000)
        copy.enableThinking = model.supportsThinking && enableThinking
        copy.enableSpeculativeDecoding = model.supportsSpeculation && enableSpeculativeDecoding
        return copy
    }

    public static func prefix(_ text: String, byteLimit: Int) -> String {
        var result = "", count = 0
        for character in text {
            let next = String(character)
            guard count + next.utf8.count <= max(0, byteLimit) else { break }
            result += next
            count += next.utf8.count
        }
        return result
    }
}
