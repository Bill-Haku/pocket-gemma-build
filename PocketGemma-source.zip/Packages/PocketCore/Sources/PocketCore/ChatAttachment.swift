import Foundation

public struct ChatAttachment: Codable, Identifiable, Equatable, Sendable {
    public enum Kind: String, Codable, Sendable { case image, video, file }
    public let id: UUID
    public let kind: Kind
    public let name: String
    public let storedName: String
    public var thumbnailName: String?
    public var imageNames: [String]
    public var extractedText: String?
    public var note: String?
    public var byteCount: Int64
    public var duration: Double?

    public init(id: UUID = UUID(), kind: Kind, name: String, storedName: String,
                thumbnailName: String? = nil, imageNames: [String] = [],
                extractedText: String? = nil, note: String? = nil,
                byteCount: Int64 = 0, duration: Double? = nil) {
        self.id = id; self.kind = kind; self.name = name; self.storedName = storedName
        self.thumbnailName = thumbnailName; self.imageNames = imageNames
        self.extractedText = extractedText; self.note = note
        self.byteCount = byteCount; self.duration = duration
    }
    public static func isSafeFileName(_ name: String) -> Bool {
        !name.isEmpty && name != "." && name != ".." && !name.contains("/")
            && !name.contains("\\") && !name.contains(":") && !name.contains("\0")
    }
    public var contextByteCost: Int {
        name.utf8.count + (extractedText?.utf8.count ?? 0) + imageNames.count * 1120
    }
}
