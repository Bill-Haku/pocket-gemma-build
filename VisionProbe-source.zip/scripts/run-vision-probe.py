"""Serial real-model ablation. A native crash is recorded as a failed case."""
from pathlib import Path
import hashlib, json, os, platform, subprocess, urllib.request

root = Path(__file__).resolve().parent.parent
out = root / 'build/VisionProbe'
out.mkdir(parents=True, exist_ok=True)
models = [
    ('E2B', 'b3ca0d2f076785a8f4b2219ddbd2bdb99954eae1', 2588147712,
     '181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c'),
    ('E4B', '28299f30ee4d43294517a4ac93abd6163412f07f', 3659530240,
     '0b2a8980ce155fd97673d8e820b4d29d9c7d99b8fa6806f425d969b145bd52e0'),
]
assert platform.system() == 'Darwin', 'Metal probe requires macOS; no simulated pass.'
subprocess.run(['swift', 'build', '--package-path', str(root/'Packages/VisionProbe'), '-c', 'release'], check=True)
binary = root / 'Packages/VisionProbe/.build/release/VisionProbe'
results = []
for name, revision, size, digest in models:
    filename = f'gemma-4-{name}-it.litertlm'
    target = out/filename
    url = f'https://huggingface.co/litert-community/gemma-4-{name}-it-litert-lm/resolve/{revision}/{filename}?download=true'
    print('Downloading pinned', name, flush=True)
    sha = hashlib.sha256()
    with urllib.request.urlopen(url, timeout=180) as response, target.open('wb') as file:
        while chunk := response.read(8*1024*1024):
            file.write(chunk); sha.update(chunk)
    assert target.stat().st_size == size and sha.hexdigest() == digest, 'Model integrity mismatch'
    for case, budget, main, vision in [
        ('baseline', 'none', 'gpu', 'gpu'), ('engine-280', '280', 'gpu', 'gpu'),
        ('engine-70', '70', 'gpu', 'gpu'), ('vision-cpu-70', '70', 'gpu', 'cpu'),
        ('text-only', 'none', 'gpu', 'none'),
    ]:
        log = out/f'{name}-{case}.log'
        with log.open('wb') as file:
            try:
                run = subprocess.run([str(binary), str(target), budget, main, vision],
                    stdout=file, stderr=subprocess.STDOUT, timeout=300)
                result = {'model': name, 'case': case, 'exitCode': run.returncode}
            except subprocess.TimeoutExpired:
                result = {'model': name, 'case': case, 'exitCode': None, 'timeoutSeconds': 300}
        events = []
        for line in log.read_text(errors='replace').splitlines():
            if line.startswith('{'):
                try: events.append(json.loads(line))
                except json.JSONDecodeError: pass
        result['events'] = events
        result['passed'] = result['exitCode'] == 0 and any(e.get('event') == 'pass' for e in events)
        results.append(result)
        (out/'results.json').write_text(json.dumps({'platform': platform.platform(),
            'runtime': '0.18.0', 'commit': os.environ.get('GITHUB_SHA'), 'cases': results}, indent=2))
        print(json.dumps(result), flush=True)
    # Delete only the explicit downloaded fixture model. Never upload weights.
    target.unlink()
print('Probe finished. See per-case results; job completion is not a model pass.', flush=True)
