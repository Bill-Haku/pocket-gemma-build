import Foundation
import CoreGraphics
import ImageIO
import Metal
import LiteRTLM

// Only generated fixtures and public pinned weights are used. This tests the
// actual macOS native library, not the iOS device library or UI preview replies.
@main struct VisionProbe {
    static var stage = "startup"
    static func record(_ event: String, _ values: [String: Any] = [:]) {
        var value = values
        value["event"] = event
        value["stage"] = stage
        value["timestamp"] = ISO8601DateFormatter().string(from: Date())
        if let data = try? JSONSerialization.data(withJSONObject: value, options: [.sortedKeys]) {
            FileHandle.standardOutput.write(data)
            FileHandle.standardOutput.write(Data([10]))
        }
    }

    static func fixture(_ circle: Bool, at url: URL) throws {
        let context = CGContext(data: nil, width: 512, height: 512, bitsPerComponent: 8,
            bytesPerRow: 2048, space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue)!
        context.setFillColor(CGColor(gray: 1, alpha: 1))
        context.fill(CGRect(x: 0, y: 0, width: 512, height: 512))
        context.setFillColor(CGColor(red: circle ? 0 : 1, green: circle ? 0.65 : 0,
            blue: 0, alpha: 1))
        let bounds = CGRect(x: 96, y: 96, width: 320, height: 320)
        if circle { context.fillEllipse(in: bounds) } else { context.fill(bounds) }
        let target = CGImageDestinationCreateWithURL(url as CFURL, "public.jpeg" as CFString, 1, nil)!
        CGImageDestinationAddImage(target, context.makeImage()!,
            [kCGImageDestinationLossyCompressionQuality: 0.85] as CFDictionary)
        guard CGImageDestinationFinalize(target) else { throw ProbeError.fixture }
    }

    static func reply(_ conversation: Conversation, _ message: Message) async throws -> String {
        var result = ""
        for try await chunk in conversation.sendMessageStream(message, maxOutputTokens: 128) {
            result += chunk.toString
        }
        record("reply", ["text": result]) // Synthetic prompt/fixture only.
        guard !result.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw ProbeError.empty }
        return result.lowercased()
    }

    static func main() async {
        let args = CommandLine.arguments
        guard args.count == 5 else { record("usage", ["arguments": "MODEL BUDGET_OR_none MAIN_BACKEND VISION_BACKEND_OR_none"]); exit(2) }
        let model = args[1], budget = Int(args[2]), mainGPU = args[3] == "gpu"
        let vision = args[4] == "none" ? nil : (args[4] == "gpu" ? Backend.gpu : Backend.cpu())
        record("environment", ["runtime": "0.18.0", "system": ProcessInfo.processInfo.operatingSystemVersionString,
            "physicalMemory": ProcessInfo.processInfo.physicalMemory,
            "metal": MTLCopyAllDevices().map(\.name), "model": URL(fileURLWithPath: model).lastPathComponent,
            "engineBudget": budget.map { $0 as Any } ?? NSNull(), "main": args[3], "vision": args[4]])
        do {
            stage = "model_info"
            let info = try ModelInfo(throwingModelPath: model)
            record("model_info", ["hasVision": info.inputModalities.vision,
                "maxVisionTokens": info.maxVisionTokenBudget(), "visionSignatures": info.visionSignatureSelection() ?? [],
                "visionBackends": info.supportedBackends(for: .vision).map { String(describing: $0) },
                "minimumRuntime": info.minRuntimeVersion ?? "unspecified"])
            let root = FileManager.default.temporaryDirectory.appendingPathComponent("vision-probe-" + UUID().uuidString)
            try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
            let red = root.appendingPathComponent("one.jpg"), green = root.appendingPathComponent("two.jpg")
            try fixture(false, at: red); try fixture(true, at: green)
            ExperimentalFlags.optIntoExperimentalAPIs()
            ExperimentalFlags.visualTokenBudget = budget.map(Int32.init)
            // Deliberately leave the engine's speculative-decoding flag at nil
            // to isolate the budget/backend difference against Pocket Gemma.
            let engine = Engine(engineConfig: try EngineConfig(modelPath: model,
                backend: mainGPU ? .gpu : .cpu(threadCount: 3), visionBackend: vision,
                maxNumTokens: 2048, cacheDir: root.path))
            stage = "engine_initialize"
            record("begin")
            try await engine.initialize()
            record("initialized")
            func conversation() async throws -> Conversation {
                try await engine.createConversation(with: ConversationConfig(
                    samplerConfig: try SamplerConfig(topK: 1, topP: 1, temperature: 0),
                    thinkingConfig: ThinkingConfig(enableThinking: false, thinkingTokenBudget: 0),
                    automaticToolCalling: false, visualTokenBudget: Int32(budget ?? 280), enableSpeculativeDecoding: false))
            }
            stage = "conversation_create"
            var chat: Conversation? = try await conversation()
            stage = "text_before_image"
            let before = try await reply(chat!, Message("What is 2 plus 3? Answer with the number only."))
            guard before.contains("5") else { throw ProbeError.semantic }
            if vision != nil {
                // Fresh conversation matches a first image turn; subsequent
                // turns exercise native multi-turn reuse and both SDK input APIs.
                chat = nil; stage = "conversation_create"; chat = try await conversation()
                stage = "image_file_red_square"
                let first = try await reply(chat!, Message(contents: [.imageFile(red.path),
                    .text("Describe the main shape and its color in this image. Answer in English with a short sentence.")]))
                guard first.contains("red") && (first.contains("square") || first.contains("rectangle")) else { throw ProbeError.semantic }
                stage = "image_data_green_circle"
                let second = try await reply(chat!, Message(contents: [.imageData(try Data(contentsOf: green)),
                    .text("Describe only the main shape and its color in the new image. Answer in English with a short sentence.")]))
                guard second.contains("green") && (second.contains("circle") || second.contains("round")) else { throw ProbeError.semantic }
                stage = "bad_image"
                do {
                    _ = try await reply(chat!, Message(contents: [.imageData(Data([0, 1, 2])), .text("Describe this image.")]))
                    throw ProbeError.badImageAccepted
                } catch ProbeError.badImageAccepted { throw ProbeError.badImageAccepted }
                catch { record("expected_error", ["error": error.localizedDescription]) }
                chat = nil; stage = "conversation_after_error"; chat = try await conversation()
                stage = "image_after_error"
                let recovered = try await reply(chat!, Message(contents: [.imageFile(red.path), .text("Describe the main shape and color in English.")]))
                guard recovered.contains("red") else { throw ProbeError.semantic }
            }
            stage = "text_after_image"
            let after = try await reply(chat!, Message("What is 4 plus 4? Answer with the number only."))
            guard after.contains("8") else { throw ProbeError.semantic }
            chat = nil
            stage = "complete"
            record("pass")
        } catch {
            record("failure", ["error": error.localizedDescription, "errorType": String(reflecting: type(of: error))])
            exit(1)
        }
    }
}

enum ProbeError: Error { case fixture, empty, semantic, badImageAccepted }
