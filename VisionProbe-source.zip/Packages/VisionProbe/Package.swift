// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "VisionProbe", platforms: [.macOS(.v13)],
    dependencies: [.package(url: "https://github.com/google-ai-edge/LiteRT-LM.git", exact: "0.18.0")],
    targets: [.executableTarget(name: "VisionProbe", dependencies: [.product(name: "LiteRTLM", package: "LiteRT-LM")])]
)
